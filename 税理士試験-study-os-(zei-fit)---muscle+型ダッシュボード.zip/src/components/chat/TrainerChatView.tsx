import React, { useState, useEffect, useRef } from 'react';
import { Bot, Send, User, RotateCcw, Sparkles, Flame, ShieldAlert } from 'lucide-react';
import { TrainerMessage, SubjectId } from '../../types';

interface TrainerChatViewProps {
  messages: TrainerMessage[];
  onSendMessage: (userText: string) => Promise<void>;
  onClearChat: () => void;
  isSending: boolean;
  currentSubject: SubjectId;
}

export const TrainerChatView: React.FC<TrainerChatViewProps> = ({
  messages,
  onSendMessage,
  onClearChat,
  isSending,
  currentSubject,
}) => {
  const [inputText, setInputText] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isSending]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isSending) return;
    const text = inputText;
    setInputText('');
    onSendMessage(text);
  };

  const handleQuickPrompt = (prompt: string) => {
    if (isSending) return;
    onSendMessage(prompt);
  };

  const QUICK_PROMPTS = [
    '住民税の均等割非課税について口頭テストを出題して！',
    '酒税法の未納税移出の要件（法第28条）を3分で総復習したい',
    '計算問題で解法がすぐ出ず手が止まる。筋トレ的克服法を教えて',
    '住民税2年落ちて不安。本番で書き切るための喝を入れてくれ！🔥',
    '2026/2027年の酒税法改正ポイント（ビール系税率一本化）を解説して',
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] max-w-4xl mx-auto rounded-2xl bg-slate-900/80 border border-slate-800 shadow-2xl overflow-hidden">
      {/* Chat Header */}
      <div className="px-4 py-3 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-rose-500 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-500/20">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>専属鬼コーチ & 試験官AI</span>
              <span className="text-[10px] text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40">
                Muscle+指導
              </span>
            </h3>
            <p className="text-[10px] text-slate-400">
              口頭出題 · 答案相談 · ミス原因分析 · モチベーション点火
            </p>
          </div>
        </div>

        <button
          onClick={onClearChat}
          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-slate-850 transition"
          title="チャット履歴をリセット"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-gradient-to-br from-rose-500 to-amber-500 text-white'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 text-xs md:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-950 border border-slate-800 text-slate-100 rounded-tl-none whitespace-pre-wrap'
                }`}
              >
                {msg.content}
                <div
                  className={`text-[9px] mt-1 text-right font-mono ${
                    isUser ? 'text-slate-900/60' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          );
        })}

        {isSending && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-slate-800 text-slate-400 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-slate-950 border border-slate-800 rounded-2xl rounded-tl-none px-4 py-3 text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>コーチが答案・アドバイスを思考中...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Strip */}
      <div className="px-3 py-2 bg-slate-950/60 border-t border-slate-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {QUICK_PROMPTS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleQuickPrompt(prompt)}
            disabled={isSending}
            className="px-2.5 py-1 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-[11px] text-slate-300 whitespace-nowrap active:scale-95 transition disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Field */}
      <form onSubmit={handleSubmit} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="質問・暗唱の回答・迷った論点を送信..."
          disabled={isSending}
          className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs md:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isSending}
          className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-40"
        >
          <span>送信</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
