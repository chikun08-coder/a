import React, { useState } from 'react';
import { 
  Layers, ExternalLink, Sparkles, Download, CheckCircle, 
  RotateCw, Plus, BookOpen, Tag, ArrowRight, FileText
} from 'lucide-react';
import { AnkiCard, TheoryItem, SubjectId } from '../../types';
import { StorageService } from '../../services/storage';
import { getJSTDateString, addDaysJST } from '../../utils/date';

interface NotebookLMAnkiHubProps {
  ankiCards: AnkiCard[];
  onAddAnkiCards: (cards: AnkiCard[]) => void;
  onUpdateAnkiCard: (card: AnkiCard) => void;
  onAddParsedTheories: (theories: TheoryItem[]) => void;
}

export const NotebookLMAnkiHub: React.FC<NotebookLMAnkiHubProps> = ({
  ankiCards,
  onAddAnkiCards,
  onUpdateAnkiCard,
  onAddParsedTheories,
}) => {
  const [activeTab, setActiveTab] = useState<'notebooklm' | 'flashcards' | 'decklist'>('notebooklm');

  // NotebookLM paste state
  const [notebookInput, setNotebookInput] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<SubjectId>('resident');
  const [isParsing, setIsParsing] = useState<boolean>(false);
  const [parseResult, setParseResult] = useState<any | null>(null);

  // In-App Flashcard Review state
  const [reviewDeckFilter, setReviewDeckFilter] = useState<string>('all');
  const [currentCardIndex, setCurrentCardIndex] = useState<number>(0);
  const [showAnswer, setShowAnswer] = useState<boolean>(false);
  const [reviewCompleted, setReviewCompleted] = useState<boolean>(false);

  // Filter cards for review
  const todayStr = getJSTDateString();
  const deckOptions = Array.from(new Set(ankiCards.map((c) => c.deckName)));
  const reviewCards = ankiCards.filter((c) => {
    const matchDeck = reviewDeckFilter === 'all' || c.deckName === reviewDeckFilter;
    return matchDeck;
  });

  const currentCard = reviewCards[currentCardIndex];

  // Parse NotebookLM text via Backend Gemini
  const handleParseNotebookLM = async () => {
    if (!notebookInput.trim()) {
      alert('NotebookLMからコピーしたテキストや講義ノートを貼り付けてください。');
      return;
    }

    setIsParsing(true);
    try {
      const response = await fetch('/api/ai/parse-notebooklm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText: notebookInput,
          subjectId: selectedSubject,
        }),
      });

      if (!response.ok) {
        throw new Error('NotebookLMの解析に失敗しました。');
      }

      const data = await response.json();
      setParseResult(data);
    } catch (e: any) {
      alert(`解析エラー: ${e?.message || '通信エラー'}`);
    } finally {
      setIsParsing(false);
    }
  };

  // Add parsed theory and anki cards into active store
  const handleImportParsedData = () => {
    if (!parseResult || !parseResult.theoryItems) return;

    const newTheories: TheoryItem[] = parseResult.theoryItems.map((item: any, i: number) => ({
      id: `th-imported-${Date.now()}-${i}`,
      subjectId: selectedSubject,
      title: item.title,
      category: item.category || 'NotebookLM抽出論点',
      isRevised2027: !!item.isRevised2027,
      standardMinutes: item.standardTimeMinutes || 12,
      lv1Hint: item.lv1TitleAnswer || item.title,
      lv2Outline: item.lv2Outline || [],
      lv3KeyRequirements: item.lv3KeyRequirements || [],
      lv4FullText: item.lv4FullText || '',
      bestScore: 0,
      bestTimeSeconds: 0,
      currentStage: 1,
      history: [],
    }));

    const newCards: AnkiCard[] = [];
    parseResult.theoryItems.forEach((item: any, idx: number) => {
      if (Array.isArray(item.ankiCards)) {
        item.ankiCards.forEach((c: any, cIdx: number) => {
          newCards.push({
            id: `anki-imported-${Date.now()}-${idx}-${cIdx}`,
            subjectId: selectedSubject,
            deckName: `${selectedSubject === 'resident' ? '住民税' : '酒税法'}::NotebookLM抽出`,
            front: c.front,
            back: c.back,
            tag: c.tag || 'NotebookLM',
            intervalDays: 1,
            repetitions: 0,
            easeFactor: 2.5,
            nextReviewDate: todayStr,
          });
        });
      }
    });

    onAddParsedTheories(newTheories);
    if (newCards.length > 0) {
      onAddAnkiCards(newCards);
    }

    alert(`理論論点 ${newTheories.length}件、Ankiカード ${newCards.length}枚 を学習システムに追加しました！`);
    setNotebookInput('');
    setParseResult(null);
  };

  // Export Anki CSV
  const handleExportCSV = () => {
    const csvContent = StorageService.exportAnkiCSV(ankiCards);
    const blob = new Blob([csvContent], { type: 'text/tab-separated-values;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tax_exam_anki_deck_${todayStr}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Handle flashcard recall rating
  const handleRateCard = (quality: 'again' | 'good' | 'easy') => {
    if (!currentCard) return;

    let newInterval = 1;
    let newRep = currentCard.repetitions + 1;
    let newEase = currentCard.easeFactor;

    if (quality === 'again') {
      newInterval = 1;
      newRep = 0;
      newEase = Math.max(1.3, newEase - 0.2);
    } else if (quality === 'good') {
      newInterval = Math.max(2, Math.round(currentCard.intervalDays * 2));
    } else if (quality === 'easy') {
      newInterval = Math.max(4, Math.round(currentCard.intervalDays * 2.5));
      newEase += 0.15;
    }

    const updatedCard: AnkiCard = {
      ...currentCard,
      repetitions: newRep,
      intervalDays: newInterval,
      easeFactor: newEase,
      nextReviewDate: addDaysJST(todayStr, newInterval),
    };

    onUpdateAnkiCard(updatedCard);
    setShowAnswer(false);

    if (currentCardIndex + 1 < reviewCards.length) {
      setCurrentCardIndex(currentCardIndex + 1);
    } else {
      setReviewCompleted(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('notebooklm')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'notebooklm'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            NotebookLM インポートハブ
          </button>
          <button
            onClick={() => {
              setActiveTab('flashcards');
              setCurrentCardIndex(0);
              setShowAnswer(false);
              setReviewCompleted(false);
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'flashcards'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            アプリ内暗記カード特訓
          </button>
          <button
            onClick={() => setActiveTab('decklist')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'decklist'
                ? 'bg-slate-800 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            カード一覧 & Anki出力
          </button>
        </div>

        {/* External Quick Links */}
        <div className="flex items-center gap-2">
          <a
            href="https://notebooklm.google.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-semibold text-purple-300 hover:bg-slate-800 transition"
          >
            <span>NotebookLM を開く</span>
            <ExternalLink className="w-3 h-3" />
          </a>

          <a
            href="https://ankiweb.net/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs font-semibold text-cyan-300 hover:bg-slate-800 transition"
          >
            <span>AnkiWeb を開く</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* TAB 1: NotebookLM Import Hub */}
      {activeTab === 'notebooklm' && (
        <div className="space-y-4">
          <div className="p-4 md:p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-purple-950/40 border border-purple-500/30 shadow-xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base md:text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  <span>NotebookLM 連携 & AI論点・Ankiカード自動分解</span>
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                  NotebookLMに教材PDFや大原の過去問を読み込ませて生成した<strong>「講義ノート・重要論点要約・Q&A」</strong>をここに貼り付けるだけで、Geminiが瞬時に「Lv1〜Lv5の5段階理論特訓データ」と「Anki用暗記カード」へ構造化・登録します。
                </p>
              </div>
            </div>

            {/* Target Subject Selector */}
            <div className="flex items-center gap-3 pt-1">
              <span className="text-xs text-slate-400">対象科目:</span>
              <div className="flex items-center gap-2">
                {[
                  { id: 'resident', label: '住民税' },
                  { id: 'liquor', label: '酒税法' },
                  { id: 'bookkeeping', label: '簿記論' },
                  { id: 'financial', label: '財務諸表論' },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedSubject(s.id as SubjectId)}
                    className={`px-3 py-1 text-xs font-bold rounded-lg border transition ${
                      selectedSubject === s.id
                        ? 'bg-purple-600 text-white border-purple-500 shadow-sm'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Paste Textarea */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>NotebookLMの抽出テキストをペースト:</span>
                <span>{notebookInput.length} 文字</span>
              </div>
              <textarea
                rows={6}
                value={notebookInput}
                onChange={(e) => setNotebookInput(e.target.value)}
                placeholder="NotebookLMの要約やQ&Aテキストをそのまま貼り付けてください。&#10;例:&#10;【均等割の非課税限度額】生活保護法の生活扶助を受けている者は絶対的非課税。障害者・未成年者・寡婦又はひとり親で前年の合計所得金額が135万円以下の者は非課税。また、同一生計配偶者又は扶養親族を有する場合の算式は..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-purple-500 font-mono leading-relaxed"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                ※ 2027年最新改正（定額減税、森林環境税、酒税一本化等）も自動検出します
              </span>

              <button
                type="button"
                onClick={handleParseNotebookLM}
                disabled={isParsing || !notebookInput.trim()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs shadow-md shadow-purple-600/30 active:scale-95 transition disabled:opacity-40"
              >
                {isParsing ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Geminiが論点構造とAnkiカードを分解生成中...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Geminiで5段階論点＋Ankiカードに自動分解</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Parsed Preview Card */}
          {parseResult && (
            <div className="p-4 md:p-6 rounded-2xl bg-slate-900 border border-purple-500/50 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <h4 className="text-sm font-bold text-white">
                    分解完了: 理論 {parseResult.theoryItems?.length || 0}件 が抽出されました
                  </h4>
                </div>
                <button
                  onClick={handleImportParsedData}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition"
                >
                  この内容を学習システムに追加する
                </button>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto">
                {parseResult.theoryItems?.map((th: any, idx: number) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-white text-sm">{th.title}</span>
                      <span className="text-[10px] text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-800/40">
                        {th.category}
                      </span>
                    </div>

                    <div className="text-slate-300">
                      <strong className="text-amber-400">Lv.2 柱・見出し:</strong> {th.lv2Outline?.join(' / ')}
                    </div>

                    <div className="text-slate-300">
                      <strong className="text-cyan-400">Lv.3 重要要件:</strong>
                      <ul className="list-disc list-inside mt-1 text-slate-400 space-y-0.5">
                        {th.lv3KeyRequirements?.slice(0, 3).map((r: string, rI: number) => (
                          <li key={rI}>{r}</li>
                        ))}
                      </ul>
                    </div>

                    {th.ankiCards && (
                      <div className="text-slate-400 pt-1 border-t border-slate-800 text-[11px]">
                        生成Ankiカード数: <strong className="text-emerald-400 font-mono">{th.ankiCards.length}枚</strong>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: In-App Flashcard Review Mode */}
      {activeTab === 'flashcards' && (
        <div className="max-w-xl mx-auto space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <span>デッキ:</span>
              <select
                value={reviewDeckFilter}
                onChange={(e) => {
                  setReviewDeckFilter(e.target.value);
                  setCurrentCardIndex(0);
                  setShowAnswer(false);
                  setReviewCompleted(false);
                }}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1"
              >
                <option value="all">全カード ({ankiCards.length}枚)</option>
                {deckOptions.map((deck) => (
                  <option key={deck} value={deck}>{deck}</option>
                ))}
              </select>
            </div>

            <span className="font-mono">
              {reviewCards.length > 0 ? `${currentCardIndex + 1} / ${reviewCards.length}` : '0枚'}
            </span>
          </div>

          {reviewCompleted ? (
            <div className="p-8 rounded-2xl bg-slate-900 border border-emerald-500/40 text-center space-y-4 shadow-xl">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">本日の復習セッション完了！🔥</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                暗記カードの反復が脳のシナプスを強化しました。明日の復習キューに自動更新されます。
              </p>
              <button
                onClick={() => {
                  setCurrentCardIndex(0);
                  setShowAnswer(false);
                  setReviewCompleted(false);
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl"
              >
                最初からやり直す
              </button>
            </div>
          ) : currentCard ? (
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl min-h-[300px] flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-3 font-mono">
                  <span>{currentCard.deckName}</span>
                  <span>{currentCard.tag}</span>
                </div>

                <div className="text-sm md:text-base font-bold text-white leading-relaxed">
                  {currentCard.front}
                </div>
              </div>

              {/* Reveal Answer Section */}
              {showAnswer ? (
                <div className="space-y-4 pt-4 border-t border-slate-800 animate-in fade-in">
                  <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 text-xs md:text-sm text-amber-200 font-mono leading-relaxed font-bold">
                    {currentCard.back}
                  </div>

                  {/* Recall Rating Buttons */}
                  <div className="grid grid-cols-3 gap-2 pt-2">
                    <button
                      onClick={() => handleRateCard('again')}
                      className="py-2.5 px-2 rounded-xl bg-rose-950/60 border border-rose-800/60 hover:bg-rose-900/60 text-rose-300 font-bold text-xs"
                    >
                      <div>もう一度</div>
                      <div className="text-[10px] text-rose-400/80 font-normal">明日復習</div>
                    </button>
                    <button
                      onClick={() => handleRateCard('good')}
                      className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                    >
                      <div>普通</div>
                      <div className="text-[10px] text-slate-400 font-normal">3日後</div>
                    </button>
                    <button
                      onClick={() => handleRateCard('easy')}
                      className="py-2.5 px-2 rounded-xl bg-emerald-950/60 border border-emerald-800/60 hover:bg-emerald-900/60 text-emerald-300 font-bold text-xs"
                    >
                      <div>簡単</div>
                      <div className="text-[10px] text-emerald-400/80 font-normal">7日後</div>
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowAnswer(true)}
                  className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm shadow-md shadow-amber-500/20 active:scale-95 transition"
                >
                  答えを表示する
                </button>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-xs text-slate-500 bg-slate-900 rounded-xl border border-slate-800">
              対象のカードがありません。
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Deck List & CSV Export */}
      {activeTab === 'decklist' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="text-xs text-slate-400">
              全 <strong className="text-white font-mono">{ankiCards.length}</strong> 枚の暗記カード
            </div>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-extrabold shadow-sm transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Anki互換CSVをダウンロード</span>
            </button>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {ankiCards.map((card) => (
              <div
                key={card.id}
                className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>{card.deckName}</span>
                  <span>次回復習: {card.nextReviewDate} (間隔: {card.intervalDays}日)</span>
                </div>
                <div className="font-bold text-white">{card.front}</div>
                <div className="text-slate-400 font-mono pl-3 border-l-2 border-slate-700">
                  {card.back}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
