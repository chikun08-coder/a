import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, Play, Pause, RotateCcw, CheckCircle, XCircle, 
  Flame, Trophy, AlertCircle, Plus, ChevronRight, TrendingDown,
  Award, HelpCircle
} from 'lucide-react';
import { CalculationItem, CalculationLog, SubjectId } from '../../types';
import { firePRCelebration, formatSeconds, formatTimeDigital } from '../../utils/confetti';
import { getJSTDateString } from '../../utils/date';

interface CalculationSpeedViewProps {
  calculations: CalculationItem[];
  onUpdateCalculation: (updated: CalculationItem) => void;
  onAddCalculation: (newItem: CalculationItem) => void;
  onRecordStudyTime: (subjectId: SubjectId, minutes: number, note: string) => void;
}

export const CalculationSpeedView: React.FC<CalculationSpeedViewProps> = ({
  calculations,
  onUpdateCalculation,
  onAddCalculation,
  onRecordStudyTime,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectId>('resident');
  const [selectedCalcId, setSelectedCalcId] = useState<string>('');

  // Stopwatch state
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Result dialog / completion modal state
  const [isFinishing, setIsFinishing] = useState<boolean>(false);
  const [isCorrectInput, setIsCorrectInput] = useState<boolean>(true);
  const [errorCategory, setErrorCategory] = useState<CalculationLog['errorCategory']>('none');
  const [memoInput, setMemoInput] = useState<string>('');

  // New problem form modal
  const [showNewModal, setShowNewModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('');
  const [newTargetMinutes, setNewTargetMinutes] = useState<number>(8);

  const subjectCalcs = calculations.filter((c) => c.subjectId === selectedSubject);
  const currentCalc = subjectCalcs.find((c) => c.id === selectedCalcId) || subjectCalcs[0];

  useEffect(() => {
    if (subjectCalcs.length > 0 && (!selectedCalcId || !subjectCalcs.some(c => c.id === selectedCalcId))) {
      setSelectedCalcId(subjectCalcs[0].id);
    }
  }, [selectedSubject, calculations]);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const toggleStopwatch = () => {
    setIsRunning(!isRunning);
  };

  const resetStopwatch = () => {
    setIsRunning(false);
    setElapsedSeconds(0);
    setIsFinishing(false);
  };

  const handleFinishLap = () => {
    setIsRunning(false);
    setIsFinishing(true);
    setIsCorrectInput(true);
    setErrorCategory('none');
    setMemoInput('');
  };

  const handleSaveLapRecord = () => {
    if (!currentCalc) return;

    const prevBest = currentCalc.bestTimeSeconds;
    // Personal Best condition: Correct answer AND (no previous record OR strictly faster)
    const isPB = isCorrectInput && (prevBest === 0 || elapsedSeconds < prevBest);

    if (isPB) {
      firePRCelebration();
    }

    const newLog: CalculationLog = {
      id: 'clog-' + Date.now(),
      date: getJSTDateString(),
      timeSeconds: elapsedSeconds,
      previousBestSeconds: prevBest || undefined,
      isCorrect: isCorrectInput,
      errorCategory: isCorrectInput ? 'none' : errorCategory,
      memo: memoInput,
      isPersonalBest: isPB,
    };

    const newConsecutive = isCorrectInput ? (currentCalc.consecutiveCorrect || 0) + 1 : 0;
    const newBestTime = isPB ? elapsedSeconds : prevBest;

    const updated: CalculationItem = {
      ...currentCalc,
      bestTimeSeconds: newBestTime,
      consecutiveCorrect: newConsecutive,
      logs: [newLog, ...currentCalc.logs],
    };

    onUpdateCalculation(updated);

    // Record study time if practiced >= 1 minute
    if (elapsedSeconds >= 60) {
      onRecordStudyTime(
        selectedSubject,
        Math.round(elapsedSeconds / 60),
        `計算スピード計測「${currentCalc.title}」所要:${formatSeconds(elapsedSeconds)} (${isCorrectInput ? '正解○' : '不正解×'})`
      );
    }

    setIsFinishing(false);
    setElapsedSeconds(0);
  };

  const handleCreateNewProblem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newItem: CalculationItem = {
      id: 'calc-custom-' + Date.now(),
      subjectId: selectedSubject,
      title: newTitle,
      category: newCategory || '総合計算',
      targetMinutes: Number(newTargetMinutes) || 8,
      bestTimeSeconds: 0,
      consecutiveCorrect: 0,
      logs: [],
    };

    onAddCalculation(newItem);
    setSelectedCalcId(newItem.id);
    setShowNewModal(false);
    setNewTitle('');
    setNewCategory('');
  };

  // Error category dictionary
  const ERROR_LABELS: Record<string, { label: string; color: string; desc: string }> = {
    lack_of_knowledge: {
      label: '① 知識不足',
      color: 'bg-rose-950/60 text-rose-300 border-rose-800/60',
      desc: '規定や算式そのものを知らなかった・覚えていなかった',
    },
    procedure_stalled: {
      label: '② 解法手順不発',
      color: 'bg-amber-950/60 text-amber-300 border-amber-800/60',
      desc: '問題を見た瞬間に解法順序が出ず、考えて手が止まった',
    },
    calc_mistake: {
      label: '③ 計算ミス',
      color: 'bg-cyan-950/60 text-cyan-300 border-cyan-800/60',
      desc: '電卓の打ち間違い、転記ミス、単純な足し引きミス',
    },
    misread: {
      label: '④ 問題文読み違い',
      color: 'bg-purple-950/60 text-purple-300 border-purple-800/60',
      desc: '指示の見落とし、端数処理の指定、除外要件の読み飛ばし',
    },
  };

  return (
    <div className="space-y-6">
      {/* Subject Filter Bar */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800">
          <button
            onClick={() => setSelectedSubject('resident')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              selectedSubject === 'resident'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            住民税（所得控除・税額計算）
          </button>
          <button
            onClick={() => setSelectedSubject('bookkeeping')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              selectedSubject === 'bookkeeping'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            簿記論（個別問題タイムアタック）
          </button>
          <button
            onClick={() => setSelectedSubject('financial')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              selectedSubject === 'financial'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            財務諸表論（B/S・P/L作成速度）
          </button>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition"
        >
          <Plus className="w-3.5 h-3.5 text-amber-400" />
          <span>新しい問題を追加</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Calculation Problem List (lg:col-span-5) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-semibold">
            <span>タイムアタック問題一覧</span>
            <span>{subjectCalcs.length}問</span>
          </div>

          <div className="space-y-2">
            {subjectCalcs.map((calc) => {
              const isSelected = calc.id === currentCalc?.id;
              const hasPB = calc.bestTimeSeconds > 0;
              const latestLog = calc.logs[0];

              return (
                <div
                  key={calc.id}
                  onClick={() => setSelectedCalcId(calc.id)}
                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500/60 shadow-lg shadow-cyan-500/5 ring-1 ring-cyan-500/20'
                      : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-[11px] font-semibold text-slate-400">
                      {calc.category}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs font-mono">
                      {calc.consecutiveCorrect > 0 && (
                        <span className="text-[10px] font-bold text-amber-400 bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-800/40 flex items-center gap-0.5">
                          <Flame className="w-3 h-3 fill-amber-400" />
                          {calc.consecutiveCorrect}連続
                        </span>
                      )}
                      <span className="text-[11px] text-slate-400">
                        目標: {calc.targetMinutes}分
                      </span>
                    </div>
                  </div>

                  <h4 className="text-sm font-bold text-white line-clamp-1">
                    {calc.title}
                  </h4>

                  {/* Muscle+ previous vs best comparison strip */}
                  <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1 text-slate-400">
                      <span>自己ベスト:</span>
                      <strong className={`tabular-nums ${hasPB ? 'text-cyan-400' : 'text-slate-400'}`}>
                        {hasPB ? formatSeconds(calc.bestTimeSeconds) : '未計測'}
                      </strong>
                    </div>

                    {latestLog && (
                      <div className="flex items-center gap-1 text-[11px]">
                        <span className="text-slate-400">直近:</span>
                        <span className={`font-bold ${latestLog.isCorrect ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {formatSeconds(latestLog.timeSeconds)} {latestLog.isCorrect ? '○' : '×'}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Muscle+ Stopwatch & Record Canvas (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-4">
          {currentCalc && (
            <div className="p-4 md:p-6 rounded-2xl bg-slate-900/70 border border-slate-800 shadow-xl space-y-6">
              {/* Problem Title & PR target benchmark */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
                <div>
                  <div className="text-xs text-cyan-400 font-semibold mb-1 flex items-center gap-1">
                    <Timer className="w-3.5 h-3.5" />
                    <span>{currentCalc.category} · 目標 {currentCalc.targetMinutes}分以内</span>
                  </div>
                  <h3 className="text-lg md:text-xl font-extrabold text-white">
                    {currentCalc.title}
                  </h3>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="text-left">
                    <div className="text-[10px] text-slate-400">前回の自己ベスト</div>
                    <div className="font-mono font-bold text-cyan-400 text-sm tabular-nums">
                      {currentCalc.bestTimeSeconds > 0 ? formatSeconds(currentCalc.bestTimeSeconds) : '未計測'}
                    </div>
                  </div>
                  <div className="w-[1px] h-7 bg-slate-800" />
                  <div className="text-left">
                    <div className="text-[10px] text-slate-400">本日のターゲット</div>
                    <div className="font-mono font-bold text-amber-400 text-sm">
                      {currentCalc.bestTimeSeconds > 0
                        ? `前回超え (-${Math.max(15, Math.round(currentCalc.bestTimeSeconds * 0.05))}秒)`
                        : `${currentCalc.targetMinutes}分切り`}
                    </div>
                  </div>
                </div>
              </div>

              {/* Muscle+ Giant Stopwatch Display */}
              <div className="py-6 px-4 bg-slate-950/90 rounded-2xl border border-slate-800 flex flex-col items-center justify-center space-y-4 shadow-inner">
                <div className="text-[11px] font-bold text-slate-400 tracking-wider">
                  考えたらアウト！数IA, IIBのように反射で解くスピード測定
                </div>

                <div className="text-5xl md:text-6xl font-black font-mono text-white tabular-nums tracking-widest text-shadow drop-shadow-[0_0_20px_rgba(6,182,212,0.15)]">
                  {formatTimeDigital(elapsedSeconds)}
                </div>

                {/* Realtime PR indicator */}
                {currentCalc.bestTimeSeconds > 0 && elapsedSeconds > 0 && (
                  <div className="text-xs font-mono">
                    {elapsedSeconds < currentCalc.bestTimeSeconds ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <TrendingDown className="w-3.5 h-3.5" />
                        前回ベストより {formatSeconds(currentCalc.bestTimeSeconds - elapsedSeconds)} リード中！
                      </span>
                    ) : (
                      <span className="text-rose-400 font-semibold">
                        前回ベスト比 +{formatSeconds(elapsedSeconds - currentCalc.bestTimeSeconds)} 経過
                      </span>
                    )}
                  </div>
                )}

                {/* Control Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={toggleStopwatch}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl font-extrabold text-sm shadow-lg transition-all active:scale-95 ${
                      isRunning
                        ? 'bg-rose-500 text-white shadow-rose-500/20 hover:bg-rose-400'
                        : 'bg-gradient-to-r from-cyan-500 to-cyan-600 text-slate-950 shadow-cyan-500/20 hover:from-cyan-400 hover:to-cyan-500'
                    }`}
                  >
                    {isRunning ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-slate-950" />}
                    <span>{isRunning ? '一時停止' : elapsedSeconds > 0 ? '再開する' : 'スタート'}</span>
                  </button>

                  <button
                    onClick={handleFinishLap}
                    disabled={elapsedSeconds === 0}
                    className="flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm shadow-md shadow-amber-500/20 active:scale-95 transition disabled:opacity-40"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>完答・記録</span>
                  </button>

                  <button
                    onClick={resetStopwatch}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800 transition"
                    title="リセット"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Completion & Error Classification Dialog */}
              {isFinishing && (
                <div className="p-4 md:p-5 rounded-2xl bg-slate-950 border border-cyan-500/50 shadow-2xl space-y-4 animate-in fade-in slide-in-from-bottom-2">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="text-sm font-extrabold text-white flex items-center gap-2">
                      <Award className="w-4 h-4 text-cyan-400" />
                      タイム: {formatSeconds(elapsedSeconds)} の結果判定
                    </span>
                    <span className="text-xs text-slate-400">Muscle+ 4大ミス分析</span>
                  </div>

                  {/* Correct / Incorrect Choice */}
                  <div>
                    <label className="text-xs text-slate-400 font-semibold block mb-2">正誤判定:</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setIsCorrectInput(true);
                          setErrorCategory('none');
                        }}
                        className={`py-2.5 px-4 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition ${
                          isCorrectInput
                            ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-850'
                        }`}
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>正解（○）</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsCorrectInput(false)}
                        className={`py-2.5 px-4 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition ${
                          !isCorrectInput
                            ? 'bg-rose-500 text-white border-rose-400 shadow-md shadow-rose-500/20'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-850'
                        }`}
                      >
                        <XCircle className="w-4 h-4" />
                        <span>不正解（×）</span>
                      </button>
                    </div>
                  </div>

                  {/* 4 Error Categories (Mandatory on Mistake) */}
                  {!isCorrectInput && (
                    <div className="space-y-2 p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                      <label className="text-xs font-bold text-rose-300 block">
                        ミスの原因を4大分類から特定せよ:
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {Object.entries(ERROR_LABELS).map(([key, item]) => {
                          const isCatSelected = errorCategory === key;
                          return (
                            <button
                              key={key}
                              type="button"
                              onClick={() => setErrorCategory(key as any)}
                              className={`p-2.5 rounded-lg border text-left transition ${
                                isCatSelected
                                  ? `${item.color} ring-1 ring-white/20 font-bold`
                                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                              }`}
                            >
                              <div className="font-bold text-white mb-0.5">{item.label}</div>
                              <div className="text-[10px] text-slate-400 leading-tight">{item.desc}</div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Memo field */}
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">気付き・電卓ミス箇所のメモ:</label>
                    <input
                      type="text"
                      value={memoInput}
                      onChange={(e) => setMemoInput(e.target.value)}
                      placeholder="例: 人的控除差額の表は即出たが、住宅ローン残高の限度額判定で迷った"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsFinishing(false)}
                      className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white"
                    >
                      キャンセル
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveLapRecord}
                      className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs shadow-md shadow-cyan-500/20"
                    >
                      ラップ記録を確定する
                    </button>
                  </div>
                </div>
              )}

              {/* History / Muscle+ PR Log Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>過去のタイム測定履歴（Muscle+ログ）</span>
                  <span className="text-slate-500">{currentCalc.logs.length}回の記録</span>
                </div>

                {currentCalc.logs.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-500 bg-slate-950/40 rounded-xl border border-slate-800">
                    まだタイム記録がありません。上のストップウォッチで1本目を測りましょう！
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-56 overflow-y-auto">
                    {currentCalc.logs.map((log) => {
                      const errorInfo = log.errorCategory !== 'none' ? ERROR_LABELS[log.errorCategory] : null;

                      return (
                        <div
                          key={log.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-mono text-slate-500">{log.date}</span>
                            <span
                              className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-xs ${
                                log.isCorrect
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                                  : 'bg-rose-950 text-rose-400 border border-rose-800'
                              }`}
                            >
                              {log.isCorrect ? '○' : '×'}
                            </span>
                            <span className="font-mono font-bold text-white text-sm tabular-nums">
                              {formatSeconds(log.timeSeconds)}
                            </span>
                            {log.isPersonalBest && (
                              <span className="text-[10px] font-bold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                                <Flame className="w-3 h-3 fill-amber-400" /> PR
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-right">
                            {errorInfo && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/40">
                                {errorInfo.label}
                              </span>
                            )}
                            {log.memo && (
                              <span className="text-[11px] text-slate-400 max-w-[180px] truncate" title={log.memo}>
                                {log.memo}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Add New Calculation Drill */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-200">
            <h3 className="text-base font-bold text-white mb-4">
              計算タイムアタック問題の新規登録
            </h3>
            <form onSubmit={handleCreateNewProblem} className="space-y-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1">問題タイトル *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="例: 退職手当等の申告分離課税・特別徴収税額計算"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">カテゴリ</label>
                  <input
                    type="text"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    placeholder="個別計算 / 総合問題"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">目標制限時間 (分)</label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={newTargetMinutes}
                    onChange={(e) => setNewTargetMinutes(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl"
                >
                  登録する
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
