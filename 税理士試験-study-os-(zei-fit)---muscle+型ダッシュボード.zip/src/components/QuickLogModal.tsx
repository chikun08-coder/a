import React, { useState } from 'react';
import { X, Clock, Flame, BookOpen, Layers } from 'lucide-react';
import { SubjectId, StudySession } from '../types';
import { getJSTDateString } from '../utils/date';

interface QuickLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSession: (session: StudySession) => void;
}

export const QuickLogModal: React.FC<QuickLogModalProps> = ({
  isOpen,
  onClose,
  onSaveSession,
}) => {
  const [subjectId, setSubjectId] = useState<SubjectId>('resident');
  const [minutes, setMinutes] = useState<number>(30);
  const [sessionType, setSessionType] = useState<StudySession['type']>('theory');
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newSession: StudySession = {
      id: 'session-' + Date.now(),
      date: getJSTDateString(),
      subjectId,
      minutes: Number(minutes) || 15,
      type: sessionType,
      notes: notes || '自主学習',
    };

    onSaveSession(newSession);
    onClose();
    setNotes('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Flame className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">本日の学習時間を記録</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Subject selector */}
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-semibold">科目:</label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'resident', name: '住民税 (本命)', color: 'border-amber-500/50 text-amber-300' },
                { id: 'liquor', name: '酒税法 (理論)', color: 'border-pink-500/50 text-pink-300' },
                { id: 'bookkeeping', name: '簿記論 (計算)', color: 'border-blue-500/50 text-blue-300' },
                { id: 'financial', name: '財務諸表論', color: 'border-emerald-500/50 text-emerald-300' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSubjectId(s.id as SubjectId)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition text-left ${
                    subjectId === s.id
                      ? 'bg-slate-800 border-white text-white shadow-sm'
                      : `bg-slate-950 ${s.color} hover:bg-slate-850 opacity-80`
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
          </div>

          {/* Time in minutes */}
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-semibold">学習時間 (分):</label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="5"
                max="600"
                step="5"
                value={minutes}
                onChange={(e) => setMinutes(Number(e.target.value))}
                className="w-28 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-white focus:outline-none focus:border-amber-500"
              />
              <div className="flex items-center gap-1.5">
                {[15, 30, 45, 60, 90].map((quickMin) => (
                  <button
                    key={quickMin}
                    type="button"
                    onClick={() => setMinutes(quickMin)}
                    className="px-2 py-1 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono"
                  >
                    {quickMin}m
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Training type */}
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-semibold">特訓タイプ:</label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: 'theory', label: '理論暗記' },
                { id: 'calc', label: '計算測定' },
                { id: 'anki', label: 'Anki' },
                { id: 'lecture', label: '講義・復習' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setSessionType(t.id as any)}
                  className={`py-1.5 text-xs font-semibold rounded-lg border transition ${
                    sessionType === t.id
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs text-slate-400 block mb-1 font-semibold">メモ・振り返り:</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="例: 均等割の非課税限度額を白紙再現。数字が正確に出るようになった。"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
            >
              キャンセル
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20"
            >
              記録を保存する
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
