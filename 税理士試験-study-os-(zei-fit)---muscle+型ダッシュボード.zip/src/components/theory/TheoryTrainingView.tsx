import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, AlertTriangle, Play, Pause, RotateCcw, 
  Sparkles, Flame, Trophy, Eye, EyeOff, Mic, ChevronRight,
  ChevronDown, Send, Award, Clock, FileText,
  ArrowUpDown, Copy, Check, BookOpen, Layers, ArrowLeft,
  Lock, Unlock, ChevronLeft, Folder, FolderOpen, GitBranch, Star
} from 'lucide-react';
import { TheoryItem, SubjectId, TheorySubSection, TheoryParentSection, FlowStep } from '../../types';
import { firePRCelebration, formatSeconds, formatTimeDigital } from '../../utils/confetti';
import { getJSTDateString, formatCleanPillarHeading, normalizePillarKey } from '../../utils/date';
import { DailyReviewQueue } from './DailyReviewQueue';
import { StorageService } from '../../services/storage';

interface TheoryTrainingViewProps {
  theories: TheoryItem[];
  milestones?: import('../../types').MonthlyMilestone[];
  onUpdateTheory: (updated: TheoryItem) => void;
  onRecordStudyTime: (subjectId: SubjectId, minutes: number, note: string) => void;
  onNavigateToRoadmap?: () => void;
}

export const TheoryTrainingView: React.FC<TheoryTrainingViewProps> = ({
  theories,
  milestones,
  onUpdateTheory,
  onRecordStudyTime,
  onNavigateToRoadmap,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectId>('resident');
  const [selectedTheoryId, setSelectedTheoryId] = useState<string>('');
  const [isDetailOpen, setIsDetailOpen] = useState<boolean>(false);
  const [currentLevel, setCurrentLevel] = useState<number>(1); // Default to Lv.1

  // Sort option: Default to "覚えないといけない順（本試験出題ランキング S→A→B順）"
  const [sortBy, setSortBy] = useState<'priority' | 'number' | 'level_desc' | 'level_asc' | 'revised'>('priority');
  // List layout: 'tree' (大分類[科目] ＞ 中分類[カテゴリ・章] ＞ 小分類[理論]の階層フォルダ) | 'flat' (全論点カード)
  const [listLayout, setListLayout] = useState<'tree' | 'flat'>('tree');
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});
  const [isDRankSectionOpen, setIsDRankSectionOpen] = useState<boolean>(false);

  // Display mode: 'easy' (超日常語訳), 'cloze' (タップ虫食い), 'quiz' (3秒クイズ), 'story' (キャラ図解), 'flow' (構造フロー図), 'structured' (Notionトグル), 'verbatim' (理サブ全文)
  const [viewFormat, setViewFormat] = useState<'easy' | 'cloze' | 'quiz' | 'story' | 'flow' | 'structured' | 'verbatim'>('easy');
  const [copied, setCopied] = useState<boolean>(false);
  const [revealedClozes, setRevealedClozes] = useState<Record<string, boolean>>({});
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});

  // Notion-style toggles state:
  // 1. 大トグル (Level 1 / 理論全体トグル)
  const [isMajorToggleOpen, setIsMajorToggleOpen] = useState<boolean>(true);
  // 2. 中トグル (Level 2 / (1)(2)等の大項目) & 3. 小トグル (Level 3 / 各「柱」[1][2])
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({});
  const [memorizedLocks, setMemorizedLocks] = useState<Record<string, boolean>>({});

  // Stopwatch state
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // User input states
  const [lv1Answer, setLv1Answer] = useState<string>('');
  const [lv2Outlines, setLv2Outlines] = useState<string[]>(['']);
  const [lv3CheckedRequirements, setLv3CheckedRequirements] = useState<Record<number, boolean>>({});
  const [userAnswerText, setUserAnswerText] = useState<string>('');

  // UI display toggles
  const [showStandardAnswer, setShowStandardAnswer] = useState<boolean>(false);
  const [isGrading, setIsGrading] = useState<boolean>(false);
  const [gradeResult, setGradeResult] = useState<any | null>(null);
  const [speechActive, setSpeechActive] = useState<boolean>(false);

  // Filter and sort theories
  const currentSubjectTheories = theories.filter((t) => t.subjectId === selectedSubject);

  const sortedTheories = [...currentSubjectTheories].sort((a, b) => {
    if (sortBy === 'priority') {
      return (a.priorityOrder || 99) - (b.priorityOrder || 99);
    }
    if (sortBy === 'number') {
      return a.theoryNumber.localeCompare(b.theoryNumber, undefined, { numeric: true });
    }
    if (sortBy === 'level_desc') {
      return (b.currentStage || 1) - (a.currentStage || 1);
    }
    if (sortBy === 'level_asc') {
      return (a.currentStage || 1) - (b.currentStage || 1);
    }
    if (sortBy === 'revised') {
      return (b.isRevised2027 ? 1 : 0) - (a.isRevised2027 ? 1 : 0);
    }
    return 0;
  });

  const currentTheoryIndex = sortedTheories.findIndex((t) => t.id === selectedTheoryId);
  const currentTheory = currentTheoryIndex >= 0 ? sortedTheories[currentTheoryIndex] : sortedTheories[0];

  // Helper to extract 3-tier hierarchy: Parent Sections (中トグル) -> Subsections (小トグル 柱)
  const getParentSections = (theory?: TheoryItem): TheoryParentSection[] => {
    if (!theory) return [];
    if (theory.parentSections && theory.parentSections.length > 0) {
      return theory.parentSections;
    }

    if (theory.structuredSubSections && theory.structuredSubSections.length > 0) {
      const groups: Record<string, TheoryParentSection> = {};
      const defaultSubs: TheorySubSection[] = [];

      theory.structuredSubSections.forEach((sub, idx) => {
        // Group by (1), (2) or 〔1〕, 〔2〕
        const match = sub.num.match(/^(\([0-9]+\)|〔[0-9]+〕|【[0-9]+】)/);
        if (match) {
          const pNum = match[1];
          if (!groups[pNum]) {
            // Lookup full parent heading from lv2Outline or predefined headings
            const outlineMatch = theory.lv2Outline?.find(l => l.startsWith(pNum));
            let fullHeading = outlineMatch ? outlineMatch.replace(/^(\([0-9]+\)|〔[0-9]+〕|【[0-9]+】)\s*/, '') : '';
            if (!fullHeading) {
              if (pNum === '(1)') fullHeading = '個人住民税における「住所」の意義及びその認定の方法';
              else if (pNum === '(2)') fullHeading = '均等割及び所得割の趣旨、課税・徴収・税率・非課税（所得税相違点）';
              else fullHeading = sub.heading;
            }

            groups[pNum] = {
              id: `p-${pNum}-${idx}`,
              num: pNum,
              heading: fullHeading,
              subSections: [],
            };
          }
          groups[pNum].subSections.push(sub);
        } else {
          defaultSubs.push(sub);
        }
      });

      const list = Object.values(groups);
      if (defaultSubs.length > 0) {
        list.unshift({
          id: 'p-default',
          num: '〔1〕',
          heading: '本問の主要柱構成',
          subSections: defaultSubs,
        });
      }
      return list.length > 0 ? list : [
        {
          id: 'p-all',
          num: '〔1〕',
          heading: '本問の主要柱構成',
          subSections: theory.structuredSubSections,
        }
      ];
    }

    return [
      {
        id: 'p-outline',
        num: '〔1〕',
        heading: '答案構成・柱一覧',
        subSections: theory.lv2Outline.map((line, idx) => ({
          num: `[${idx + 1}]`,
          heading: line,
          body: line,
        })),
      },
    ];
  };

  const parentSectionsList = getParentSections(currentTheory);
  const totalPillarsCount = parentSectionsList.reduce((acc, p) => acc + p.subSections.length, 0);

  useEffect(() => {
    if (sortedTheories.length > 0 && (!selectedTheoryId || !sortedTheories.some(t => t.id === selectedTheoryId))) {
      setSelectedTheoryId(sortedTheories[0].id);
    }
  }, [selectedSubject, sortBy, theories]);

  // Reset training & toggle state when switching theory
  useEffect(() => {
    if (currentTheory) {
      setTimerSeconds(0);
      setIsTimerRunning(false);
      setLv1Answer('');
      setLv2Outlines(['']);
      setLv3CheckedRequirements({});
      setUserAnswerText('');
      setShowStandardAnswer(false);
      setGradeResult(null);
      setCopied(false);
      setRevealedClozes({});
      setQuizAnswers({});

      // Default: 大トグル is open, 中トグル are open, 柱 toggles can be opened by default or on-demand
      setIsMajorToggleOpen(true);
      const defaultOpens: Record<string, boolean> = {};
      const parents = getParentSections(currentTheory);
      parents.forEach((_, pIdx) => {
        defaultOpens[`parent-${pIdx}`] = true;
      });
      setOpenSections(defaultOpens);
    }
  }, [selectedTheoryId]);

  // Timer runner
  useEffect(() => {
    if (isTimerRunning) {
      timerRef.current = setInterval(() => {
        setTimerSeconds((prev) => prev + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isTimerRunning]);

  const toggleTimer = () => setIsTimerRunning(!isTimerRunning);
  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimerSeconds(0);
  };

  const copyVerbatimText = () => {
    if (!currentTheory) return;
    navigator.clipboard.writeText(currentTheory.lv4FullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const addOutlineRow = () => setLv2Outlines([...lv2Outlines, '']);
  const updateOutlineRow = (index: number, val: string) => {
    const copy = [...lv2Outlines];
    copy[index] = val;
    setLv2Outlines(copy);
  };

  // Toggle specific accordion item (either parent or child 柱)
  const toggleAccordion = (key: string) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Expand all toggles (大トグル・中トグル・小トグルすべて展開)
  const expandAllToggles = () => {
    setIsMajorToggleOpen(true);
    const opens: Record<string, boolean> = {};
    parentSectionsList.forEach((p, pIdx) => {
      opens[`parent-${pIdx}`] = true;
      p.subSections.forEach((_, sIdx) => {
        opens[`child-${pIdx}-${sIdx}`] = true;
      });
    });
    opens['diag'] = true;
    opens['diff'] = true;
    setOpenSections(opens);
  };

  // Open up to 中トグル only (Hide all 柱 for testing recall!)
  const collapseOnlyPillars = () => {
    setIsMajorToggleOpen(true);
    const opens: Record<string, boolean> = {};
    parentSectionsList.forEach((_, pIdx) => {
      opens[`parent-${pIdx}`] = true;
    });
    setOpenSections(opens);
  };

  // Collapse everything completely
  const collapseAllToggles = () => {
    setIsMajorToggleOpen(false);
    setOpenSections({});
  };

  // Cloze handlers
  const revealAllClozes = () => {
    const revealed: Record<string, boolean> = {};
    if (currentTheory) {
      (currentTheory.clozeKeywords || []).forEach((k) => {
        revealed[k] = true;
      });
      // Also mark any individual cloze keys
      parentSectionsList.forEach((p, pIdx) => {
        p.subSections.forEach((s, sIdx) => {
          (currentTheory.clozeKeywords || []).forEach((k) => {
            revealed[`${pIdx}-${sIdx}-${k}`] = true;
          });
        });
      });
    }
    setRevealedClozes(revealed);
  };

  const hideAllClozes = () => {
    setRevealedClozes({});
  };

  const handleQuizOptionSelect = (qId: string, optIdx: number, correctIdx: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qId]: optIdx }));
    if (optIdx === correctIdx) {
      firePRCelebration();
    }
  };

  // Helper to render interactive cloze tap buttons in text
  const renderClozeText = (text: string, keywords: string[] = [], pKey: string) => {
    if (!keywords || keywords.length === 0) return text;
    const sortedKeywords = [...keywords].sort((a, b) => b.length - a.length);
    const pattern = new RegExp(`(${sortedKeywords.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'g');
    const parts = text.split(pattern);

    return parts.map((part, idx) => {
      if (keywords.includes(part)) {
        const clozeKey = `${pKey}-${part}`;
        const isRevealed = !!revealedClozes[clozeKey] || !!revealedClozes[part];
        return (
          <button
            key={idx}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setRevealedClozes((prev) => ({ ...prev, [clozeKey]: !isRevealed, [part]: !isRevealed }));
            }}
            className={`mx-0.5 my-0.5 px-2 py-0.5 rounded font-bold text-[11px] sm:text-xs transition-all active:scale-95 inline-flex items-center select-none ${
              isRevealed
                ? 'bg-amber-500/25 text-amber-200 border border-amber-500/60 shadow-sm'
                : 'bg-slate-800 text-amber-400 border border-amber-500/40 hover:bg-slate-750 shadow-inner'
            }`}
            title={isRevealed ? 'タップで隠す' : 'タップでめくる！'}
          >
            {isRevealed ? part : '❓ めくる'}
          </button>
        );
      }
      return part;
    });
  };

  // 1, 3, 4 Linked Pillar State Helper (User actions including ❌ downgrades ALWAYS override baseline defaults)
  const getPillarState = (
    theory: TheoryItem,
    pillarKey: string,
    initialStatus?: 'mastered' | 'learning' | 'weak'
  ): { status: 'mastered' | 'learning' | 'weak'; lockCount: number } => {
    const normKey = normalizePillarKey(pillarKey);
    const pStat = theory.pillarStatuses?.[pillarKey] || theory.pillarStatuses?.[normKey];
    const vault = StorageService.getPillarVault();
    const vEntry = vault[`${theory.id}::${pillarKey}`] || vault[`${theory.id}::${normKey}`];

    if (vEntry && vEntry.isUserAction) {
      if (pStat && pStat.isUserAction === true && (pStat.updatedAt || 0) >= (vEntry.updatedAt || 0)) {
        return { status: pStat.status, lockCount: pStat.lockCount };
      }
      return { status: vEntry.status, lockCount: vEntry.lockCount };
    }
    if (pStat && pStat.isUserAction === true) {
      return { status: pStat.status, lockCount: pStat.lockCount };
    }
    const fallbackStatus = pStat?.status || initialStatus || 'weak';
    const fallbackLocks =
      pStat?.lockCount ?? (fallbackStatus === 'mastered' ? 2 : fallbackStatus === 'learning' ? 1 : 0);
    return {
      status: fallbackStatus,
      lockCount: fallbackLocks,
    };
  };

  // Helper to calculate stage from pillar statuses (bidirectional link: downgrading ◎ -> ○/❌ lowers stage!)
  const calculateStageFromPillars = (
    theory: TheoryItem,
    pillarStatuses: Record<string, { status: 'mastered' | 'learning' | 'weak'; lockCount: number }>
  ): number => {
    const parents = getParentSections(theory);
    let totalPillars = 0;
    let masteredCount = 0;
    let weakCount = 0;

    parents.forEach((p) => {
      p.subSections.forEach((s) => {
        totalPillars++;
        const normH = normalizePillarKey(s.heading);
        const state = pillarStatuses[s.heading] || pillarStatuses[normH] || getPillarState(theory, s.heading, s.status);
        if (state.status === 'mastered') {
          masteredCount++;
        } else if (state.status !== 'learning') {
          weakCount++;
        }
      });
    });

    if (totalPillars === 0) return theory.currentStage || 1;

    const current = theory.currentStage || 1;

    // All pillars are ◎ (mastered): Lv.3+, preserve Lv.4/Lv.5 if achieved
    if (masteredCount === totalPillars) {
      return Math.max(3, current);
    }

    // All pillars are at least ○ (no ❌ weak pillars), but not all ◎ -> strictly Lv.2
    if (weakCount === 0) {
      return 2;
    }

    // Any ❌ weak pillar present -> Lv.1
    return 1;
  };

  // Update a 柱's status & lockCount, then persist and bidirectionally update theory currentStage
  const updatePillarState = (
    theory: TheoryItem,
    pillarKey: string,
    newStatus: 'mastered' | 'learning' | 'weak',
    newLockCount: number
  ) => {
    // Preserve all existing pillar states across all pillars in the theory without marking untouched baseline pillars as user actions
    const parents = getParentSections(theory);
    const existingStatuses: Record<
      string,
      { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }
    > = {
      ...(theory.pillarStatuses || {}),
    };

    parents.forEach((p) => {
      p.subSections.forEach((s) => {
        if (!existingStatuses[s.heading]) {
          const st = getPillarState(theory, s.heading, s.status);
          existingStatuses[s.heading] = {
            ...st,
            updatedAt: 0,
            isUserAction: false,
          };
        }
      });
    });

    const now = Date.now();
    const normKey = normalizePillarKey(pillarKey);
    const updatedStatuses = {
      ...existingStatuses,
      [pillarKey]: {
        status: newStatus,
        lockCount: newLockCount,
        updatedAt: now,
        isUserAction: true,
      },
      [normKey]: {
        status: newStatus,
        lockCount: newLockCount,
        updatedAt: now,
        isUserAction: true,
      },
    };

    // Save directly to the persistent Vault
    StorageService.recordPillarTap(theory.id, pillarKey, newStatus, newLockCount);

    const newStage = calculateStageFromPillars(theory, updatedStatuses);

    const updatedTheory: TheoryItem = {
      ...theory,
      pillarStatuses: updatedStatuses,
      currentStage: newStage,
    };

    onUpdateTheory(updatedTheory);
  };

  // Bidirectional Level Progression & Rollback Toggle Handler (Lv.1 〜 Lv.5)
  const handleToggleStage = (targetStage: number) => {
    if (!currentTheory) return;
    const current = currentTheory.currentStage || 1;

    let nextStage = targetStage;
    if (current === targetStage) {
      nextStage = Math.max(1, current - 1);
    }

    const now = Date.now();
    const parents = getParentSections(currentTheory);
    const updatedStatuses: Record<
      string,
      { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }
    > = {
      ...(currentTheory.pillarStatuses || {}),
    };
    const vaultBatch: Array<{ pillarKey: string; status: 'mastered' | 'learning' | 'weak'; lockCount: number }> = [];

    parents.forEach((p) => {
      p.subSections.forEach((s) => {
        const status: 'mastered' | 'learning' | 'weak' =
          nextStage >= 3 ? 'mastered' : nextStage === 2 ? 'learning' : 'weak';
        const lockCount = nextStage >= 3 ? 2 : nextStage === 2 ? 1 : 0;
        updatedStatuses[s.heading] = {
          status,
          lockCount,
          updatedAt: now,
          isUserAction: true,
        };
        vaultBatch.push({ pillarKey: s.heading, status, lockCount });
      });
    });

    // Persist batch stage rollback/advance into Vault so ◎ never resurrects
    StorageService.recordBatchPillarTaps(currentTheory.id, vaultBatch);

    const updatedTheory: TheoryItem = {
      ...currentTheory,
      currentStage: nextStage,
      pillarStatuses: updatedStatuses,
    };

    onUpdateTheory(updatedTheory);

    if (nextStage >= 3 && nextStage > current) {
      firePRCelebration();
    }
  };

  // [案1 & 3] Lock button click handler: 0 (❌) -> 1 (○) -> 2 (◎) -> unlock (○)
  const handleLockClick = (pillarKey: string, childKey: string, initialStatus?: any) => {
    if (!currentTheory) return;
    const current = getPillarState(currentTheory, pillarKey, initialStatus);

    if (current.lockCount === 0) {
      // Step 1: 1st lock -> ○ (1 rep) & auto-close toggle
      updatePillarState(currentTheory, pillarKey, 'learning', 1);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
    } else if (current.lockCount === 1) {
      // Step 2: 2nd lock -> ◎ (2 reps streak! 完璧・炎点灯) & auto-close
      updatePillarState(currentTheory, pillarKey, 'mastered', 2);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
      firePRCelebration();
    } else {
      // If already ◎, tapping unlock drops back to ○ and opens toggle for review
      updatePillarState(currentTheory, pillarKey, 'learning', 1);
      setOpenSections((prev) => ({ ...prev, [childKey]: true }));
    }
  };

  // Direct Status Setter: select ❌, ○, or ◎ with toggle rollback
  const handleDirectSetPillarStatus = (
    pillarKey: string,
    childKey: string,
    targetStatus: 'mastered' | 'learning' | 'weak',
    initialStatus?: any
  ) => {
    if (!currentTheory) return;
    const current = getPillarState(currentTheory, pillarKey, initialStatus);

    // If clicking current status, toggle rollback to previous status
    if (current.status === targetStatus) {
      if (targetStatus === 'mastered') {
        // ◎ -> rollback to ○
        updatePillarState(currentTheory, pillarKey, 'learning', 1);
        setOpenSections((prev) => ({ ...prev, [childKey]: true }));
      } else if (targetStatus === 'learning') {
        // ○ -> rollback to ❌
        updatePillarState(currentTheory, pillarKey, 'weak', 0);
        setOpenSections((prev) => ({ ...prev, [childKey]: true }));
      }
      return;
    }

    if (targetStatus === 'mastered') {
      updatePillarState(currentTheory, pillarKey, 'mastered', 2);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
      firePRCelebration();
    } else if (targetStatus === 'learning') {
      updatePillarState(currentTheory, pillarKey, 'learning', 1);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
    } else {
      updatePillarState(currentTheory, pillarKey, 'weak', 0);
      setOpenSections((prev) => ({ ...prev, [childKey]: true }));
    }
  };

  // [案3] Direct Badge Click: Cycle ❌ -> ○ -> ◎ -> ❌
  const handleBadgeClick = (pillarKey: string, childKey: string, initialStatus?: any) => {
    if (!currentTheory) return;
    const current = getPillarState(currentTheory, pillarKey, initialStatus);

    if (current.status === 'weak') {
      updatePillarState(currentTheory, pillarKey, 'learning', 1);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
    } else if (current.status === 'learning') {
      updatePillarState(currentTheory, pillarKey, 'mastered', 2);
      setOpenSections((prev) => ({ ...prev, [childKey]: false }));
      firePRCelebration();
    } else {
      updatePillarState(currentTheory, pillarKey, 'weak', 0);
      setOpenSections((prev) => ({ ...prev, [childKey]: true }));
    }
  };

  // Opening/closing a toggle is purely for viewing/studying (NEVER downgrades evaluation!)
  const handleTogglePillar = (childKey: string) => {
    setOpenSections((prev) => ({ ...prev, [childKey]: !prev[childKey] }));
  };

  // Helper to get total counts of ◎, ○, ❌ for a theory
  const getTheoryPillarStats = (theory: TheoryItem) => {
    const parents = getParentSections(theory);
    let total = 0;
    let mastered = 0;
    let learning = 0;
    let weak = 0;

    parents.forEach((p) => {
      p.subSections.forEach((s) => {
        total++;
        const pState = getPillarState(theory, s.heading, s.status);
        if (pState.status === 'mastered') mastered++;
        else if (pState.status === 'learning') learning++;
        else weak++;
      });
    });

    return { total, mastered, learning, weak };
  };

  // Speech recognition for "つぶやき・歩きながら暗唱"
  const startSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('お使いのブラウザは音声認識に対応していません。Google ChromeやSafariをご利用ください。');
      return;
    }
    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ja-JP';
      recognition.interimResults = true;
      recognition.continuous = true;

      recognition.onstart = () => setSpeechActive(true);
      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setUserAnswerText((prev) => prev + ' ' + transcript);
      };
      recognition.onerror = () => setSpeechActive(false);
      recognition.onend = () => setSpeechActive(false);
      recognition.start();
    } catch (e) {
      setSpeechActive(false);
    }
  };

  // Execute Gemini AI Strict Theory Grading
  const handleAIGrading = async () => {
    if (!currentTheory) return;
    const answerToGrade =
      currentLevel === 1
        ? lv1Answer
        : currentLevel === 2
        ? lv2Outlines.filter(Boolean).join('\n')
        : userAnswerText;

    if (!answerToGrade.trim()) {
      alert('採点する答案またはキーワードを入力してください。');
      return;
    }

    setIsGrading(true);
    setIsTimerRunning(false);

    try {
      const previousLog = currentTheory.history.length > 0 ? currentTheory.history[currentTheory.history.length - 1] : null;

      const response = await fetch('/api/ai/grade-theory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          theoryTitle: currentTheory.title,
          standardAnswer: currentTheory.lv4FullText,
          keyRequirements: currentTheory.lv3KeyRequirements,
          userAnswer: answerToGrade,
          targetLevel: currentLevel,
          previousAttempt: previousLog,
        }),
      });

      if (!response.ok) {
        throw new Error('AI採点リクエストに失敗しました。');
      }

      const result = await response.json();
      setGradeResult(result);

      const isPR = currentTheory.bestScore === 0 ? result.score >= 60 : result.score > currentTheory.bestScore;
      if (isPR) {
        firePRCelebration();
      }

      // [案4] Gemini AI Grading auto-sync with 柱 toggles!
      const missingDefects = [
        ...(result.defectBreakdown?.requirementsMissing || []),
        ...(result.defectBreakdown?.numbersOrDatesWrong || []),
        ...(result.defectBreakdown?.titleMissing || []),
        ...(result.defectBreakdown?.crucialKeywordsMissing || []),
      ];

      const now = Date.now();
      const newPillarStatuses = { ...(currentTheory.pillarStatuses || {}) };
      const autoOpens: Record<string, boolean> = { ...openSections };
      const vaultBatch: Array<{ pillarKey: string; status: 'mastered' | 'learning' | 'weak'; lockCount: number }> = [];

      parentSectionsList.forEach((parent, pIdx) => {
        parent.subSections.forEach((sec, sIdx) => {
          const pKey = sec.heading;
          const childKey = `child-${pIdx}-${sIdx}`;
          const currentPillar = getPillarState(currentTheory, pKey, sec.status);

          // Check if this pillar has missing items
          const isFailed = missingDefects.some(
            (defect) =>
              defect.toLowerCase().includes(sec.heading.toLowerCase()) ||
              sec.heading.toLowerCase().includes(defect.toLowerCase()) ||
              (sec.keyPoints && sec.keyPoints.some((kp) => defect.toLowerCase().includes(kp.toLowerCase())))
          );

          if (isFailed) {
            newPillarStatuses[pKey] = { status: 'weak', lockCount: 0, updatedAt: now, isUserAction: true };
            vaultBatch.push({ pillarKey: pKey, status: 'weak', lockCount: 0 });
            autoOpens[childKey] = true;
          } else if (result.score >= 70) {
            if (currentPillar.lockCount === 0) {
              newPillarStatuses[pKey] = { status: 'learning', lockCount: 1, updatedAt: now, isUserAction: true };
              vaultBatch.push({ pillarKey: pKey, status: 'learning', lockCount: 1 });
              autoOpens[childKey] = false;
            } else if (currentPillar.lockCount === 1) {
              newPillarStatuses[pKey] = { status: 'mastered', lockCount: 2, updatedAt: now, isUserAction: true };
              vaultBatch.push({ pillarKey: pKey, status: 'mastered', lockCount: 2 });
              autoOpens[childKey] = false;
            }
          }
        });
      });
      if (vaultBatch.length > 0) {
        StorageService.recordBatchPillarTaps(currentTheory.id, vaultBatch);
      }
      setOpenSections(autoOpens);

      const todayJst = getJSTDateString();
      const newLog = {
        id: 'th-log-' + Date.now(),
        date: todayJst,
        level: currentLevel,
        timeSeconds: timerSeconds,
        score: result.score || 0,
        reproductionRate: result.reproductionRate || result.score || 0,
        isPersonalBest: isPR,
        missingItems: [
          ...(result.defectBreakdown?.requirementsMissing || []),
          ...(result.defectBreakdown?.numbersOrDatesWrong || []),
        ],
        feedback: result.summaryComment,
      };

      const updatedTheory: TheoryItem = {
        ...currentTheory,
        pillarStatuses: newPillarStatuses,
        bestScore: Math.max(currentTheory.bestScore, result.score || 0),
        bestTimeSeconds:
          currentTheory.bestTimeSeconds === 0
            ? timerSeconds
            : Math.min(currentTheory.bestTimeSeconds, timerSeconds || 9999),
        currentStage: calculateStageFromPillars(
          { ...currentTheory, currentStage: Math.max(currentTheory.currentStage, result.score >= 80 ? currentLevel + 1 : currentLevel) },
          newPillarStatuses
        ),
        lastPracticed: todayJst,
        history: [...currentTheory.history, newLog],
      };

      onUpdateTheory(updatedTheory);

      if (timerSeconds >= 60) {
        onRecordStudyTime(
          selectedSubject,
          Math.round(timerSeconds / 60),
          `理論特訓 Lv.${currentLevel}「${currentTheory.theoryNumber} ${currentTheory.title}」スコア:${result.score}点`
        );
      }
    } catch (error: any) {
      setGradeResult({
        score: 0,
        isPass: false,
        summaryComment: `採点エラー: ${error?.message || '通信に失敗しました'}`,
        defectBreakdown: {},
      });
    } finally {
      setIsGrading(false);
    }
  };

  // Self grading button
  const handleSelfGrade = (score: number) => {
    if (!currentTheory) return;
    const isPR = currentTheory.bestScore === 0 ? score >= 60 : score > currentTheory.bestScore;
    if (isPR) firePRCelebration();

    const todayJst = getJSTDateString();
    const newLog = {
      id: 'th-log-' + Date.now(),
      date: todayJst,
      level: currentLevel,
      timeSeconds: timerSeconds,
      score,
      reproductionRate: score,
      isPersonalBest: isPR,
      feedback: '自己採点による記録',
    };

    const updatedTheory: TheoryItem = {
      ...currentTheory,
      bestScore: Math.max(currentTheory.bestScore, score),
      bestTimeSeconds:
        currentTheory.bestTimeSeconds === 0
          ? timerSeconds
          : Math.min(currentTheory.bestTimeSeconds, timerSeconds || 9999),
      currentStage: Math.max(currentTheory.currentStage, score >= 80 ? currentLevel + 1 : currentLevel),
      lastPracticed: todayJst,
      history: [...currentTheory.history, newLog],
    };

    onUpdateTheory(updatedTheory);
    if (timerSeconds >= 60) {
      onRecordStudyTime(
        selectedSubject,
        Math.round(timerSeconds / 60),
        `理論自己採点 Lv.${currentLevel}「${currentTheory.theoryNumber} ${currentTheory.title}」`
      );
    }
  };

  // Navigation handlers
  const handlePrevTheory = () => {
    if (currentTheoryIndex > 0) {
      setSelectedTheoryId(sortedTheories[currentTheoryIndex - 1].id);
    }
  };

  const handleNextTheory = () => {
    if (currentTheoryIndex < sortedTheories.length - 1) {
      setSelectedTheoryId(sortedTheories[currentTheoryIndex + 1].id);
    }
  };

  // Stage color configuration based on user request: "⭐︎の段階でいろわけしてもいいかも"
  const getStageConfig = (stage: number = 1) => {
    const current = Math.min(Math.max(stage || 1, 1), 5);
    switch (current) {
      case 5:
        return {
          level: 5,
          title: 'Lv.5 本試験完成',
          shortTitle: '完成★5',
          starColor: 'text-yellow-300 fill-yellow-300 drop-shadow-[0_0_6px_rgba(253,224,71,0.9)]',
          badgeBg: 'bg-gradient-to-r from-yellow-500/20 via-amber-500/25 to-yellow-500/20 text-yellow-200 border border-yellow-400/60 shadow-md shadow-yellow-500/15',
          textBadge: 'text-yellow-300 font-black',
        };
      case 4:
        return {
          level: 4,
          title: 'Lv.4 白紙再現',
          shortTitle: '白紙★4',
          starColor: 'text-orange-400 fill-orange-400 drop-shadow-[0_0_5px_rgba(251,146,60,0.8)]',
          badgeBg: 'bg-orange-950/60 text-orange-300 border border-orange-700/60 shadow-sm',
          textBadge: 'text-orange-300 font-extrabold',
        };
      case 3:
        return {
          level: 3,
          title: 'Lv.3 規範要件',
          shortTitle: '要件★3',
          starColor: 'text-amber-400 fill-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.6)]',
          badgeBg: 'bg-amber-950/60 text-amber-300 border border-amber-800/60 shadow-sm',
          textBadge: 'text-amber-300 font-bold',
        };
      case 2:
        return {
          level: 2,
          title: 'Lv.2 柱完成',
          shortTitle: '柱★2',
          starColor: 'text-emerald-400 fill-emerald-400 drop-shadow-[0_0_4px_rgba(52,211,153,0.6)]',
          badgeBg: 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 shadow-sm',
          textBadge: 'text-emerald-300 font-bold',
        };
      case 1:
      default:
        return {
          level: 1,
          title: 'Lv.1 未着手・趣旨',
          shortTitle: '始動★1',
          starColor: 'text-cyan-400 fill-cyan-400/80 drop-shadow-[0_0_3px_rgba(34,211,238,0.5)]',
          badgeBg: 'bg-cyan-950/40 text-cyan-300 border border-cyan-800/40 shadow-sm',
          textBadge: 'text-cyan-300 font-medium',
        };
    }
  };

  // Render color-coded 5 stars
  const renderStars = (stage: number = 1, showLabel: boolean = true) => {
    const current = Math.min(Math.max(stage || 1, 1), 5);
    const cfg = getStageConfig(current);

    return (
      <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-lg border font-mono text-[10px] font-bold ${cfg.badgeBg}`}>
        <div className="flex items-center gap-0.5">
          {[1, 2, 3, 4, 5].map((s) => (
            <Star
              key={s}
              className={`w-3 h-3 ${
                s <= current
                  ? cfg.starColor
                  : 'text-slate-800 fill-slate-900/60'
              }`}
            />
          ))}
        </div>
        {showLabel && <span className={cfg.textBadge}>{cfg.shortTitle}</span>}
      </div>
    );
  };

  // Separate active theories (S/A/B) from D-rank theories (recently tested in R7 75th / R8 76th / Re-exam)
  const activeTheories = sortedTheories.filter((t) => t.priorityRank !== 'D');
  const dRankTheories = sortedTheories.filter((t) => t.priorityRank === 'D');

  // Group active theories by category for hierarchical tree structure (1 -> 2 -> 3 -> 4 -> 5 -> 6)
  const categoriesList = Array.from(new Set(activeTheories.map((t) => t.category || '主要論点'))).sort((a, b) => {
    return a.localeCompare(b, undefined, { numeric: true });
  });
  const groupedTheories = categoriesList.reduce((acc, cat) => {
    acc[cat] = activeTheories.filter((t) => (t.category || '主要論点') === cat);
    return acc;
  }, {} as Record<string, TheoryItem[]>);

  // Render individual theory card with color-coded stars and honest indicators
  const renderTheoryCard = (theory: TheoryItem) => {
    const hasPB = theory.bestScore > 0;
    const stats = getTheoryPillarStats(theory);

    return (
      <div
        key={theory.id}
        onClick={() => {
          setSelectedTheoryId(theory.id);
          setIsDetailOpen(true);
        }}
        className="p-4 rounded-2xl border text-left cursor-pointer transition-all bg-slate-900/70 border-slate-800 hover:bg-slate-900 hover:border-amber-500/70 hover:shadow-xl hover:shadow-amber-500/5 group relative overflow-hidden flex flex-col justify-between"
      >
        <div>
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs font-mono font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-md">
                {theory.theoryNumber}
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                  theory.priorityRank === 'S'
                    ? 'bg-rose-950 text-rose-300 border border-rose-800/80'
                    : theory.priorityRank === 'A'
                    ? 'bg-amber-950 text-amber-300 border border-amber-800/80'
                    : theory.priorityRank === 'D'
                    ? 'bg-slate-900 text-slate-400 border border-slate-700/80'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {theory.priorityRank}ランク
              </span>
              {theory.subCategory && (
                <span className="text-[10px] font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-700/60 px-1.5 py-0.5 rounded">
                  {theory.subCategory}
                </span>
              )}
              {theory.isRevised2027 && (
                <span className="text-[10px] font-bold text-pink-400 bg-pink-950/70 border border-pink-800/70 px-1.5 py-0.5 rounded">
                  '27改正
                </span>
              )}
            </div>

            {/* 段階別色分け星評価バッジ (Lv.1水色 → Lv.2緑 → Lv.3黄色 → Lv.4橙 → Lv.5金) */}
            {renderStars(theory.currentStage || 1)}
          </div>

          <h4 className="text-sm sm:text-base font-extrabold text-white leading-snug group-hover:text-amber-300 transition-colors">
            {theory.title}
          </h4>

          <div className="mt-2 text-xs text-rose-300 font-bold line-clamp-1">
            {theory.examRankNote}
          </div>

          {/* 柱の暗記進捗ステータス (◎, ○, ❌) */}
          <div className="mt-2 flex items-center gap-2 text-[10px] font-mono bg-slate-950/80 px-2.5 py-1 rounded-lg border border-slate-850">
            <span className="text-emerald-400 font-bold">◎ {stats.mastered}</span>
            <span className="text-amber-400 font-bold">○ {stats.learning}</span>
            <span className="text-rose-400 font-bold">❌ {stats.weak}</span>
            <span className="text-slate-500">/ 全{stats.total}柱</span>
          </div>

          {theory.mnemonics && theory.mnemonics.length > 0 && (
            <div className="mt-2 text-[11px] text-slate-300 bg-slate-950/70 p-2 rounded-lg border border-slate-800/80 line-clamp-1">
              <span className="text-amber-400 font-bold">語呂:</span> {theory.mnemonics[0]}
            </div>
          )}
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
          <div className="text-slate-400">
            自己ベスト:{' '}
            {hasPB ? (
              <span className="font-bold text-emerald-400 tabular-nums">
                {theory.bestScore}点
              </span>
            ) : (
              <span className="text-slate-500 font-normal">未計測 (本日始動)</span>
            )}
          </div>
          <div className="flex items-center gap-1 text-amber-400 font-bold text-xs group-hover:translate-x-0.5 transition-transform">
            <span>開く・特訓</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Subject Filter Bar (Always visible) */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-800">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800">
          <button
            onClick={() => {
              setSelectedSubject('resident');
              setIsDetailOpen(false);
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              selectedSubject === 'resident'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            住民税（本命・絶対合格）
          </button>
          <button
            onClick={() => {
              setSelectedSubject('liquor');
              setIsDetailOpen(false);
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              selectedSubject === 'liquor'
                ? 'bg-pink-600 text-white shadow-md shadow-pink-600/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            酒税法（理論先行）
          </button>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <ArrowUpDown className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">並び替え:</span>
          </span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 text-xs font-bold text-amber-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-500 max-w-[240px] sm:max-w-none truncate"
          >
            <option value="priority">🔥 覚えるべき優先順（出題実績S→A→B）</option>
            <option value="level_desc">⭐ 習得度順（完成★5 → 未着手★1）</option>
            <option value="level_asc">⭐ 習得度順（未着手★1 → 完成★5）</option>
            <option value="number">理論テキスト番号順 (1-1, 1-2, 2-1...)</option>
            <option value="revised">'27最新法改正優先</option>
          </select>
        </div>
      </div>

      {/* ========================================================= */}
      {/* VIEW 1: THEORY LIST VIEW (!isDetailOpen)                  */}
      {/* 階層型トグル構造（大分類[科目] ＞ 中分類[カテゴリ] ＞ 小分類[理論]） */}
      {/* ========================================================= */}
      {!isDetailOpen && (
        <div className="space-y-4">
          {/* 完全自動復習システム (本日のメニュー 3問 / 目安15分) */}
          <DailyReviewQueue
            theories={theories}
            selectedSubject={selectedSubject}
            milestones={milestones}
            onUpdateTheory={onUpdateTheory}
            onRecordStudyTime={onRecordStudyTime}
            getPillarState={getPillarState}
            updatePillarState={updatePillarState}
            onSelectTheory={(theoryId) => {
              setSelectedTheoryId(theoryId);
              setIsDetailOpen(true);
            }}
            onNavigateToRoadmap={onNavigateToRoadmap}
          />

          {/* Sub Header Bar: Layout Selector & Hierarchy Info */}
          <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-semibold flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-white font-bold flex items-center gap-1.5 flex-wrap">
                <span>{selectedSubject === 'resident' ? '🏛️ 住民税' : '🍶 酒税法'} 論点体系</span>
                <span className="font-mono text-amber-400 font-bold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/50">
                  重点 {activeTheories.length}論点
                </span>
                {dRankTheories.length > 0 && (
                  <span className="font-mono text-slate-400 font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    ＋Dランク(直近出題済) {dRankTheories.length}論点
                  </span>
                )}
              </span>
            </div>

            {/* Tree vs Flat toggle & Folder Controls */}
            <div className="flex items-center gap-2">
              <div className="flex items-center p-0.5 bg-slate-900 rounded-lg border border-slate-800">
                <button
                  onClick={() => setListLayout('tree')}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition flex items-center gap-1 ${
                    listLayout === 'tree'
                      ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="大分類(科目) ＞ 中分類(章・カテゴリ) ＞ 小分類(理論) の階層フォルダ表示"
                >
                  <Folder className="w-3.5 h-3.5" />
                  <span>階層フォルダ</span>
                </button>
                <button
                  onClick={() => setListLayout('flat')}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition flex items-center gap-1 ${
                    listLayout === 'flat'
                      ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="全論点をフラットなカード一覧で表示"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>全件カード</span>
                </button>
              </div>

              {listLayout === 'tree' && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      const allOpen: Record<string, boolean> = {};
                      categoriesList.forEach((c) => {
                        allOpen[c] = true;
                      });
                      setOpenCategories(allOpen);
                    }}
                    className="px-2 py-1 text-[10px] font-bold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 rounded-md transition"
                  >
                    全展開
                  </button>
                  <button
                    onClick={() => {
                      const allClosed: Record<string, boolean> = {};
                      categoriesList.forEach((c) => {
                        allClosed[c] = false;
                      });
                      setOpenCategories(allClosed);
                    }}
                    className="px-2 py-1 text-[10px] font-bold text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded-md transition"
                  >
                    全閉じる
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* 1. 階層フォルダ表示モード (大分類 ＞ 中分類 ＞ 小分類) */}
          {listLayout === 'tree' ? (
            <div className="space-y-3">
              {categoriesList.map((catName) => {
                const catTheories = groupedTheories[catName] || [];
                const isCatOpen = openCategories[catName] !== false; // Default open
                const catMastered = catTheories.reduce((sum, t) => sum + getTheoryPillarStats(t).mastered, 0);
                const catTotal = catTheories.reduce((sum, t) => sum + getTheoryPillarStats(t).total, 0);
                const avgStage = (
                  catTheories.reduce((sum, t) => sum + (t.currentStage || 1), 0) / (catTheories.length || 1)
                ).toFixed(1);

                return (
                  <div
                    key={catName}
                    className="rounded-2xl border border-slate-800/90 bg-slate-900/40 overflow-hidden shadow-lg transition-all"
                  >
                    {/* 中分類 (カテゴリ・章) フォルダトグルヘッダー */}
                    <div
                      onClick={() =>
                        setOpenCategories((prev) => ({
                          ...prev,
                          [catName]: !isCatOpen,
                        }))
                      }
                      className="p-3 sm:p-3.5 flex items-center justify-between cursor-pointer select-none bg-slate-900/90 hover:bg-slate-850 border-b border-slate-800/80 transition gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="text-amber-400">
                          {isCatOpen ? (
                            <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
                          ) : (
                            <Folder className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                        </span>
                        <h3 className="text-xs sm:text-sm font-extrabold text-white truncate">
                          {catName}
                        </h3>
                        <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-950/70 px-2 py-0.5 rounded border border-amber-800/50 shrink-0">
                          {catTheories.length}論点
                        </span>
                      </div>

                      <div className="flex items-center gap-2.5 shrink-0">
                        {/* フォルダ内の進捗概要 */}
                        <div className="hidden sm:flex items-center gap-2 text-[10px] font-mono bg-slate-950/80 px-2.5 py-1 rounded-lg border border-slate-850">
                          <span className="text-amber-300 font-bold">★平均 {avgStage}</span>
                          <span className="text-slate-600">|</span>
                          <span className="text-emerald-400 font-bold">◎ {catMastered}</span>
                          <span className="text-slate-500">/ {catTotal}柱</span>
                        </div>

                        <span className="text-xs text-amber-400">
                          {isCatOpen ? (
                            <ChevronDown className="w-4 h-4 text-amber-400" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-slate-500" />
                          )}
                        </span>
                      </div>
                    </div>

                    {/* 小分類 (各理論カード) */}
                    {isCatOpen && (
                      <div className="p-3 sm:p-4 grid grid-cols-1 md:grid-cols-2 gap-3 bg-slate-950/50 animate-in fade-in duration-150">
                        {catTheories.map((theory) => renderTheoryCard(theory))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            /* 2. フラット全件カード表示モード (S/A/Bランク) */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeTheories.map((theory) => renderTheoryCard(theory))}
            </div>
          )}

          {/* 3. Dランク（直近第75回・第76回・熊本再試験で出題済 → 自動復習除外・最下部折りたたみ） */}
          {dRankTheories.length > 0 && (
            <div className="mt-6 rounded-2xl border border-slate-800/80 bg-slate-950/70 overflow-hidden">
              <div
                onClick={() => setIsDRankSectionOpen(!isDRankSectionOpen)}
                className="p-3.5 sm:p-4 flex items-center justify-between cursor-pointer select-none bg-slate-900/60 hover:bg-slate-900 transition gap-2"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-wrap">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    Dランク（直近本試験・再試験 出題済）
                  </span>
                  <span className="text-xs sm:text-sm font-bold text-slate-300">
                    R7第75回・R8第76回（本試験・熊本再試験）出題済論点（{dRankTheories.length}題 / 自動復習対象外）
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0 text-xs text-slate-400 font-bold">
                  <span>{isDRankSectionOpen ? '折りたたむ' : '展開して確認する'}</span>
                  {isDRankSectionOpen ? (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  )}
                </div>
              </div>

              {isDRankSectionOpen && (
                <div className="p-3.5 sm:p-4 border-t border-slate-800/80 bg-slate-950/90 space-y-3">
                  <p className="text-xs text-slate-400 leading-relaxed">
                    ※ 直近の第75回（R7）・第76回（R8本試験および熊本再試験）で出題された論点です。毎日の自動復習メニューからは除外していますが、カードをクリックすればいつでも条文・柱・暗記状態を確認できます。
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 opacity-85 hover:opacity-100 transition-opacity">
                    {dRankTheories.map((theory) => renderTheoryCard(theory))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* VIEW 2: OPENED THEORY FOCUSED CANVAS (isDetailOpen)      */}
      {/* ========================================================= */}
      {isDetailOpen && currentTheory && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Top Bar inside opened Theory: Back Button at top-left + Prev/Next controls */}
          <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-800">
            {/* Top-Left Back Button as explicitly requested */}
            <button
              onClick={() => setIsDetailOpen(false)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition active:scale-95 shadow-md shadow-black/40"
            >
              <ArrowLeft className="w-4 h-4 text-amber-400" />
              <span>← 論点一覧に戻る</span>
            </button>

            {/* Prev / Next Theory Navigation */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevTheory}
                disabled={currentTheoryIndex <= 0}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-850 text-xs font-medium text-slate-300 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">前の論点</span>
              </button>

              <span className="text-xs font-mono font-bold text-slate-400 px-1">
                {currentTheoryIndex + 1} / {sortedTheories.length}
              </span>

              <button
                onClick={handleNextTheory}
                disabled={currentTheoryIndex >= sortedTheories.length - 1}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-850 text-xs font-medium text-slate-300 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition"
              >
                <span className="hidden sm:inline">次の論点</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Theory Details Header */}
          <div className="p-4 md:p-6 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs flex-wrap">
                  <span className="font-mono font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-md">
                    理論 {currentTheory.theoryNumber}
                  </span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded-md text-[10px] ${
                      currentTheory.priorityRank === 'S'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : currentTheory.priorityRank === 'A'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : currentTheory.priorityRank === 'D'
                        ? 'bg-slate-900 text-slate-400 border border-slate-700'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {currentTheory.priorityRank}ランク
                  </span>
                  {currentTheory.subCategory && (
                    <span className="text-[10px] font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-700/60 px-2 py-0.5 rounded">
                      {currentTheory.subCategory}
                    </span>
                  )}
                  {currentTheory.category && (
                    <span className="text-[10px] text-slate-400 bg-slate-850 px-2 py-0.5 rounded border border-slate-700/80">
                      {currentTheory.category}
                    </span>
                  )}
                  <span className="text-xs text-rose-300 font-bold">
                    {currentTheory.examRankNote}
                  </span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400 font-medium">標準目安: {currentTheory.standardMinutes}分</span>
                </div>
                <h2 className="text-lg md:text-xl font-black text-white leading-tight">
                  {currentTheory.title}
                </h2>
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  {renderStars(currentTheory.currentStage || 1)}
                  <span className="text-[11px] text-slate-400 font-medium">
                    現在の習得度: <strong className="text-slate-200">{getStageConfig(currentTheory.currentStage || 1).title}</strong>
                  </span>
                </div>

                {/* Level 1〜5 Interactive Progression & Rollback Toggle Bar */}
                <div className="pt-2 max-w-xl">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold mb-1.5 flex-wrap gap-2">
                    <span className="flex items-center gap-1.5">
                      <span>🎯 習得度Lv進捗（タップで昇格 / 再タップで前段階へ戻す）:</span>
                    </span>
                    <span className="text-[10px] text-amber-400/90 font-medium">
                      柱の評価（◎○❌）と完全連動
                    </span>
                  </div>
                  <div className="grid grid-cols-5 gap-1.5 p-1.5 bg-slate-950/80 rounded-xl border border-slate-800">
                    {[1, 2, 3, 4, 5].map((lvl) => {
                      const cfg = getStageConfig(lvl);
                      const isCurrent = (currentTheory.currentStage || 1) === lvl;
                      const isPassed = (currentTheory.currentStage || 1) >= lvl;
                      return (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => handleToggleStage(lvl)}
                          title={isCurrent ? `現在Lv.${lvl}（クリックでLv.${Math.max(1, lvl - 1)}に戻す）` : `Lv.${lvl}（${cfg.title}）に切り替え`}
                          className={`flex flex-col items-center justify-center py-2 px-1 rounded-lg border transition-all text-center relative group cursor-pointer ${
                            isCurrent
                              ? `${cfg.badgeBg} ring-2 ring-amber-400/50 shadow-md scale-[1.02]`
                              : isPassed
                              ? 'bg-slate-900/90 border-slate-700 text-slate-200 hover:border-slate-500'
                              : 'bg-slate-950/50 border-slate-800/80 text-slate-500 hover:text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-0.5">
                            <span className="text-xs font-black font-mono">Lv.{lvl}</span>
                            <span className={`text-xs ${isPassed ? cfg.starColor : 'text-slate-700'}`}>★</span>
                          </div>
                          <span className={`text-[10px] font-bold tracking-tight truncate w-full ${isCurrent ? cfg.textBadge : 'text-slate-400'}`}>
                            {cfg.shortTitle}
                          </span>
                          {isCurrent && (
                            <span className="text-[9px] text-amber-300 font-bold mt-0.5 flex items-center gap-0.5">
                              <span>● 達成</span>
                              <span className="text-[8px] opacity-75">↩戻す</span>
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Honest PB Benchmark Box */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center gap-3 shrink-0 self-start sm:self-auto">
                <div className="text-left">
                  <div className="text-[10px] text-slate-400">自己ベスト</div>
                  <div className="font-mono font-bold text-sm tabular-nums">
                    {currentTheory.bestScore > 0 ? (
                      <span className="text-emerald-400">{currentTheory.bestScore}点</span>
                    ) : (
                      <span className="text-slate-500">未挑戦（0点）</span>
                    )}
                  </div>
                </div>
                <div className="w-[1px] h-7 bg-slate-800" />
                <div className="text-left">
                  <div className="text-[10px] text-slate-400">本日のターゲット</div>
                  <div className="font-mono font-bold text-amber-400 text-sm">
                    {currentTheory.bestScore > 0 ? '前回超え！' : '1回目の記録作成'}
                  </div>
                </div>
              </div>
            </div>

            {/* View Format Selector & Fun Memorization Mode Tabs */}
            <div className="space-y-2.5 pt-1">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar flex-wrap">
                  <button
                    onClick={() => setViewFormat('easy')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'easy'
                        ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <span>💡 超日常語訳（要するに）</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('cloze')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'cloze'
                        ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <span>❓ タップ虫食い暗記</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('quiz')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'quiz'
                        ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <span>⚡ 3秒即答クイズ</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('story')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'story'
                        ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <span>💬 キャラ図解会話</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('flow')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'flow'
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <GitBranch className="w-3.5 h-3.5" />
                    <span>🗺️ 柱の構造フロー図</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('structured')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'structured'
                        ? 'bg-slate-800 text-amber-300 border border-amber-500/40 shadow-sm'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>Notionトグル</span>
                  </button>

                  <button
                    onClick={() => setViewFormat('verbatim')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      viewFormat === 'verbatim'
                        ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                        : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>理サブ全文</span>
                  </button>
                </div>

                {viewFormat === 'structured' && (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                      onClick={expandAllToggles}
                      className="px-2.5 py-1 text-[11px] font-semibold text-slate-300 hover:text-white bg-slate-950 border border-slate-800 rounded-lg transition"
                    >
                      すべて開く
                    </button>
                    <button
                      onClick={collapseOnlyPillars}
                      className="px-2.5 py-1 text-[11px] font-semibold text-amber-400 hover:text-amber-300 bg-slate-950 border border-slate-850 rounded-lg transition"
                      title="(1)(2)の大見出しだけ残して柱を閉じる"
                    >
                      柱を閉じる
                    </button>
                    <button
                      onClick={collapseAllToggles}
                      className="px-2.5 py-1 text-[11px] font-semibold text-rose-300 hover:text-rose-200 bg-slate-950 border border-slate-850 rounded-lg transition"
                      title="すべて閉じて見出しだけにし、完全暗唱テストを行う"
                    >
                      すべて閉じる
                    </button>
                  </div>
                )}

                {viewFormat === 'cloze' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={revealAllClozes}
                      className="px-2.5 py-1 text-[11px] font-semibold text-cyan-300 hover:text-white bg-slate-950 border border-cyan-850 rounded-lg transition"
                    >
                      すべての穴をめくる
                    </button>
                    <button
                      onClick={hideAllClozes}
                      className="px-2.5 py-1 text-[11px] font-semibold text-slate-400 hover:text-slate-200 bg-slate-950 border border-slate-800 rounded-lg transition"
                    >
                      すべて隠す（再挑戦）
                    </button>
                  </div>
                )}

                {viewFormat === 'verbatim' && (
                  <button
                    onClick={copyVerbatimText}
                    className="flex items-center gap-1 px-3 py-1 text-xs text-slate-300 hover:text-white bg-slate-950 border border-slate-700 rounded-lg transition"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'コピー完了' : '本文コピー'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* 1. 【💡 超日常語訳】（要するにこういうこと！） */}
            {viewFormat === 'easy' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-amber-950/30 border border-amber-500/30 space-y-3.5 shadow-xl animate-in fade-in duration-150">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
                    💡
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">超日常語訳（文字面が苦手な人のためのイメージ理解）</h3>
                    <p className="text-[10px] text-slate-400">堅い条文を読む前に、まず「日常のどんな場面のルールか」を頭に焼き付けよう！</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-850 text-xs sm:text-sm text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
                  {currentTheory.easyExplanation || `【要するにこういうこと！💡】\n${currentTheory.lv1Hint}\n\n自治体（地方団体）の行政サービスを公平に受けるため、法文で厳密にルール化されている規定です。`}
                </div>

                {/* Display any pillar visual images in easy mode for instant visual comprehension */}
                {parentSectionsList.some((p) => p.subSections.some((s) => s.imageUrl)) && (
                  <div className="space-y-3 pt-1">
                    <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <span>🖼️ 柱のイメージ図解</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {parentSectionsList.flatMap((p) =>
                        p.subSections
                          .filter((s) => s.imageUrl)
                          .map((s, idx) => (
                            <div
                              key={`${p.num}-${s.num}-${idx}`}
                              className="rounded-xl bg-slate-950 border border-amber-500/30 p-2.5 space-y-2 shadow-lg"
                            >
                              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-200">
                                <span className="font-mono px-1.5 py-0.5 rounded bg-amber-950 border border-amber-700/60 text-[10px] text-amber-300">
                                  {p.num}{s.num}
                                </span>
                                <span>{s.heading}</span>
                              </div>
                              <img
                                src={s.imageUrl}
                                alt={`${p.num}${s.num} ${s.heading} イメージ図`}
                                referrerPolicy="no-referrer"
                                className="w-full rounded-lg border border-slate-800 object-contain bg-slate-900"
                              />
                            </div>
                          ))
                      )}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-1 text-xs flex-wrap gap-2">
                  <span className="text-[11px] text-slate-400">
                    情景が浮かんだら、上の <strong className="text-cyan-400">[ ❓ タップ虫食い ]</strong> や <strong className="text-emerald-400">[ ⚡ 3秒即答クイズ ]</strong> で重要語句を刷り込もう！
                  </span>
                  <button
                    onClick={() => setViewFormat('cloze')}
                    className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1 transition"
                  >
                    <span>次：タップ虫食い暗記へ</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* 2. 【❓ タップ虫食い暗記モード】 */}
            {viewFormat === 'cloze' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-4 shadow-xl animate-in fade-in duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-base">❓</span>
                    <div>
                      <h3 className="text-sm font-bold text-white">タップ虫食い暗記（ゲーム感覚で重要キーワードをめくる）</h3>
                      <p className="text-[10px] text-slate-400">黒塗りの [ ❓ めくる ] をタップすると答えが出ます。指先を使って能動的に記憶！</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3.5">
                  {parentSectionsList.map((parent, pIdx) => (
                    <div key={pIdx} className="space-y-2 p-3 bg-slate-950/80 rounded-xl border border-slate-800">
                      <div className="text-xs font-bold text-amber-300 pb-1 border-b border-slate-850">
                        {parent.num} {parent.heading}
                      </div>

                      <div className="space-y-2 pl-2">
                        {parent.subSections.map((sec, sIdx) => {
                          const cleanNum = sec.num.replace(/^\([0-9]+\)/, '').replace(/^[〔【][0-9]+[〕】]/, '') || sec.num;
                          return (
                            <div key={sIdx} className="space-y-1 text-xs">
                              <div className="font-bold text-white flex items-center gap-1.5">
                                <span className="font-mono text-cyan-400">{cleanNum}</span>
                                <span>{sec.heading}</span>
                              </div>
                              {sec.essence && (
                                <div className="ml-3 text-[10px] text-cyan-200 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-850/50 font-medium">
                                  💡 ようは: {sec.essence}
                                </div>
                              )}
                              <div className="pl-3 text-slate-300 leading-relaxed font-sans">
                                {renderClozeText(
                                  sec.body,
                                  currentTheory.clozeKeywords || [
                                    '生活の本拠', '一人一箇所', '住民基本台帳に記録', 'みなして',
                                    '通知', '二重課税', '負担分任', '応益関係', '賦課課税方式',
                                    '1,000円', '3,000円', '135万円', '普通徴収', '特別徴収'
                                  ],
                                  `cloze-${pIdx}-${sIdx}`
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 3. 【⚡ 3秒即答クイズ】 */}
            {viewFormat === 'quiz' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-4 shadow-xl animate-in fade-in duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-base">⚡</span>
                    <div>
                      <h3 className="text-sm font-bold text-white">3秒即答クイックノック（反射で答えて記憶の引き出しを鍛える）</h3>
                      <p className="text-[10px] text-slate-400">迷ったらアウト！数字や重要要件を直感で選んで即答力を鍛えます。</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  {(currentTheory.quickKnockQuestions || [
                    {
                      id: 'qk-def-1',
                      question: `${currentTheory.title}における重要キーワードは？`,
                      options: [currentTheory.lv3KeyRequirements[0] || '生活の本拠', '住民票の所在地のみ'],
                      correctIndex: 0,
                      tip: '条文の重要要件を一瞬で選べるようにしよう！',
                    },
                    {
                      id: 'qk-def-2',
                      question: 'この論点の標準的な所要時間は？',
                      options: [`${currentTheory.standardMinutes}分以内`, '30分以上'],
                      correctIndex: 0,
                      tip: '本試験で書き切る標準スピードを意識！',
                    },
                  ]).map((q, qIdx) => {
                    const picked = quizAnswers[q.id];
                    const isAnswered = picked !== undefined;
                    const isCorrect = picked === q.correctIndex;

                    return (
                      <div key={q.id || qIdx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5 text-xs">
                        <div className="font-bold text-slate-100 flex items-start gap-2">
                          <span className="font-mono text-emerald-400 font-black">Q{qIdx + 1}.</span>
                          <span className="leading-snug">{q.question}</span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                          {q.options.map((opt, optIdx) => {
                            const isChosen = picked === optIdx;
                            const isThisCorrect = optIdx === q.correctIndex;

                            let btnStyle = 'bg-slate-900 border-slate-750 text-slate-300 hover:bg-slate-800 hover:border-slate-700';
                            if (isAnswered) {
                              if (isThisCorrect) btnStyle = 'bg-emerald-950 border-emerald-500 text-emerald-300 font-bold';
                              else if (isChosen) btnStyle = 'bg-rose-950 border-rose-500 text-rose-300';
                              else btnStyle = 'bg-slate-950 border-slate-850 text-slate-500 opacity-60';
                            }

                            return (
                              <button
                                key={optIdx}
                                type="button"
                                disabled={isAnswered}
                                onClick={() => handleQuizOptionSelect(q.id, optIdx, q.correctIndex)}
                                className={`p-2.5 rounded-lg border text-left font-medium transition active:scale-95 text-xs ${btnStyle}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>

                        {isAnswered && (
                          <div className={`p-2 rounded-lg text-[11px] font-sans ${isCorrect ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40' : 'bg-rose-950/40 text-rose-300 border border-rose-800/40'}`}>
                            <strong>{isCorrect ? '⭕ 正解！' : '❌ 惜しい！'}</strong> {q.tip}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 4. 【💬 キャラ図解会話】 */}
            {viewFormat === 'story' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-purple-500/30 space-y-4 shadow-xl animate-in fade-in duration-150">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <span className="text-base">💬</span>
                  <div>
                    <h3 className="text-sm font-bold text-white">キャラ図解会話（全柱のストーリー・登場人物のリアル問答）</h3>
                    <p className="text-[10px] text-slate-400">田中さんたちと役所の会話で、すべての柱の背景と理由がドラマ感覚で身につきます。</p>
                  </div>
                </div>

                <div className="space-y-3 max-w-2xl mx-auto py-2">
                  {(currentTheory.storyDialogue || [
                    {
                      speaker: '納税者（田中さん）',
                      avatar: '👨',
                      text: `「${currentTheory.title}って、結局どういうことなんですか？」`,
                      side: 'left',
                    },
                    {
                      speaker: '役所 課税課',
                      avatar: '🏛️',
                      text: `「${currentTheory.lv1Hint}」`,
                      side: 'right',
                    },
                    {
                      speaker: '納税者（田中さん）',
                      avatar: '👨',
                      text: '「なるほど！だからこの要件や数字が決まっているんですね！」',
                      side: 'left',
                    },
                  ]).map((chat, cIdx) => (
                    <div
                      key={cIdx}
                      className={`flex items-start gap-2.5 ${chat.side === 'right' ? 'flex-row-reverse' : ''}`}
                    >
                      <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-base shrink-0 border border-slate-700">
                        {chat.avatar}
                      </div>
                      <div
                        className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                          chat.side === 'right'
                            ? 'bg-amber-500/20 text-amber-200 border border-amber-500/40 rounded-tr-none'
                            : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-tl-none'
                        }`}
                      >
                        <div className="text-[10px] text-slate-400 font-bold mb-0.5">{chat.speaker}</div>
                        <div>{chat.text}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 5. 【🗺️ 柱の構造フロー図】 */}
            {viewFormat === 'flow' && (
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-blue-950/20 to-slate-900 border border-blue-500/30 space-y-4 shadow-xl animate-in fade-in duration-150">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm">
                      🗺️
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">各柱の構造フロー図（論理構造・判定ステップ・帰結）</h3>
                      <p className="text-[10px] text-slate-400">前提条件 → 法的判定 → 結論（課税/非課税/通知等）の流れを全柱ビジュアル化！</p>
                    </div>
                  </div>
                  <div className="text-[11px] font-mono text-blue-300 bg-blue-950/80 px-2.5 py-1 rounded-lg border border-blue-800/40">
                    全{(currentTheory.flowSteps || []).length || parentSectionsList.reduce((acc, p) => acc + p.subSections.length, 0)}ステップ
                  </div>
                </div>

                {/* Pillar Visual Images inside Flow mode */}
                {parentSectionsList.some((p) => p.subSections.some((s) => s.imageUrl)) && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-3xl mx-auto">
                    {parentSectionsList.flatMap((p) =>
                      p.subSections
                        .filter((s) => s.imageUrl)
                        .map((s, idx) => (
                          <div
                            key={`flow-img-${p.num}-${s.num}-${idx}`}
                            className="rounded-xl bg-slate-950 border border-indigo-500/40 p-2.5 space-y-2 shadow-lg"
                          >
                            <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-200">
                              <span className="font-mono px-1.5 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 text-[10px] text-indigo-300">
                                🖼️ {p.num}{s.num}
                              </span>
                              <span>{s.heading}</span>
                            </div>
                            <img
                              src={s.imageUrl}
                              alt={`${p.num}${s.num} ${s.heading} イメージ図`}
                              referrerPolicy="no-referrer"
                              className="w-full rounded-lg border border-slate-800 object-contain bg-slate-900"
                            />
                          </div>
                        ))
                    )}
                  </div>
                )}

                {/* Flow cards */}
                <div className="space-y-3 max-w-3xl mx-auto py-1">
                  {((currentTheory.flowSteps && currentTheory.flowSteps.length > 0) ? currentTheory.flowSteps : (
                    parentSectionsList.flatMap((p, pIdx) =>
                      p.subSections.map((sec, sIdx) => ({
                        step: pIdx * 10 + sIdx + 1,
                        pillarNum: `${p.num}${sec.num}`,
                        title: sec.heading,
                        actor: '🏛️ 課税当局 / 納税者',
                        actionOrCondition: sec.essence || sec.heading,
                        judgment: sec.keyPoints?.join('・') || '条文要件への該当性を判定',
                        outcome: sec.body.slice(0, 60) + '...',
                        subNote: sec.mnemonic,
                      }))
                    )
                  )).map((flow, fIdx, allFlows) => (
                    <div key={fIdx} className="relative">
                      {/* Step Card */}
                      <div className="rounded-xl bg-slate-950 border border-slate-800 p-3.5 sm:p-4 space-y-2.5 shadow-md hover:border-blue-500/50 transition">
                        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-850 pb-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] font-black font-mono px-2 py-0.5 rounded bg-blue-600 text-white shadow-sm">
                              STEP {flow.step}
                            </span>
                            {flow.pillarNum && (
                              <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-950/70 border border-amber-800/50 text-amber-300">
                                {flow.pillarNum}
                              </span>
                            )}
                            <h4 className="text-xs sm:text-sm font-bold text-white">{flow.title}</h4>
                          </div>
                          <span className="text-[11px] font-bold text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                            {flow.actor}
                          </span>
                        </div>

                        {/* Logic Matrix */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1">
                            <div className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                              <span>🚩 前提・トリガー</span>
                            </div>
                            <div className="text-slate-200 leading-snug">{flow.actionOrCondition}</div>
                          </div>

                          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1">
                            <div className="text-[10px] font-bold text-amber-400 flex items-center gap-1">
                              <span>⚖️ 判定基準</span>
                            </div>
                            <div className="text-slate-200 leading-snug">{flow.judgment}</div>
                          </div>

                          <div className="p-2.5 rounded-lg bg-blue-950/40 border border-blue-700/50 space-y-1">
                            <div className="text-[10px] font-bold text-blue-300 flex items-center gap-1">
                              <span>🎯 法的効果・結論</span>
                            </div>
                            <div className="text-blue-100 font-semibold leading-snug">{flow.outcome}</div>
                          </div>
                        </div>

                        {/* Note & Mnemonic */}
                        {flow.subNote && (
                          <div className="text-[11px] text-amber-300 bg-amber-950/30 px-2.5 py-1.5 rounded-lg border border-amber-850/50 flex items-center gap-1.5">
                            <Flame className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />
                            <span>ポイント: {flow.subNote}</span>
                          </div>
                        )}
                      </div>

                      {/* Connection arrow */}
                      {fIdx < allFlows.length - 1 && (
                        <div className="flex justify-center my-1.5">
                          <div className="flex items-center gap-1 text-[11px] text-blue-400/80 bg-slate-900/90 px-2.5 py-0.5 rounded-full border border-blue-900/40 font-mono shadow-sm">
                            <span>↓ 次の柱へ接続</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ======================================================== */}
            {/* NOTION-STYLE 3-TIER NESTED TOGGLE SECTION                */}
            {/* 大トグル (Root) -> 中トグル (Parent) -> 小トグル (柱)     */}
            {/* ======================================================== */}
            {viewFormat === 'structured' && (
              <div className="space-y-4 pt-2">
                {/* Official Mnemonics Bar */}
                {currentTheory.mnemonics && currentTheory.mnemonics.length > 0 && (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs space-y-1.5">
                    <div className="font-extrabold text-amber-300 flex items-center gap-1.5">
                      <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span>公式語呂合わせ（暗記の合言葉）:</span>
                    </div>
                    <div className="flex flex-wrap gap-2 pt-0.5">
                      {currentTheory.mnemonics.map((m, mI) => (
                        <span key={mI} className="px-2.5 py-1 rounded-lg bg-slate-950 border border-amber-500/40 font-bold text-amber-200 text-xs shadow-sm">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* 1. 大トグル (Level 1: 理論全体トグル) */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/90 shadow-xl overflow-hidden transition-all">
                  <div
                    onClick={() => setIsMajorToggleOpen(!isMajorToggleOpen)}
                    className="p-3 sm:p-3.5 flex items-center justify-between cursor-pointer select-none bg-slate-900/90 hover:bg-slate-850 border-b border-slate-800 transition"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-amber-400">
                        {isMajorToggleOpen ? (
                          <ChevronDown className="w-4 h-4 text-amber-400 shrink-0" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                      </span>
                      <span className="text-xs sm:text-sm font-extrabold text-white truncate">
                        理論 {currentTheory.theoryNumber}: {currentTheory.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {parentSectionsList.length}大項目 · {totalPillarsCount}柱
                      </span>
                      <span className="text-[11px] font-bold text-amber-400">
                        {isMajorToggleOpen ? '閉じる' : '展開する'}
                      </span>
                    </div>
                  </div>

                  {/* 大トグル Body */}
                  {isMajorToggleOpen && (
                    <div className="p-3 sm:p-4 space-y-3.5 animate-in fade-in duration-150">
                      {/* 2. 中トグル ((1), (2), 〔1〕, 〔2〕...) */}
                      {parentSectionsList.map((parent, pIdx) => {
                        const parentKey = `parent-${pIdx}`;
                        const isParentOpen = !!openSections[parentKey];

                        return (
                          <div
                            key={parent.id || pIdx}
                            className="rounded-xl border border-slate-800/90 bg-slate-900/40 overflow-hidden"
                          >
                            {/* 中トグル ヘッダー */}
                            <div
                              onClick={() => toggleAccordion(parentKey)}
                              className="py-2.5 px-3 flex items-start justify-between cursor-pointer select-none bg-slate-900/80 hover:bg-slate-850 transition gap-2"
                            >
                              <div className="flex items-start gap-2 flex-1 min-w-0">
                                <span className="text-amber-400/90 mt-0.5 shrink-0">
                                  {isParentOpen ? (
                                    <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                                  ) : (
                                    <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                                  )}
                                </span>
                                <span className="text-[11px] font-mono font-bold text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40 shrink-0 mt-0.5">
                                  {parent.num}
                                </span>
                                <h4 className="text-xs sm:text-[13px] font-bold text-slate-100 leading-snug break-words flex-1">
                                  {parent.heading}
                                </h4>
                              </div>

                              <div className="flex items-center gap-2 shrink-0 mt-0.5">
                                <span className="text-[10px] text-slate-400 font-mono bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                  {parent.subSections.length}柱
                                </span>
                              </div>
                            </div>

                            {/* 中トグル Body: 3. 小トグル (各柱 [1], [2], [3]...) */}
                            {isParentOpen && (
                              <div className="p-2 sm:p-3 space-y-2 border-t border-slate-800/80 bg-slate-950/70 pl-2.5 sm:pl-4 border-l-2 border-l-amber-500/50">
                                {parent.subSections.map((sec, sIdx) => {
                                  const childKey = `child-${pIdx}-${sIdx}`;
                                  const isChildOpen = !!openSections[childKey];
                                  const pillarState = getPillarState(currentTheory, sec.heading, sec.status);
                                  // Strip redundant parent prefix like (1)[2] -> [2]
                                  const cleanNum = sec.num.replace(/^\([0-9]+\)/, '').replace(/^[〔【][0-9]+[〕】]/, '') || sec.num;
                                  const matchedFlowStep = currentTheory.flowSteps?.find(
                                    (fs) =>
                                      (fs.pillarNum && (fs.pillarNum.includes(sec.num) || fs.pillarNum.includes(cleanNum) || fs.pillarNum.includes(`${parent.num}${sec.num}`))) ||
                                      fs.title.includes(sec.heading) ||
                                      sec.heading.includes(fs.title)
                                  );

                                  return (
                                    <div
                                      key={sIdx}
                                      className={`rounded-lg border transition-all ${
                                        pillarState.status === 'mastered'
                                          ? 'bg-slate-950/40 border-slate-850 opacity-90'
                                          : isChildOpen
                                          ? 'bg-slate-900/90 border-slate-700 shadow-sm'
                                          : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                                      }`}
                                    >
                                      {/* 小トグル (柱) ヘッダー: 1,3,4連動 */}
                                      <div
                                        onClick={() => handleTogglePillar(childKey)}
                                        className="py-2 px-2.5 flex items-start justify-between cursor-pointer select-none gap-2 hover:bg-slate-800/40 rounded-lg"
                                      >
                                        <div className="flex items-start gap-2 flex-1 min-w-0">
                                          <span className="text-slate-400 hover:text-amber-400 transition-colors mt-0.5 shrink-0">
                                            {isChildOpen ? (
                                              <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                                            ) : (
                                              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                                            )}
                                          </span>

                                          <span className="font-mono font-black text-amber-300 text-[11px] px-1.5 py-0.5 rounded bg-amber-950/70 border border-amber-800/50 shrink-0 mt-0.5">
                                            {cleanNum}
                                          </span>

                                          {/* 柱の文字：絶対に省略せず全文を綺麗に表示 */}
                                          <span className="font-bold text-slate-100 text-xs sm:text-[13px] leading-snug break-words flex-1 flex items-center gap-1.5 flex-wrap">
                                            <span>{formatCleanPillarHeading(sec.heading)}</span>
                                            {sec.imageUrl && (
                                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700/60">
                                                🖼️ 図解画像あり
                                              </span>
                                            )}
                                          </span>
                                        </div>

                                        <div className="flex items-center gap-1.5 shrink-0 mt-0.5">
                                          {/* [案1] ロックボタン: 0回(❌) -> 1回(○) -> 2回(◎) -> 解除 */}
                                          <button
                                            type="button"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleLockClick(sec.heading, childKey, sec.status);
                                            }}
                                            className={`px-2 py-0.5 rounded text-[10px] font-bold transition flex items-center gap-1 ${
                                              pillarState.status === 'mastered'
                                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-600 shadow-sm shadow-emerald-500/20'
                                                : pillarState.status === 'learning'
                                                ? 'bg-amber-950 text-amber-300 border border-amber-600'
                                                : 'bg-slate-900 text-slate-400 hover:text-amber-300 border border-slate-750'
                                            }`}
                                            title={
                                              pillarState.status === 'mastered'
                                                ? '◎ 2回ロック達成！タップで解除'
                                                : pillarState.status === 'learning'
                                                ? '○ 1回ロック中。もう一度思い出せたらロックして◎へ！'
                                                : '暗唱できたらロックして○へ昇格'
                                            }
                                          >
                                            {pillarState.status === 'mastered' ? (
                                              <>
                                                <Lock className="w-3 h-3 text-emerald-400" />
                                                <span className="hidden sm:inline">2回ロック済</span>
                                              </>
                                            ) : pillarState.status === 'learning' ? (
                                              <>
                                                <Lock className="w-3 h-3 text-amber-400" />
                                                <span className="hidden sm:inline">1回ロック中</span>
                                              </>
                                            ) : (
                                              <>
                                                <Unlock className="w-3 h-3 text-slate-400" />
                                                <span className="hidden sm:inline">覚えたら🔒</span>
                                              </>
                                            )}
                                          </button>

                                          {/* [案3] 直接タップで ❌, ○, ◎ を切り替え & トグルで前段階へ戻る */}
                                          <div className="flex items-center bg-slate-950/80 p-0.5 rounded-lg border border-slate-800 gap-0.5">
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleDirectSetPillarStatus(sec.heading, childKey, 'weak', sec.status);
                                              }}
                                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                pillarState.status === 'weak'
                                                  ? 'bg-rose-950 text-rose-300 border border-rose-800 font-black shadow-sm'
                                                  : 'text-slate-500 hover:text-slate-300'
                                              }`}
                                              title="❌ 未習得にする（理論Lvが連動して下がります）"
                                            >
                                              ❌
                                            </button>
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleDirectSetPillarStatus(sec.heading, childKey, 'learning', sec.status);
                                              }}
                                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                pillarState.status === 'learning'
                                                  ? 'bg-amber-950 text-amber-300 border border-amber-600 font-black shadow-sm'
                                                  : 'text-slate-500 hover:text-slate-300'
                                              }`}
                                              title="○ 1回ロック（骨格暗記。全柱○でLv.2に昇格 / 再タップで❌へ戻る）"
                                            >
                                              ○
                                            </button>
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleDirectSetPillarStatus(sec.heading, childKey, 'mastered', sec.status);
                                              }}
                                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                pillarState.status === 'mastered'
                                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-500 font-black shadow-sm'
                                                  : 'text-slate-500 hover:text-slate-300'
                                              }`}
                                              title="◎ 2回ロック（完全習得。全柱◎でLv.3に昇格 / 再タップで○へ戻る）"
                                            >
                                              ◎
                                            </button>
                                          </div>
                                        </div>
                                      </div>

                                      {/* 小トグル (柱) Body */}
                                      {isChildOpen && (
                                        <div className="p-3 pt-1 border-t border-slate-800 space-y-2 animate-in fade-in duration-100">
                                          {sec.essence && (
                                            <div className="text-[11px] font-bold text-cyan-300 bg-cyan-950/40 p-2.5 rounded-lg border border-cyan-800/50 flex items-start gap-2 shadow-sm">
                                              <span className="text-cyan-400 font-black shrink-0 bg-cyan-900/60 px-1.5 py-0.5 rounded text-[10px] border border-cyan-700/50">
                                                💡 ようは
                                              </span>
                                              <span className="leading-snug text-cyan-100 flex-1">{sec.essence}</span>
                                            </div>
                                          )}

                                          {/* 🖼️ 柱ごとのビジュアルイメージ図（生成画像） */}
                                          {sec.imageUrl && (
                                            <div className="rounded-xl bg-slate-950 border border-indigo-500/40 p-2.5 space-y-2 shadow-md">
                                              <div className="flex items-center gap-1.5 text-[11px] font-bold text-indigo-300">
                                                <span className="px-1.5 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 text-[10px] text-indigo-300 font-mono">
                                                  🖼️ イメージ図解
                                                </span>
                                                <span>{parent.num}{cleanNum} {sec.heading}</span>
                                              </div>
                                              <img
                                                src={sec.imageUrl}
                                                alt={`${parent.num}${cleanNum} ${sec.heading} イメージ図`}
                                                referrerPolicy="no-referrer"
                                                className="w-full rounded-lg border border-slate-800 object-contain bg-slate-900"
                                              />
                                            </div>
                                          )}

                                          {/* 🗺️ 柱ごとの図解・構造ビジュアルフロー */}
                                          {(sec.diagram || matchedFlowStep) && (
                                            <div className="rounded-xl bg-slate-950/90 border border-indigo-900/50 p-2.5 sm:p-3 space-y-2 shadow-inner">
                                              <div className="flex items-center justify-between gap-2">
                                                <div className="flex items-center gap-1.5 text-[11px] font-bold text-indigo-300">
                                                  <span className="px-1.5 py-0.5 rounded bg-indigo-950 border border-indigo-700/60 text-[10px] text-indigo-300 font-mono">
                                                    🗺️ 柱の図解
                                                  </span>
                                                  <span>構造・判定フロー</span>
                                                </div>
                                                {matchedFlowStep && (
                                                  <span className="text-[10px] text-indigo-400 font-medium">
                                                    {matchedFlowStep.actor}
                                                  </span>
                                                )}
                                              </div>

                                              {/* 3段階ステップカード (前提・要件 ➔ 税法判定 ➔ 結論・法的効果) */}
                                              {matchedFlowStep && (
                                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 text-[10px]">
                                                  <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                                                    <div className="text-slate-400 font-bold mb-0.5 flex items-center gap-1">
                                                      <span>① 前提・要件</span>
                                                    </div>
                                                    <div className="text-slate-200 font-medium leading-snug">
                                                      {matchedFlowStep.actionOrCondition}
                                                    </div>
                                                  </div>

                                                  <div className="bg-slate-900/90 p-2 rounded-lg border border-amber-900/40">
                                                    <div className="text-amber-400 font-bold mb-0.5 flex items-center gap-1">
                                                      <span>② 税法判定基準</span>
                                                    </div>
                                                    <div className="text-amber-200/90 font-medium leading-snug">
                                                      {matchedFlowStep.judgment}
                                                    </div>
                                                  </div>

                                                  <div className="bg-slate-900/90 p-2 rounded-lg border border-emerald-900/40">
                                                    <div className="text-emerald-400 font-bold mb-0.5 flex items-center gap-1">
                                                      <span>③ 結論・法的効果</span>
                                                    </div>
                                                    <div className="text-emerald-200/90 font-bold leading-snug">
                                                      {matchedFlowStep.outcome}
                                                    </div>
                                                  </div>
                                                </div>
                                              )}

                                              {/* 視覚構造ダイアグラム / フローチャート */}
                                              {sec.diagram && (
                                                <pre className="font-mono text-[10px] sm:text-[11px] text-indigo-200/90 leading-relaxed overflow-x-auto p-2.5 bg-slate-900/70 rounded-lg border border-slate-800 whitespace-pre">
                                                  {sec.diagram}
                                                </pre>
                                              )}
                                            </div>
                                          )}

                                          {sec.mnemonic && (
                                            <div className="text-[11px] font-bold text-amber-300 bg-amber-950/30 p-2 rounded-lg border border-amber-800/30 flex items-center gap-1.5">
                                              <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
                                              <span>語呂: {sec.mnemonic}</span>
                                            </div>
                                          )}

                                          {/* 🔍 【一字一句暗記対策】深掘り解説トグル */}
                                          {sec.deepDiveNote && (
                                            <details className="group rounded-xl border border-amber-500/40 bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 p-2.5 shadow-md transition-all text-xs">
                                              <summary className="flex items-center justify-between cursor-pointer font-bold text-amber-300 hover:text-amber-200 select-none list-none">
                                                <div className="flex items-center gap-1.5">
                                                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black">
                                                    🔥 暗記深掘り解説
                                                  </span>
                                                  <span className="text-[11px] text-amber-200 font-bold">理屈・背景＆一字一句攻略ドリル</span>
                                                </div>
                                                <span className="text-[10px] text-amber-400/80 group-open:rotate-180 transition-transform duration-200">
                                                  ▼
                                                </span>
                                              </summary>
                                              <div className="mt-2.5 pt-2 border-t border-amber-500/20 text-slate-200 leading-relaxed font-sans whitespace-pre-wrap text-[11px] bg-slate-950/80 p-2.5 rounded-lg border border-slate-800/80">
                                                {sec.deepDiveNote}
                                              </div>
                                            </details>
                                          )}

                                          {/* 本文テキスト：コンパクトで読みやすい文字サイズ */}
                                          <p className="text-[11px] sm:text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-wrap pl-1">
                                            {sec.body}
                                          </p>

                                          {sec.keyPoints && sec.keyPoints.length > 0 && (
                                            <div className="flex flex-wrap gap-1 pt-1 border-t border-slate-850">
                                              {sec.keyPoints.map((kp, kpI) => (
                                                <span key={kpI} className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-400 font-medium">
                                                  🔑 {kp}
                                                </span>
                                              ))}
                                            </div>
                                          )}

                                          <div className="pt-1.5 flex items-center justify-between text-xs border-t border-slate-850">
                                            <span className="text-[10px] text-slate-500 font-mono">
                                              状態: {pillarState.status === 'mastered' ? '◎ 2回ロック (定着)' : pillarState.status === 'learning' ? '○ 1回ロック (復習中)' : '❌ 未習得'}
                                            </span>
                                            <button
                                              type="button"
                                              onClick={() => handleLockClick(sec.heading, childKey, sec.status)}
                                              className="text-[10px] font-bold text-amber-400 hover:text-amber-300 inline-flex items-center gap-1 py-1 px-2.5 rounded bg-amber-950/40 border border-amber-800/40 transition"
                                            >
                                              <Lock className="w-2.5 h-2.5" />
                                              <span>{pillarState.lockCount === 0 ? '覚えて閉じる (○へ)' : pillarState.lockCount === 1 ? 'もう一度閉じる (◎へ昇格)' : '閉じる'}</span>
                                            </button>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* 所得税との相違点対比表 Toggle */}
                {currentTheory.taxDifferenceTable && (
                  <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950/90">
                    <button
                      onClick={() => toggleAccordion('diff')}
                      className="w-full p-2.5 sm:p-3 flex items-center justify-between text-left text-xs font-bold text-amber-400 hover:bg-slate-900 transition"
                    >
                      <div className="flex items-center gap-2">
                        {openSections['diff'] ? (
                          <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                        )}
                        <span>本試験で差がつく！【所得税との相違点対比表】を開く</span>
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {openSections['diff'] ? '閉じる' : '開く'}
                      </span>
                    </button>

                    {openSections['diff'] && (
                      <div className="p-3 border-t border-slate-800 overflow-x-auto bg-slate-950">
                        <table className="w-full text-left border-collapse text-[11px] sm:text-xs">
                          <thead>
                            <tr className="border-b border-slate-800 text-slate-400">
                              <th className="py-1.5 px-2">区分</th>
                              <th className="py-1.5 px-2 text-amber-300 font-bold">個人住民税</th>
                              <th className="py-1.5 px-2 text-slate-300">所得税</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 text-slate-300">
                            {currentTheory.taxDifferenceTable.map((row, rI) => (
                              <tr key={rI}>
                                <td className="py-1.5 px-2 font-bold text-white whitespace-nowrap">{row.category}</td>
                                <td className="py-1.5 px-2 text-amber-200 font-medium">{row.resident}</td>
                                <td className="py-1.5 px-2 text-slate-400">{row.incomeTax}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Verbatim Full Text */}
            {viewFormat === 'verbatim' && (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold text-amber-400">【一字一句 理サブ原文・模範解答】</span>
                  <span className="font-mono">{currentTheory.lv4FullText.length}文字</span>
                </div>
                <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
                  {currentTheory.lv4FullText}
                </pre>
              </div>
            )}

            {/* ======================================================== */}
            {/* 5-STAGE TRAINING DRILL SECTION                           */}
            {/* ======================================================== */}
            <div className="pt-4 border-t border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>実践トレーニングモード（Lv.1〜Lv.5）</span>
                </h3>
              </div>

              {/* 5 Tabs */}
              <div className="grid grid-cols-5 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-center">
                {[
                  { lv: 1, name: 'Lv.1 柱想起', sub: '大枠・柱を即答' },
                  { lv: 2, name: 'Lv.2 骨格', sub: '見出し・柱列挙' },
                  { lv: 3, name: 'Lv.3 口頭暗唱', sub: '要件・数字' },
                  { lv: 4, name: 'Lv.4 白紙再現', sub: '自力全文執筆' },
                  { lv: 5, name: 'Lv.5 制限時間', sub: '本試験アタック' },
                ].map((stage) => {
                  const isActive = currentLevel === stage.lv;
                  return (
                    <button
                      key={stage.lv}
                      onClick={() => setCurrentLevel(stage.lv)}
                      className={`py-2 px-1 rounded-lg text-xs transition-all ${
                        isActive
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                      }`}
                    >
                      <div className="font-bold">{stage.name}</div>
                      <div className={`text-[10px] hidden sm:block ${isActive ? 'text-slate-900 font-semibold' : 'text-slate-500'}`}>
                        {stage.sub}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Stopwatch & Action Bar */}
              <div className="flex items-center justify-between flex-wrap gap-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span className="font-mono text-lg font-bold text-white tabular-nums tracking-wider">
                      {formatTimeDigital(timerSeconds)}
                    </span>
                  </div>

                  <button
                    onClick={toggleTimer}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      isTimerRunning
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                    }`}
                  >
                    {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isTimerRunning ? '一時停止' : 'タイマースタート'}</span>
                  </button>

                  <button
                    onClick={resetTimer}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
                    title="リセット"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={startSpeechRecognition}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
                    speechActive
                      ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                      : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                  }`}
                  title="ブツブツつぶやき・歩きながら暗唱合格法"
                >
                  <Mic className="w-3.5 h-3.5 text-amber-400" />
                  <span>{speechActive ? '音声聞き取り中...' : 'ブツブツ音声入力'}</span>
                </button>
              </div>

              {/* Stage Drill Body */}
              {currentLevel === 1 && (
                <div className="space-y-3 p-4 bg-slate-950/80 rounded-xl border border-slate-800">
                  <div className="text-xs text-amber-400 font-semibold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Lv.1 柱想起: 出題趣旨や内容から、解答すべき「柱（大項目）」を思い出し打鍵せよ！</span>
                  </div>
                  <div className="p-3 bg-slate-900 rounded-lg text-xs text-slate-300 border border-slate-800 font-medium">
                    {currentTheory.lv1Hint}
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-slate-400">解答すべき柱・タイトル・趣旨を入力:</label>
                    <input
                      type="text"
                      value={lv1Answer}
                      onChange={(e) => setLv1Answer(e.target.value)}
                      placeholder="例: (1)住所の意義及びその認定方法 [1]住所の意義 [2]みなす規定者..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              )}

              {currentLevel === 2 && (
                <div className="space-y-3 p-4 bg-slate-950/80 rounded-xl border border-slate-800">
                  <div className="text-xs text-amber-400 font-semibold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Lv.2 骨格: 答案を構成する「柱（見出し・条文項目）」をすべて挙げよ！</span>
                  </div>
                  <div className="space-y-2">
                    {lv2Outlines.map((outline, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="text-xs font-mono text-slate-500 w-5">{idx + 1}.</span>
                        <input
                          type="text"
                          value={outline}
                          onChange={(e) => updateOutlineRow(idx, e.target.value)}
                          placeholder={`柱${idx + 1}の見出し（例: [1]住所の意義、[2]みなす規定者...）`}
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    ))}
                    <button
                      onClick={addOutlineRow}
                      className="text-xs text-amber-400 hover:text-amber-300 font-semibold py-1 px-2"
                    >
                      ＋ 柱を追加する
                    </button>
                  </div>
                </div>
              )}

              {currentLevel === 3 && (
                <div className="space-y-3 p-4 bg-slate-950/80 rounded-xl border border-slate-800">
                  <div className="text-xs text-amber-400 font-semibold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>Lv.3 口頭暗唱: 数字・期限・例外規定・適用要件を一言一句チェック！</span>
                  </div>
                  <div className="space-y-2 mt-2">
                    {currentTheory.lv3KeyRequirements.map((req, idx) => {
                      const isChecked = !!lv3CheckedRequirements[idx];
                      return (
                        <label
                          key={idx}
                          className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition ${
                            isChecked
                              ? 'bg-emerald-950/30 border-emerald-500/40 text-slate-200'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-900/80'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) =>
                              setLv3CheckedRequirements({
                                ...lv3CheckedRequirements,
                                [idx]: e.target.checked,
                              })
                            }
                            className="mt-0.5 rounded border-slate-700 text-emerald-500 focus:ring-0"
                          />
                          <span className="text-xs md:text-sm font-medium leading-relaxed">{req}</span>
                        </label>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400 pt-2">
                    <span>
                      暗唱済要件:{' '}
                      <strong className="text-emerald-400 font-mono">
                        {Object.values(lv3CheckedRequirements).filter(Boolean).length}/
                        {currentTheory.lv3KeyRequirements.length}
                      </strong>
                    </span>
                    <button
                      onClick={() => {
                        const total = currentTheory.lv3KeyRequirements.length;
                        const checked = Object.values(lv3CheckedRequirements).filter(Boolean).length;
                        const score = Math.round((checked / total) * 100);
                        handleSelfGrade(score);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white transition"
                    >
                      要件チェック結果を保存
                    </button>
                  </div>
                </div>
              )}

              {(currentLevel === 4 || currentLevel === 5) && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-amber-400" />
                      <span>{currentLevel === 5 ? '【Lv.5 制限時間アタック】' : '【Lv.4 白紙アウトプット】'} テキストを見ずに答案を作成:</span>
                    </label>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {userAnswerText.length}文字
                    </span>
                  </div>

                  <textarea
                    rows={8}
                    value={userAnswerText}
                    onChange={(e) => setUserAnswerText(e.target.value)}
                    placeholder="(1) 個人住民税における「住所」の意義及びその認定の方法&#10;[1] 住所の意義&#10;「市町村内に住所を有する個人」とは...&#10;[2] みなす規定者に対する課税市町村&#10;市町村は、その市町村の住民基本台帳に記録されていない個人が..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs md:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500 font-mono leading-relaxed resize-y"
                  />

                  {/* Submission and Grading Action Buttons */}
                  <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
                    <button
                      onClick={() => setShowStandardAnswer(!showStandardAnswer)}
                      className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 transition"
                    >
                      {showStandardAnswer ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{showStandardAnswer ? '模範解答を閉じる' : '模範解答と自己照合'}</span>
                    </button>

                    <button
                      onClick={handleAIGrading}
                      disabled={isGrading || !userAnswerText.trim()}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition disabled:opacity-50"
                    >
                      {isGrading ? (
                        <>
                          <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                          <span>Gemini AIが厳格採点中（High Thinking）...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 fill-slate-950" />
                          <span>Gemini厳格採点を受ける</span>
                        </>
                      )}
                    </button>
                  </div>

                  {showStandardAnswer && (
                    <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-400">【理サブ模範解答との自己照合】</span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleSelfGrade(90)}
                            className="px-2.5 py-1 text-[11px] bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 rounded font-bold hover:bg-emerald-900/60"
                          >
                            90点 (合格)
                          </button>
                          <button
                            onClick={() => handleSelfGrade(70)}
                            className="px-2.5 py-1 text-[11px] bg-amber-950/60 border border-amber-700/60 text-amber-300 rounded font-bold hover:bg-amber-900/60"
                          >
                            70点 (惜しい)
                          </button>
                          <button
                            onClick={() => handleSelfGrade(50)}
                            className="px-2.5 py-1 text-[11px] bg-rose-950/60 border border-rose-700/60 text-rose-300 rounded font-bold hover:bg-rose-900/60"
                          >
                            50点 (再特訓)
                          </button>
                        </div>
                      </div>
                      <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">
                        {currentTheory.lv4FullText}
                      </pre>
                    </div>
                  )}
                </div>
              )}

              {/* AI Strict Grading Result Card */}
              {gradeResult && (
                <div className="mt-6 p-4 md:p-6 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/40 shadow-2xl space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                      <div className="text-3xl md:text-4xl font-extrabold font-mono text-white tabular-nums">
                        {gradeResult.score}<span className="text-base text-slate-400 font-normal">点</span>
                      </div>
                      <div>
                        {gradeResult.isPass ? (
                          <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4" /> 合格水準クリア（80点以上）
                          </div>
                        ) : (
                          <div className="text-xs font-bold text-rose-400 flex items-center gap-1">
                            <AlertTriangle className="w-4 h-4" /> 80点未満（不完全再現）
                          </div>
                        )}
                        <div className="text-[11px] text-slate-400">
                          所要時間: {formatSeconds(timerSeconds)}
                        </div>
                      </div>
                    </div>

                    {gradeResult.isPersonalBest && (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 animate-bounce">
                        <Flame className="w-4 h-4 fill-slate-950" />
                        <span>自己ベスト更新 (PR)！</span>
                      </div>
                    )}
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs sm:text-sm text-slate-200 leading-relaxed">
                    <strong className="text-amber-400 font-bold block mb-1">採点官講評:</strong>
                    {gradeResult.summaryComment}
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-xs font-bold text-slate-400">容赦なき減点・欠落分析（克服ポイント）:</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                      {gradeResult.defectBreakdown?.titleMissing?.length > 0 && (
                        <div className="p-2.5 rounded-lg bg-rose-950/30 border border-rose-800/40 text-rose-200">
                          <strong className="block text-rose-300 font-bold mb-1">柱・タイトルの漏れ:</strong>
                          <ul className="list-disc list-inside space-y-0.5">
                            {gradeResult.defectBreakdown.titleMissing.map((item: string, i: number) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {gradeResult.defectBreakdown?.requirementsMissing?.length > 0 && (
                        <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-800/40 text-amber-200">
                          <strong className="block text-amber-300 font-bold mb-1">要件・適用の抜け落ち:</strong>
                          <ul className="list-disc list-inside space-y-0.5">
                            {gradeResult.defectBreakdown.requirementsMissing.map((item: string, i: number) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {gradeResult.defectBreakdown?.numbersOrDatesWrong?.length > 0 && (
                        <div className="p-2.5 rounded-lg bg-pink-950/30 border border-pink-800/40 text-pink-200">
                          <strong className="block text-pink-300 font-bold mb-1">数字・金額・期限の誤り:</strong>
                          <ul className="list-disc list-inside space-y-0.5">
                            {gradeResult.defectBreakdown.numbersOrDatesWrong.map((item: string, i: number) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {gradeResult.defectBreakdown?.crucialKeywordsMissing?.length > 0 && (
                        <div className="p-2.5 rounded-lg bg-cyan-950/30 border border-cyan-800/40 text-cyan-200">
                          <strong className="block text-cyan-300 font-bold mb-1">法令専門用語の欠落:</strong>
                          <ul className="list-disc list-inside space-y-0.5">
                            {gradeResult.defectBreakdown.crucialKeywordsMissing.map((item: string, i: number) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
