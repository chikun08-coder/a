import React, { useState, useMemo, useEffect } from 'react';
import { 
  Play, CheckCircle2, ChevronRight, ChevronDown,
  RotateCcw, X, Plus, BookOpen, Layers, Zap, Check,
  Settings, MessageSquare, GitBranch, Sparkles, HelpCircle, Flame, ExternalLink,
  GraduationCap, Award
} from 'lucide-react';
import { TheoryItem, SubjectId, TheorySubSection, TheoryParentSection, FlowStep, TheorySRSData } from '../../types';
import { firePRCelebration } from '../../utils/confetti';
import { StorageService } from '../../services/storage';
import {
  getJSTDateString,
  getJSTMonthKey,
  getJSTCalendarParts,
  addDaysJST,
  formatCleanPillarHeading,
  deterministicShuffle,
} from '../../utils/date';

interface FastDrillItem {
  id: string;
  theoryId: string;
  theoryNumber: string;
  theoryTitle: string;
  type: 'quiz' | 'cloze' | 'story' | 'flow';
  typeLabel: string;
  badgeColor: string;
  question: string;
  contextSnippet?: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  pillarHeading?: string;
  pillarNum?: string;
  isWeakFocus?: boolean;
}

interface DailyReviewQueueProps {
  theories: TheoryItem[];
  selectedSubject: SubjectId;
  milestones?: import('../../types').MonthlyMilestone[];
  onUpdateTheory: (updated: TheoryItem) => void;
  onRecordStudyTime: (subjectId: SubjectId, minutes: number, note: string) => void;
  getPillarState: (theory: TheoryItem, pillarKey: string, initialStatus?: any) => { status: 'mastered' | 'learning' | 'weak'; lockCount: number };
  updatePillarState: (theory: TheoryItem, pillarKey: string, newStatus: 'mastered' | 'learning' | 'weak', newLockCount: number) => void;
  onSelectTheory: (theoryId: string) => void;
  onNavigateToRoadmap?: () => void;
}

export const DailyReviewQueue: React.FC<DailyReviewQueueProps> = ({
  theories,
  selectedSubject,
  milestones,
  onUpdateTheory,
  onRecordStudyTime,
  getPillarState,
  updatePillarState,
  onSelectTheory,
  onNavigateToRoadmap,
}) => {
  // Modes: 'drill' (サクサク高速ドリル 20問) | 'notion' (Notionトグル暗記 3題)
  const [activeTab, setActiveTab] = useState<'drill' | 'notion'>('drill');

  // Question count settings (user configurable & persisted)
  const [drillQuota, setDrillQuota] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('tax_exam_drill_quota');
      return saved ? parseInt(saved, 10) : 20;
    } catch {
      return 20;
    }
  });

  const [toggleQuota, setToggleQuota] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('tax_exam_toggle_quota');
      return saved ? parseInt(saved, 10) : 3;
    } catch {
      return 3;
    }
  });

  const [showSettings, setShowSettings] = useState<boolean>(false);

  // Drill Player modal state (plays strictly active uncompleted queue or review queue)
  const [isDrillOpen, setIsDrillOpen] = useState<boolean>(false);
  const [drillPlayQueue, setDrillPlayQueue] = useState<FastDrillItem[]>([]);
  const [isDrillReviewMode, setIsDrillReviewMode] = useState<boolean>(false);
  const [currentDrillIndex, setCurrentDrillIndex] = useState<number>(0);
  const [selectedDrillOption, setSelectedDrillOption] = useState<number | null>(null);
  const [isDrillRevealed, setIsDrillRevealed] = useState<boolean>(false);
  const [drillCorrectCount, setDrillCorrectCount] = useState<number>(0);

  // Notion toggle local open/close state
  const [openNotionSections, setOpenNotionSections] = useState<Record<string, boolean>>({});

  // B+C fusion: Rotation offset for "別の3問にチェンジ 🔄" and graduated list toggle
  const [notionShuffleOffset, setNotionShuffleOffset] = useState<number>(0);
  const [showGraduatedList, setShowGraduatedList] = useState<boolean>(false);

  const [justSaved, setJustSaved] = useState<boolean>(false);

  useEffect(() => {
    let timer: any;
    const handleSyncSaved = () => {
      setJustSaved(true);
      clearTimeout(timer);
      timer = setTimeout(() => setJustSaved(false), 2000);
    };
    window.addEventListener('tax_exam_sync_saved', handleSyncSaved);
    return () => {
      window.removeEventListener('tax_exam_sync_saved', handleSyncSaved);
      clearTimeout(timer);
    };
  }, []);

  // Anki Spaced Repetition (SRS) data for full-mastered theories
  const [srsMap, setSrsMap] = useState<Record<string, TheorySRSData>>(() => {
    return StorageService.getTheorySRSData(selectedSubject);
  });

  useEffect(() => {
    setSrsMap(StorageService.getTheorySRSData(selectedSubject));
  }, [selectedSubject]);

  // Helper to add days to YYYY-MM-DD in JST
  const addDaysToDate = (dateStr: string, days: number): string => addDaysJST(dateStr, days);

  // Reactive JST Date (Asia/Tokyo) - Automatically updates at 00:00 JST / morning wake-up!
  const [todayStr, setTodayStr] = useState<string>(() => getJSTDateString());

  useEffect(() => {
    const syncJstDate = () => {
      const latest = getJSTDateString();
      setTodayStr((prev) => (prev !== latest ? latest : prev));
    };
    const handleRolloverEvent = (e: Event) => {
      const detailDate = (e as CustomEvent)?.detail?.date;
      setTodayStr(detailDate || getJSTDateString());
    };

    const interval = setInterval(syncJstDate, 30000);
    window.addEventListener('tax_exam_date_rollover', handleRolloverEvent);
    window.addEventListener('focus', syncJstDate);
    document.addEventListener('visibilitychange', syncJstDate);

    return () => {
      clearInterval(interval);
      window.removeEventListener('tax_exam_date_rollover', handleRolloverEvent);
      window.removeEventListener('focus', syncJstDate);
      document.removeEventListener('visibilitychange', syncJstDate);
    };
  }, []);

  // Anki Interval ladder: 3日 -> 7日 -> 14日 -> 30日 -> 60日
  const getNextAnkiInterval = (currentInterval: number = 0): { nextInterval: number; level: number } => {
    if (currentInterval < 3) return { nextInterval: 3, level: 1 };
    if (currentInterval < 7) return { nextInterval: 7, level: 2 };
    if (currentInterval < 14) return { nextInterval: 14, level: 3 };
    if (currentInterval < 30) return { nextInterval: 30, level: 4 };
    return { nextInterval: 60, level: 5 };
  };

  // Record Anki SRS progression when a theory is cleared or mastered
  const handleRecordSRSProgress = (theoryId: string, isAllMastered: boolean) => {
    if (!isAllMastered) return;
    setSrsMap((prev) => {
      const current = prev[theoryId];
      const prevInterval = current?.intervalDays || 0;
      const { nextInterval, level } = getNextAnkiInterval(prevInterval);
      const nextDueDate = addDaysToDate(todayStr, nextInterval);

      const updatedItem: TheorySRSData = {
        theoryId,
        intervalDays: nextInterval,
        level,
        lastReviewedDate: todayStr,
        nextDueDate,
        lapseCount: current?.lapseCount || 0,
      };

      const nextMap = { ...prev, [theoryId]: updatedItem };
      StorageService.saveTheorySRSData(selectedSubject, nextMap);
      return nextMap;
    });
  };

  // Record Anki Lapse (忘却検知) when a graduated theory receives ❌ or ○
  const handleRecordSRSLapse = (theoryId: string) => {
    setSrsMap((prev) => {
      const current = prev[theoryId];
      if (!current) return prev;
      const updatedItem: TheorySRSData = {
        ...current,
        intervalDays: 3,
        level: 1,
        lastReviewedDate: todayStr,
        nextDueDate: addDaysToDate(todayStr, 1),
        lapseCount: (current.lapseCount || 0) + 1,
      };
      const nextMap = { ...prev, [theoryId]: updatedItem };
      StorageService.saveTheorySRSData(selectedSubject, nextMap);
      return nextMap;
    });
  };

  const drillDoneKey = `tax_exam_drill_done_${selectedSubject}_${todayStr}`;
  const toggleDoneKey = `tax_exam_toggle_done_${selectedSubject}_${todayStr}`;
  const completedDrillItemsKey = `tax_exam_drill_completed_items_${selectedSubject}_${todayStr}`;
  const completedTheoriesKey = `tax_exam_notion_completed_theories_${selectedSubject}_${todayStr}`;

  const [drillDoneToday, setDrillDoneToday] = useState<boolean>(() => {
    try {
      const k = `tax_exam_drill_done_${selectedSubject}_${getJSTDateString()}`;
      return localStorage.getItem(k) === 'true';
    } catch {
      return false;
    }
  });

  const [toggleDoneToday, setToggleDoneToday] = useState<boolean>(() => {
    try {
      const k = `tax_exam_toggle_done_${selectedSubject}_${getJSTDateString()}`;
      return localStorage.getItem(k) === 'true';
    } catch {
      return false;
    }
  });

  // Per-item completion sets for today (resets cleanly to {} when JST date rolls over!)
  const [completedDrillIds, setCompletedDrillIds] = useState<Record<string, boolean>>(() => {
    try {
      const k = `tax_exam_drill_completed_items_${selectedSubject}_${getJSTDateString()}`;
      const saved = localStorage.getItem(k);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [completedTheoryIds, setCompletedTheoryIds] = useState<Record<string, boolean>>(() => {
    try {
      const k = `tax_exam_notion_completed_theories_${selectedSubject}_${getJSTDateString()}`;
      const saved = localStorage.getItem(k);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Toggle to view completed items ("また見れる機能")
  const [showCompletedDrill, setShowCompletedDrill] = useState<boolean>(false);
  const [showCompletedNotion, setShowCompletedNotion] = useState<boolean>(false);

  useEffect(() => {
    const handleReload = () => {
      try {
        setDrillDoneToday(localStorage.getItem(drillDoneKey) === 'true');
        setToggleDoneToday(localStorage.getItem(toggleDoneKey) === 'true');
        const savedDrill = localStorage.getItem(completedDrillItemsKey);
        setCompletedDrillIds(savedDrill ? JSON.parse(savedDrill) : {});
        const savedTheories = localStorage.getItem(completedTheoriesKey);
        setCompletedTheoryIds(savedTheories ? JSON.parse(savedTheories) : {});
        setSrsMap(StorageService.getTheorySRSData(selectedSubject));
      } catch {
        setDrillDoneToday(false);
        setToggleDoneToday(false);
        setCompletedDrillIds({});
        setCompletedTheoryIds({});
      }
    };

    handleReload();
    window.addEventListener('tax_exam_sync_updated', handleReload);
    window.addEventListener('storage', handleReload);
    return () => {
      window.removeEventListener('tax_exam_sync_updated', handleReload);
      window.removeEventListener('storage', handleReload);
    };
  }, [drillDoneKey, toggleDoneKey, completedDrillItemsKey, completedTheoriesKey, selectedSubject]);

  // Handler to mark an individual drill item as completed
  const handleMarkDrillItemCompleted = (itemId: string) => {
    setCompletedDrillIds((prev) => {
      const next = { ...prev, [itemId]: true };
      try {
        localStorage.setItem(completedDrillItemsKey, JSON.stringify(next));
      } catch {}
      return next;
    });
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  // Helper to extract parent sections for a theory
  const getParentSectionsForTheory = (theory: TheoryItem): TheoryParentSection[] => {
    if (theory.parentSections && theory.parentSections.length > 0) {
      return theory.parentSections;
    }
    if (theory.structuredSubSections && theory.structuredSubSections.length > 0) {
      return [
        {
          id: `p-${theory.id}`,
          num: '〔1〕',
          heading: '本問の主要柱構成',
          subSections: theory.structuredSubSections,
        },
      ];
    }
    return [
      {
        id: `p-${theory.id}`,
        num: '〔1〕',
        heading: '答案構成・柱一覧',
        subSections: (theory.lv2Outline || []).map((line, idx) => ({
          num: `[${idx + 1}]`,
          heading: line,
          body: line,
        })),
      },
    ];
  };

  // Helper to compute theory mastery & graduation status (全柱◎マスター判定)
  const getTheoryMasteryStats = (theory: TheoryItem) => {
    const parents = getParentSectionsForTheory(theory);
    let totalPillars = 0;
    let masteredPillars = 0;
    let learningPillars = 0;
    let weakPillars = 0;

    parents.forEach((p) => {
      (p.subSections || []).forEach((s) => {
        totalPillars++;
        const state = getPillarState(theory, s.heading, s.status);
        if (state.status === 'mastered') masteredPillars++;
        else if (state.status === 'learning') learningPillars++;
        else weakPillars++;
      });
    });

    const isGraduated = totalPillars > 0 && masteredPillars === totalPillars;
    const hasWeak = weakPillars > 0;
    const hasLearning = learningPillars > 0;
    const isStarted = masteredPillars > 0 || learningPillars > 0 || (theory.history && theory.history.length > 0) || (theory.bestScore > 0);

    return {
      theory,
      totalPillars,
      masteredPillars,
      learningPillars,
      weakPillars,
      isGraduated,
      hasWeak,
      hasLearning,
      isStarted,
      remainingToGraduate: Math.max(0, totalPillars - masteredPillars),
    };
  };

  // Handler to mark an individual Notion theory as completed
  const handleMarkTheoryCompleted = (theoryId: string, theoryTitle: string) => {
    setCompletedTheoryIds((prev) => {
      const next = { ...prev, [theoryId]: true };
      try {
        localStorage.setItem(completedTheoriesKey, JSON.stringify(next));
      } catch {}

      // If all daily theories are now completed, mark toggleDoneToday = true
      const isAllNowCompleted = notionDailyTheories.every(
        (t) => t.id === theoryId || next[t.id]
      );
      if (isAllNowCompleted) {
        setToggleDoneToday(true);
        try {
          localStorage.setItem(toggleDoneKey, 'true');
        } catch {}
      }

      return next;
    });

    // Advance Anki SRS interval (3 -> 7 -> 14 -> 30日)
    handleRecordSRSProgress(theoryId, true);

    firePRCelebration();
    onRecordStudyTime(selectedSubject, 5, `Notionトグル暗記（${theoryTitle}）完了`);
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  // Handler to restore/uncomplete an individual Notion theory or drill item
  const handleUnmarkTheoryCompleted = (theoryId: string) => {
    setCompletedTheoryIds((prev) => {
      const next = { ...prev };
      delete next[theoryId];
      try {
        localStorage.setItem(completedTheoriesKey, JSON.stringify(next));
      } catch {}
      return next;
    });
    setToggleDoneToday(false);
    try {
      localStorage.removeItem(toggleDoneKey);
    } catch {}
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  const handleUnmarkDrillItemCompleted = (itemId: string) => {
    setCompletedDrillIds((prev) => {
      const next = { ...prev };
      delete next[itemId];
      try {
        localStorage.setItem(completedDrillItemsKey, JSON.stringify(next));
      } catch {}
      return next;
    });
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  // Persist quota preferences
  const handleUpdateDrillQuota = (num: number) => {
    setDrillQuota(num);
    try {
      localStorage.setItem('tax_exam_drill_quota', num.toString());
    } catch {}
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  const handleUpdateToggleQuota = (num: number) => {
    setToggleQuota(num);
    try {
      localStorage.setItem('tax_exam_toggle_quota', num.toString());
    } catch {}
    setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 600);
  };

  // Filter subject theories (exclude D-rank theories tested in recent exams from automatic daily review)
  const subjectTheories = useMemo(() => {
    return theories.filter((t) => t.subjectId === selectedSubject && t.priorityRank !== 'D');
  }, [theories, selectedSubject]);

  // Compute memory asset stats
  const assetStats = useMemo(() => {
    let totalPillars = 0;
    let masteredCount = 0;
    let learningCount = 0;
    let weakCount = 0;

    subjectTheories.forEach((theory) => {
      if (theory.parentSections) {
        theory.parentSections.forEach((p) => {
          p.subSections.forEach((s) => {
            totalPillars++;
            const state = getPillarState(theory, s.heading, s.status);
            if (state.status === 'mastered') masteredCount++;
            else if (state.status === 'learning') learningCount++;
            else weakCount++;
          });
        });
      } else if (theory.structuredSubSections) {
        theory.structuredSubSections.forEach((s) => {
          totalPillars++;
          const state = getPillarState(theory, s.heading, s.status);
          if (state.status === 'mastered') masteredCount++;
          else if (state.status === 'learning') learningCount++;
          else weakCount++;
        });
      }
    });

    const retentionPercent = totalPillars > 0 ? Math.round((masteredCount / totalPillars) * 100) : 0;
    return { totalPillars, masteredCount, learningCount, weakCount, retentionPercent };
  }, [subjectTheories, getPillarState]);

  // Current Month Milestone Progress Calculation (Strictly JST)
  const currentMonthData = useMemo(() => {
    const currentMonthKey = getJSTMonthKey();
    const { year, month, day: currentDay, lastDayOfMonth } = getJSTCalendarParts();
    const list = milestones || [];
    const activeMilestone = list.find((m) => m.monthKey === currentMonthKey) || list[0] || {
      monthKey: currentMonthKey,
      label: `${year}年${month}月`,
      phase: 'basic',
      phaseName: '第1期 基礎定着期',
      targetMasteredPillars: 15,
      targetTotalHours: 40,
      focusTheoriesNote: 'Sランク基礎重要論点の骨格確立',
    };

    const currentMastered = assetStats.masteredCount;
    const currentLearning = assetStats.learningCount;
    const target = activeMilestone.targetMasteredPillars;
    const remaining = Math.max(0, target - currentMastered);
    const progressPercent = Math.min(100, Math.round((currentMastered / Math.max(1, target)) * 100));

    const daysLeft = Math.max(1, lastDayOfMonth - currentDay + 1);
    const dailyPace = remaining > 0 ? (remaining / daysLeft).toFixed(1) : '0';

    const expectedRateByDay = (currentDay / lastDayOfMonth) * target;
    let paceStatus: 'ahead' | 'on_track' | 'behind' = 'on_track';
    let paceLabel = '順調（目標ペース維持）';
    let paceColor = 'text-emerald-400 bg-emerald-950/60 border-emerald-700/60';

    if (currentMastered >= target) {
      paceStatus = 'ahead';
      paceLabel = '今月目標達成！前倒し中';
      paceColor = 'text-yellow-300 bg-yellow-950/60 border-yellow-500/60';
    } else if (currentMastered >= expectedRateByDay) {
      paceStatus = 'ahead';
      paceLabel = '前倒しペースで進行中';
      paceColor = 'text-cyan-300 bg-cyan-950/60 border-cyan-700/60';
    } else if (currentMastered + currentLearning * 0.5 < expectedRateByDay * 0.7) {
      paceStatus = 'behind';
      paceLabel = '要加速（ペースアップ推奨）';
      paceColor = 'text-rose-300 bg-rose-950/60 border-rose-700/60';
    }

    return {
      milestone: activeMilestone,
      target,
      currentMastered,
      currentLearning,
      remaining,
      progressPercent,
      daysLeft,
      dailyPace,
      paceStatus,
      paceLabel,
      paceColor,
    };
  }, [milestones, assetStats, todayStr]);

  // =========================================================================
  // 1. FAST DRILL DECK GENERATION (苦手柱・Anki期日優先 + 選択肢完全シャッフル)
  // =========================================================================
  const fastDrillDeck = useMemo<FastDrillItem[]>(() => {
    const tier1WeakOrDue: FastDrillItem[] = [];
    const tier2Active: FastDrillItem[] = [];
    const tier3Graduated: FastDrillItem[] = [];

    // Build realistic cross-theory distractor pools so [A] is NEVER predictably the answer
    const globalKeywordsPool = Array.from(
      new Set(subjectTheories.flatMap((t) => t.clozeKeywords || []))
    );
    const globalStoryRepliesPool = Array.from(
      new Set(
        subjectTheories.flatMap((t) =>
          (t.storyDialogue || [])
            .filter((d) => d.side === 'right' && d.text)
            .map((d) => (d.text.length > 58 ? d.text.slice(0, 56) + '...' : d.text))
        )
      )
    );
    const globalFlowOutcomesPool = Array.from(
      new Set(subjectTheories.flatMap((t) => (t.flowSteps || []).map((f) => f.outcome).filter(Boolean)))
    );

    const shuffleItemOptions = (
      correctOption: string,
      rawDistractors: string[],
      fallbackPool: string[],
      itemId: string
    ): { options: string[]; correctIndex: number } => {
      const uniqueDistractors: string[] = [];
      for (const d of rawDistractors) {
        if (d && d !== correctOption && !uniqueDistractors.includes(d)) {
          uniqueDistractors.push(d);
        }
      }
      if (uniqueDistractors.length < 2) {
        const extra = deterministicShuffle(fallbackPool, `${itemId}_pool_${todayStr}`);
        for (const e of extra) {
          if (e && e !== correctOption && !uniqueDistractors.includes(e)) {
            uniqueDistractors.push(e);
            if (uniqueDistractors.length >= 3) break;
          }
        }
      }
      const combined = [correctOption, ...uniqueDistractors.slice(0, 3)];
      const shuffled = deterministicShuffle(combined, `${itemId}_opts_${todayStr}`);
      return {
        options: shuffled,
        correctIndex: Math.max(0, shuffled.indexOf(correctOption)),
      };
    };

    // Snapshot initial mastery per theory ONLY seeded by date so mid-drill pillar taps don't reshuffle the deck
    subjectTheories.forEach((theory) => {
      const stats = getTheoryMasteryStats(theory);
      const srs = srsMap[theory.id];
      const isDue = stats.isGraduated && (!srs || !srs.nextDueDate || srs.nextDueDate <= todayStr);
      const theoryHasWeakOrDue = stats.hasWeak || isDue;

      const pushToTier = (item: FastDrillItem, pillarIsWeak: boolean) => {
        if (pillarIsWeak || theoryHasWeakOrDue) {
          tier1WeakOrDue.push({ ...item, isWeakFocus: true });
        } else if (!stats.isGraduated) {
          tier2Active.push(item);
        } else {
          tier3Graduated.push(item);
        }
      };

      // (1) 3-Sec Quick Knock Questions (shuffle options deterministically!)
      if (theory.quickKnockQuestions && theory.quickKnockQuestions.length > 0) {
        theory.quickKnockQuestions.forEach((q, qIdx) => {
          const itemId = `drill-quiz-${theory.id}-${q.id || qIdx}`;
          const correctText = q.options[q.correctIndex] ?? q.options[0] ?? '';
          const otherOpts = q.options.filter((_, idx) => idx !== q.correctIndex);
          const { options, correctIndex } = shuffleItemOptions(correctText, otherOpts, [], itemId);

          pushToTier(
            {
              id: itemId,
              theoryId: theory.id,
              theoryNumber: theory.theoryNumber,
              theoryTitle: theory.title,
              type: 'quiz',
              typeLabel: '⚡ 3秒即答',
              badgeColor: 'bg-amber-950 text-amber-300 border-amber-700/60',
              question: q.question,
              options,
              correctIndex,
              explanation: q.tip,
            },
            stats.hasWeak
          );
        });
      }

      // (2) Cloze Test Questions (虫食い穴埋め)
      if (theory.clozeKeywords && theory.clozeKeywords.length > 0) {
        const subSecs = theory.parentSections
          ? theory.parentSections.flatMap((p) => p.subSections)
          : theory.structuredSubSections || [];

        subSecs.forEach((sec, sIdx) => {
          const matchedKw = theory.clozeKeywords?.find((kw) => sec.body.includes(kw));
          if (matchedKw && sec.body.length > 20) {
            const itemId = `drill-cloze-${theory.id}-${sIdx}`;
            const sentences = sec.body.split('。').filter((s) => s.includes(matchedKw));
            const targetSentence = sentences[0] ? sentences[0] + '。' : sec.body.slice(0, 100) + '...';
            const maskedSentence = targetSentence.replace(matchedKw, '【 ❓ ？？？ 】');

            const sameTheoryKws = deterministicShuffle(
              (theory.clozeKeywords || []).filter((k) => k !== matchedKw),
              `${itemId}_kw_${todayStr}`
            );
            const { options, correctIndex } = shuffleItemOptions(
              matchedKw,
              sameTheoryKws.slice(0, 3),
              [...globalKeywordsPool, '住民基本台帳', '賦課期日現在', '申告納付'],
              itemId
            );
            const pState = getPillarState(theory, sec.heading, sec.status);

            pushToTier(
              {
                id: itemId,
                theoryId: theory.id,
                theoryNumber: theory.theoryNumber,
                theoryTitle: theory.title,
                type: 'cloze',
                typeLabel: '🕳️ 虫食い穴埋め',
                badgeColor: 'bg-emerald-950 text-emerald-300 border-emerald-700/60',
                question: `空欄【 ❓ 】に入る税法上の正確な用語はどれ？`,
                contextSnippet: maskedSentence,
                options,
                correctIndex,
                explanation: `正解は「${matchedKw}」！${sec.essence ? '（💡 ' + sec.essence + '）' : ''}`,
                pillarHeading: sec.heading,
                pillarNum: sec.num,
              },
              pState.status === 'weak'
            );
          }
        });
      }

      // (3) Character Story Dialogue Questions (キャラ図解会話 - realistic shuffled options!)
      if (theory.storyDialogue && theory.storyDialogue.length >= 2) {
        for (let dIdx = 0; dIdx < theory.storyDialogue.length - 1; dIdx += 2) {
          const speaker1 = theory.storyDialogue[dIdx];
          const speaker2 = theory.storyDialogue[dIdx + 1];
          if (speaker1 && speaker2 && speaker1.side === 'left' && speaker2.side === 'right') {
            const itemId = `drill-story-${theory.id}-${dIdx}`;
            const correctReply =
              speaker2.text.length > 58 ? speaker2.text.slice(0, 56) + '...' : speaker2.text;
            const statutoryTraps = [
              '住民基本台帳の登録地のみによって形式的に判定し、生活の本拠の実態は問わない。',
              '納税義務者の選択により、所得税または個人住民税のいずれか一方のみを納付すれば足りる。',
              '前年中ではなく、納付書が送達された日現在の現況によって課税要件を判定する。',
            ];
            const { options, correctIndex } = shuffleItemOptions(
              correctReply,
              [],
              [...globalStoryRepliesPool, ...statutoryTraps],
              itemId
            );

            pushToTier(
              {
                id: itemId,
                theoryId: theory.id,
                theoryNumber: theory.theoryNumber,
                theoryTitle: theory.title,
                type: 'story',
                typeLabel: '💬 キャラ会話問答',
                badgeColor: 'bg-purple-950 text-purple-300 border-purple-700/60',
                question: `${speaker1.speaker}の相談・疑問に対する、課税課の正確な税法判断は？`,
                contextSnippet: `${speaker1.speaker}: 「${speaker1.text}」`,
                options,
                correctIndex,
                explanation: `役所の回答: 「${speaker2.text}」`,
              },
              stats.hasWeak
            );
          }
        }
      }

      // (4) Flow Step Questions (構造フロー図判定 - realistic shuffled options!)
      if (theory.flowSteps && theory.flowSteps.length > 0) {
        const subSecs = theory.parentSections
          ? theory.parentSections.flatMap((p) => p.subSections)
          : theory.structuredSubSections || [];

        theory.flowSteps.forEach((flow, fIdx) => {
          const itemId = `drill-flow-${theory.id}-${fIdx}`;
          const sameTheoryOtherOutcomes = (theory.flowSteps || [])
            .filter((_, idx) => idx !== fIdx)
            .map((f) => f.outcome)
            .filter((o) => o && o !== flow.outcome);

          const { options, correctIndex } = shuffleItemOptions(
            flow.outcome,
            sameTheoryOtherOutcomes.slice(0, 2),
            [
              ...globalFlowOutcomesPool,
              '均等割のみが課税され、所得割は常に非課税となる。',
              '市町村長の職権ではなく、本人の確定申告があった場合に限り適用される。',
            ],
            itemId
          );

          const matchedSec = subSecs.find(
            (s) => s.heading === flow.title || s.heading.includes(flow.title) || flow.title.includes(s.heading)
          );
          const matchedHeading = matchedSec ? matchedSec.heading : undefined;
          const isPillarWeak = matchedSec
            ? getPillarState(theory, matchedSec.heading, matchedSec.status).status === 'weak'
            : stats.hasWeak;

          pushToTier(
            {
              id: itemId,
              theoryId: theory.id,
              theoryNumber: theory.theoryNumber,
              theoryTitle: theory.title,
              type: 'flow',
              typeLabel: '🗺️ 判定フロー',
              badgeColor: 'bg-blue-950 text-blue-300 border-blue-700/60',
              question: `【${flow.title}】における税法上の結論・法的効果は？`,
              contextSnippet: `前提: ${flow.actionOrCondition} ➔ 判定: ${flow.judgment}`,
              options,
              correctIndex,
              explanation: `正解: ${flow.outcome}（要件: ${flow.judgment}）`,
              pillarHeading: matchedHeading,
              pillarNum: flow.pillarNum,
            },
            isPillarWeak
          );
        });
      }
    });

    // Deterministically shuffle each priority tier by subject + JST date
    // Lock daily drill IDs in localStorage for today so toggling ◎/○/❌ mid-study never shifts today's deck!
    const deckCacheKey = `tax_exam_drill_daily_ids_${selectedSubject}_${todayStr}_q${drillQuota}`;
    const allItemsMap = new Map<string, FastDrillItem>();
    [...tier1WeakOrDue, ...tier2Active, ...tier3Graduated].forEach((item) => {
      allItemsMap.set(item.id, item);
    });

    try {
      const cachedRaw = localStorage.getItem(deckCacheKey);
      if (cachedRaw) {
        const cachedIds: string[] = JSON.parse(cachedRaw);
        if (Array.isArray(cachedIds) && cachedIds.length > 0) {
          const resolved = cachedIds.map((id) => allItemsMap.get(id)).filter(Boolean) as FastDrillItem[];
          if (resolved.length === Math.min(drillQuota, allItemsMap.size)) {
            return resolved;
          }
        }
      }
    } catch {}

    const s1 = deterministicShuffle(tier1WeakOrDue, `t1_${selectedSubject}_${todayStr}`);
    const s2 = deterministicShuffle(tier2Active, `t2_${selectedSubject}_${todayStr}`);
    const s3 = deterministicShuffle(tier3Graduated, `t3_${selectedSubject}_${todayStr}`);

    const combinedPrioritized = [...s1, ...s2, ...s3].slice(0, drillQuota);
    // Final deterministic mix of the chosen daily items so question types interleave smoothly
    const finalDeck = deterministicShuffle(combinedPrioritized, `mix_${selectedSubject}_${todayStr}`);

    try {
      localStorage.setItem(deckCacheKey, JSON.stringify(finalDeck.map((d) => d.id)));
    } catch {}

    return finalDeck;
  }, [subjectTheories, drillQuota, todayStr, selectedSubject, srsMap]);

  // Active (uncompleted) Drill Deck & Completed Drill Deck
  const activeDrillDeck = useMemo(() => {
    if (drillDoneToday) return [];
    return fastDrillDeck.filter((item) => !completedDrillIds[item.id]);
  }, [fastDrillDeck, completedDrillIds, drillDoneToday]);

  const completedDrillDeck = useMemo(() => {
    return fastDrillDeck.filter((item) => completedDrillIds[item.id]);
  }, [fastDrillDeck, completedDrillIds]);

  // Mastery stats for all subject theories
  const theoriesMasteryList = useMemo(() => {
    return subjectTheories.map(getTheoryMasteryStats);
  }, [subjectTheories, getPillarState]);

  // Graduated (全柱◎達成) vs In-Progress
  const graduatedTheories = useMemo(() => {
    return theoriesMasteryList.filter((m) => m.isGraduated).map((m) => m.theory);
  }, [theoriesMasteryList]);

  const activeNonGraduated = useMemo(() => {
    return theoriesMasteryList.filter((m) => !m.isGraduated);
  }, [theoriesMasteryList]);

  // Monthly Phase & Adaptive Quota Calculation (本試験カレンダー連動)
  const dynamicPhaseInfo = useMemo(() => {
    const phase = currentMonthData.milestone.phase; // 'basic' | 'applied' | 'pre_exam' | 'exam'
    const totalQuota = Math.max(1, toggleQuota);

    let targetReview = 1;
    let targetNew = 2;
    let phaseName = '第1期 基礎定着期';
    let phaseBadge = 'bg-cyan-950/80 text-cyan-300 border-cyan-700/70';
    let phaseRule = '復習 1問 : 新規 2問（骨格インプット優先）';

    if (phase === 'applied') {
      targetReview = 2;
      targetNew = 1;
      phaseName = '第2期 応用展開期';
      phaseBadge = 'bg-indigo-950/80 text-indigo-300 border-indigo-700/70';
      phaseRule = '復習 2問 : 新規 1問（苦手克服＆定着強化）';
    } else if (phase === 'pre_exam' || phase === 'exam') {
      targetReview = totalQuota;
      targetNew = 0;
      phaseName = '第3期 直前総仕上げ期';
      phaseBadge = 'bg-rose-950/80 text-rose-300 border-rose-700/70';
      phaseRule = `復習 ${totalQuota}問 : 新規 0問（全範囲の完全維持・総回転）`;
    }

    return {
      phase,
      phaseName,
      phaseBadge,
      phaseRule,
      targetReview,
      targetNew,
    };
  }, [currentMonthData.milestone.phase, toggleQuota]);

  // Count of Anki SRS due theories (all pillars mastered & nextDueDate <= today)
  const dueTheoriesCount = useMemo(() => {
    return theoriesMasteryList.filter((m) => {
      if (!m.isGraduated) return false;
      const srs = srsMap[m.theory.id];
      return !srs || !srs.nextDueDate || srs.nextDueDate <= todayStr;
    }).length;
  }, [theoriesMasteryList, srsMap, todayStr]);

  // =========================================================================
  // 2. NOTION TOGGLE DAILY THEORIES (Anki SRS × 本試験カレンダー動的配分)
  // =========================================================================
  interface NotionTheorySelection {
    theory: TheoryItem;
    reasonType: 'due_srs' | 'weak_review' | 'learning_review' | 'incubating' | 'new_forward' | 'maintenance';
    reasonBadge: string;
    reasonDesc: string;
    badgeStyle: string;
    remainingToGraduate: number;
    totalPillars: number;
    masteredPillars: number;
    isGraduated: boolean;
    srsData?: TheorySRSData;
    daysOverdue?: number;
  }

  // =========================================================================
  // 2. STABLE DAILY NOTION THEORY IDS (今日受講する3問のIDをセッション・日付で固定ロック)
  // =========================================================================
  const dailyNotionTheoryIds = useMemo<string[]>(() => {
    const quota = Math.min(Math.max(1, toggleQuota), subjectTheories.length || 1);
    const cacheKey = `tax_exam_notion_daily_ids_${selectedSubject}_${todayStr}_q${quota}_s${notionShuffleOffset}`;

    // 1. Check if already locked for today & this shuffle offset
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed: string[] = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length === quota) {
          const allExist = parsed.every((id) => subjectTheories.some((t) => t.id === id));
          if (allExist) {
            return parsed;
          }
        }
      }
    } catch {}

    // 2. Calculate stable selection for today
    const pickedIds: string[] = [];
    const usedIds = new Set<string>();

    // Analyze each theory's Anki SRS and Due status
    const analyzedList = theoriesMasteryList.map((m) => {
      const srs = srsMap[m.theory.id];
      const isDue = m.isGraduated && (!srs || !srs.nextDueDate || srs.nextDueDate <= todayStr);
      let daysOverdue = 0;
      if (srs?.nextDueDate && srs.nextDueDate <= todayStr) {
        const diffMs = new Date(todayStr).getTime() - new Date(srs.nextDueDate).getTime();
        daysOverdue = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
      }
      return {
        ...m,
        srs,
        isDue,
        daysOverdue,
      };
    });

    // 1. Due theories (全柱◎だがAnki忘却曲線期日到来)
    const dueCandidates = analyzedList
      .filter((m) => m.isDue)
      .sort((a, b) => {
        if (b.daysOverdue !== a.daysOverdue) return b.daysOverdue - a.daysOverdue;
        return (a.theory.priorityOrder || 99) - (b.theory.priorityOrder || 99);
      });

    // 2. Lapse / Weak / Learning candidates (未完全暗記で苦手・要復習柱がある)
    const weakCandidates = analyzedList
      .filter((m) => !m.isGraduated && m.isStarted && (m.hasWeak || m.hasLearning))
      .sort((a, b) => {
        if (b.weakPillars !== a.weakPillars) return b.weakPillars - a.weakPillars;
        return (a.theory.priorityOrder || 99) - (b.theory.priorityOrder || 99);
      });

    // Combined Review Pool (Due SRS first, then Weak/Learning)
    const reviewPool = [...dueCandidates, ...weakCandidates];

    // 3. Incubating candidates (攻略中の未卒業論点)
    const incubatingCandidates = analyzedList
      .filter((m) => !m.isGraduated && m.isStarted && !m.hasWeak && !m.hasLearning)
      .sort((a, b) => (a.theory.priorityOrder || 99) - (b.theory.priorityOrder || 99));

    // 4. Fresh New candidates (未着手論点)
    const freshNewCandidates = analyzedList
      .filter((m) => !m.isGraduated && !m.isStarted)
      .sort((a, b) => {
        if (a.theory.theoryNumber === '1-1') return -1;
        if (b.theory.theoryNumber === '1-1') return 1;
        return (a.theory.priorityOrder || 99) - (b.theory.priorityOrder || 99);
      });

    // Forward Pool (Incubating first, then Fresh)
    const forwardPool = [...incubatingCandidates, ...freshNewCandidates];

    // Dynamic quota targets from phase
    let targetReview = dynamicPhaseInfo.targetReview;

    // Anki Rule: If due reviews exceed targetReview, expand review slots to prevent forgetting!
    if (dueCandidates.length > targetReview) {
      targetReview = Math.min(quota, dueCandidates.length);
    }
    if (forwardPool.length === 0) {
      targetReview = quota;
    }

    // A. Fill Review Slots
    const availableReview = reviewPool.filter((m) => !usedIds.has(m.theory.id));
    const reviewOffset = (notionShuffleOffset) % Math.max(1, availableReview.length);
    const orderedReview = [
      ...availableReview.slice(reviewOffset),
      ...availableReview.slice(0, reviewOffset),
    ];
    for (const cand of orderedReview) {
      if (pickedIds.length >= targetReview) break;
      usedIds.add(cand.theory.id);
      pickedIds.push(cand.theory.id);
    }

    // B. Fill New / Forward Slots
    const availableForward = forwardPool.filter((m) => !usedIds.has(m.theory.id));
    const forwardOffset = (Math.floor(notionShuffleOffset / Math.max(1, reviewPool.length || 1))) % Math.max(1, availableForward.length);
    const orderedForward = [
      ...availableForward.slice(forwardOffset),
      ...availableForward.slice(0, forwardOffset),
    ];
    for (const cand of orderedForward) {
      if (pickedIds.length >= quota) break;
      usedIds.add(cand.theory.id);
      pickedIds.push(cand.theory.id);
    }

    // C. Fallback: Fill any remaining quota from whatever is available
    if (pickedIds.length < quota) {
      const remainingCandidates = analyzedList.filter((m) => !usedIds.has(m.theory.id));
      for (const cand of remainingCandidates) {
        if (pickedIds.length >= quota) break;
        usedIds.add(cand.theory.id);
        pickedIds.push(cand.theory.id);
      }
    }

    // Lock the chosen IDs for today so user actions (◎○❌) don't jump the menu mid-session!
    try {
      localStorage.setItem(cacheKey, JSON.stringify(pickedIds));
    } catch {}

    return pickedIds;
  }, [
    subjectTheories,
    theoriesMasteryList,
    srsMap,
    toggleQuota,
    notionShuffleOffset,
    dynamicPhaseInfo,
    todayStr,
    selectedSubject,
  ]);

  const notionDailyTheories = useMemo<TheoryItem[]>(() => {
    return dailyNotionTheoryIds
      .map((id) => subjectTheories.find((t) => t.id === id))
      .filter(Boolean) as TheoryItem[];
  }, [dailyNotionTheoryIds, subjectTheories]);

  // Map to get selection metadata & reason badge for any theory id
  const notionDailySelection = useMemo<NotionTheorySelection[]>(() => {
    return notionDailyTheories.map((theory) => {
      const stats = getTheoryMasteryStats(theory);
      const srs = srsMap[theory.id];
      const isDue = stats.isGraduated && (!srs || !srs.nextDueDate || srs.nextDueDate <= todayStr);
      let daysOverdue = 0;
      if (srs?.nextDueDate && srs.nextDueDate <= todayStr) {
        const diffMs = new Date(todayStr).getTime() - new Date(srs.nextDueDate).getTime();
        daysOverdue = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
      }

      let reasonType: NotionTheorySelection['reasonType'] = 'new_forward';
      let reasonBadge = '✨ 新規前進';
      let reasonDesc = '重要論点の骨格インプット';
      let badgeStyle = 'bg-indigo-950/80 text-indigo-300 border-indigo-700/80';

      if (isDue) {
        reasonType = 'due_srs';
        reasonBadge = '👑 定着復習（Anki期日）';
        reasonDesc = srs?.intervalDays
          ? `前回◎から${srs.intervalDays}日経過（忘却防止チェック）`
          : '忘却曲線による期日到来（定着想起）';
        badgeStyle = 'bg-yellow-950/80 text-yellow-300 border-yellow-600/80';
      } else if (stats.isGraduated) {
        reasonType = 'maintenance';
        reasonBadge = '👑 卒業生（全柱◎）';
        reasonDesc = '全柱マスター維持チェック';
        badgeStyle = 'bg-yellow-950/80 text-yellow-300 border-yellow-600/80';
      } else if (stats.hasWeak) {
        reasonType = 'weak_review';
        reasonBadge = '🔥 苦手復習';
        reasonDesc = `❌の柱が${stats.weakPillars}本残っています（忘却克服）`;
        badgeStyle = 'bg-rose-950/80 text-rose-300 border-rose-700/80';
      } else if (stats.hasLearning) {
        reasonType = 'learning_review';
        reasonBadge = '⚡ 要復習';
        reasonDesc = '○の柱をマスター（◎）へ昇格';
        badgeStyle = 'bg-amber-950/80 text-amber-300 border-amber-700/80';
      } else if (stats.isStarted) {
        reasonType = 'incubating';
        reasonBadge = `🌱 育成中（◎まであと${stats.remainingToGraduate}柱）`;
        reasonDesc = '全柱マスター（◎）で卒業＆Ankiサイクルへ';
        badgeStyle = 'bg-emerald-950/80 text-emerald-300 border-emerald-700/80';
      }

      return {
        theory,
        reasonType,
        reasonBadge,
        reasonDesc,
        badgeStyle,
        remainingToGraduate: stats.remainingToGraduate,
        totalPillars: stats.totalPillars,
        masteredPillars: stats.masteredPillars,
        isGraduated: stats.isGraduated,
        srsData: srs,
        daysOverdue,
      };
    });
  }, [notionDailyTheories, srsMap, todayStr]);

  const notionDailyMap = useMemo(() => {
    const map = new Map<string, NotionTheorySelection>();
    notionDailySelection.forEach((s) => map.set(s.theory.id, s));
    return map;
  }, [notionDailySelection]);

  // Active (uncompleted) Notion Theories & Completed Notion Theories
  const activeNotionTheories = useMemo(() => {
    return notionDailyTheories.filter((t) => !completedTheoryIds[t.id]);
  }, [notionDailyTheories, completedTheoryIds]);

  const completedNotionTheories = useMemo(() => {
    return notionDailyTheories.filter((t) => completedTheoryIds[t.id]);
  }, [notionDailyTheories, completedTheoryIds]);

  // Drill player navigation (plays strictly uncompleted active items or review queue!)
  const activeModalQueue = drillPlayQueue.length > 0 ? drillPlayQueue : fastDrillDeck;
  const currentDrillItem = activeModalQueue[currentDrillIndex] || activeModalQueue[0];

  const handleStartDrillRemaining = (customDeck?: FastDrillItem[], startIdx: number = 0, reviewMode: boolean = false) => {
    const targetQueue = customDeck && customDeck.length > 0 ? customDeck : activeDrillDeck.length > 0 ? activeDrillDeck : fastDrillDeck;
    setDrillPlayQueue(targetQueue);
    setIsDrillReviewMode(reviewMode);
    setCurrentDrillIndex(Math.min(startIdx, Math.max(0, targetQueue.length - 1)));
    setSelectedDrillOption(null);
    setIsDrillRevealed(false);
    setDrillCorrectCount(0);
    setIsDrillOpen(true);
  };

  const handleSelectDrillOption = (idx: number) => {
    if (isDrillRevealed) return;
    setSelectedDrillOption(idx);
    setIsDrillRevealed(true);
    if (currentDrillItem && !isDrillReviewMode) {
      handleMarkDrillItemCompleted(currentDrillItem.id);
    }
    if (idx === currentDrillItem?.correctIndex) {
      setDrillCorrectCount((c) => c + 1);
      firePRCelebration();
    }
  };

  const handleNextDrillItem = () => {
    if (currentDrillIndex < activeModalQueue.length - 1) {
      setCurrentDrillIndex((idx) => idx + 1);
      setSelectedDrillOption(null);
      setIsDrillRevealed(false);
    } else {
      firePRCelebration();
      if (!isDrillReviewMode) {
        const allFinishedNow = fastDrillDeck.every(
          (item) => item.id === currentDrillItem?.id || completedDrillIds[item.id]
        );
        if (allFinishedNow) {
          setDrillDoneToday(true);
          try {
            localStorage.setItem(drillDoneKey, 'true');
          } catch {}
          onRecordStudyTime(
            selectedSubject,
            Math.max(5, Math.round(fastDrillDeck.length * 0.5)),
            `高速サクサクドリル（${fastDrillDeck.length}問）完了`
          );
          setTimeout(() => {
            StorageService.pushToServer().catch(() => {});
          }, 400);
        }
      }
      setIsDrillOpen(false);
    }
  };

  // Shared Pillar Evaluation helper for Notion Toggle (1-tap header & body buttons)
  const handleEvaluateNotionPillar = (
    theory: TheoryItem,
    sec: TheorySubSection,
    targetStatus: 'mastered' | 'learning' | 'weak'
  ) => {
    if (targetStatus === 'weak') {
      updatePillarState(theory, sec.heading, 'weak', 0);
      if (srsMap[theory.id]) {
        handleRecordSRSLapse(theory.id);
      }
      return;
    }
    if (targetStatus === 'learning') {
      updatePillarState(theory, sec.heading, 'learning', 1);
      if (srsMap[theory.id]) {
        handleRecordSRSLapse(theory.id);
      }
      return;
    }
    // targetStatus === 'mastered'
    updatePillarState(theory, sec.heading, 'mastered', 2);
    firePRCelebration();

    const parentSecs = getParentSectionsForTheory(theory);
    let allDone = true;
    parentSecs.forEach((p) => {
      (p.subSections || []).forEach((s) => {
        if (s.heading === sec.heading) return;
        const curState = getPillarState(theory, s.heading, s.status);
        if (curState.status !== 'mastered') allDone = false;
      });
    });
    if (allDone) {
      handleRecordSRSProgress(theory.id, true);
    }
  };

  const toggleNotionItem = (key: string) => {
    setOpenNotionSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 sm:p-5 shadow-xl space-y-4">
      {/* 🎯 Monthly Milestone & Progress Tracker Banner (今月の目標とリアルタイム進捗) */}
      <div className="p-3 sm:p-4 rounded-xl bg-gradient-to-r from-slate-950 via-slate-950 to-indigo-950/40 border border-indigo-500/30 space-y-2.5 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-mono font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-md">
              {currentMonthData.milestone.label}
            </span>
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>🎯 今月の暗記目標:</span>
              <strong className="text-amber-300 font-mono text-sm">{currentMonthData.target}本</strong>
              <span className="text-slate-400 font-normal">（{currentMonthData.milestone.phaseName}）</span>
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${currentMonthData.paceColor}`}>
              {currentMonthData.paceLabel}
            </span>
          </div>

          {onNavigateToRoadmap && (
            <button
              onClick={onNavigateToRoadmap}
              className="text-[11px] font-bold text-indigo-300 hover:text-white flex items-center gap-1 self-start sm:self-auto cursor-pointer transition group"
            >
              <span>8月本試験までの全月別目標を見る</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}
        </div>

        {/* Progress Bar & Pace Counter */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 flex items-center gap-2 flex-wrap">
              <span>進捗: <strong className="text-emerald-400 font-black">{currentMonthData.currentMastered}本</strong> 完璧◎</span>
              <span className="text-slate-500">·</span>
              <span className="text-amber-400">{currentMonthData.currentLearning}本 骨格○</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400 font-sans">
                {currentMonthData.remaining > 0 ? (
                  <>目標まであと <strong className="text-rose-300">{currentMonthData.remaining}本</strong>（日割 {currentMonthData.dailyPace}本/日）</>
                ) : (
                  <strong className="text-emerald-300">🎉 今月目標クリア！</strong>
                )}
              </span>
            </span>
            <span className="font-bold text-white tabular-nums">
              {currentMonthData.progressPercent}%
            </span>
          </div>

          <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-gradient-to-r from-amber-400 via-emerald-400 to-indigo-400 rounded-full transition-all duration-500"
              style={{ width: `${currentMonthData.progressPercent}%` }}
            />
          </div>
        </div>

        {/* Focus Theories Note */}
        {currentMonthData.milestone.focusTheoriesNote && (
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 bg-slate-900/60 px-2.5 py-1 rounded-lg border border-slate-850">
            <span className="text-amber-400 font-bold shrink-0">📌 今月の重点:</span>
            <span className="truncate text-slate-300">{currentMonthData.milestone.focusTheoriesNote}</span>
          </div>
        )}
      </div>

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm sm:text-base font-black text-white flex items-center gap-1.5">
              <span>📅 本日のメニュー</span>
            </span>

            {/* Badges for completion */}
            {drillDoneToday && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-black border border-emerald-700/60 flex items-center gap-1">
                <Check className="w-3 h-3" />
                <span>ドリル完了</span>
              </span>
            )}
            {toggleDoneToday && (
              <span className="px-2 py-0.5 rounded-full bg-indigo-950 text-indigo-300 text-[10px] font-black border border-indigo-700/60 flex items-center gap-1">
                <Check className="w-3 h-3" />
                <span>Notion3題完了</span>
              </span>
            )}
          </div>

          {/* Memory Asset Meter */}
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <span className="text-xs font-mono font-bold text-slate-300">
              記憶の定着資産: <strong className="text-emerald-400">{assetStats.masteredCount}</strong> / {assetStats.totalPillars}本 ({assetStats.retentionPercent}%)
            </span>
            <div className="w-28 sm:w-40 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800 shrink-0">
              <div 
                className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-500 rounded-full"
                style={{ width: `${assetStats.retentionPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right side controls: Settings button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              showSettings
                ? 'bg-amber-500 text-slate-950 border-amber-400'
                : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
            title="問題数設定を変更"
          >
            <Settings className="w-3.5 h-3.5" />
            <span className="text-[11px]">問題数変更</span>
          </button>
        </div>
      </div>

      {/* Settings Panel (Dropdown drawer) */}
      {showSettings && (
        <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-500/30 space-y-3 animate-in fade-in duration-150 text-xs">
          <div className="font-bold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-amber-300">
              <Settings className="w-3.5 h-3.5" />
              <span>毎日の問題数・題数カスタム設定</span>
            </span>
            <button
              onClick={() => setShowSettings(false)}
              className="text-slate-400 hover:text-white text-[11px]"
            >
              閉じる
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {/* Fast Drill Quota */}
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5">
              <div className="font-bold text-slate-300 flex items-center justify-between">
                <span>⚡ 高速サクサクドリル</span>
                <span className="text-amber-400 font-mono font-black">{drillQuota}問</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                3秒即答・虫食い・キャラ会話・フロー図判定をテンポよく解く問題数
              </p>
              <div className="flex items-center gap-1.5 pt-1">
                {[5, 10, 20, 30].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleUpdateDrillQuota(num)}
                    className={`flex-1 py-1 rounded text-[11px] font-bold border transition ${
                      drillQuota === num
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {num}問{num === 20 ? '🔥' : ''}
                  </button>
                ))}
              </div>
            </div>

            {/* Notion Toggle Quota */}
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5">
              <div className="font-bold text-slate-300 flex items-center justify-between">
                <span>📑 Notionトグル骨格暗記</span>
                <span className="text-indigo-400 font-mono font-black">{toggleQuota}題</span>
              </div>
              <p className="text-[10px] text-slate-400 leading-snug">
                柱の想起・開閉確認・◎○❌自己判定を行う本格理論の題数
              </p>
              <div className="flex items-center gap-1.5 pt-1">
                {[1, 2, 3, 5].map((num) => (
                  <button
                    key={num}
                    onClick={() => handleUpdateToggleQuota(num)}
                    className={`flex-1 py-1 rounded text-[11px] font-bold border transition ${
                      toggleQuota === num
                        ? 'bg-indigo-600 text-white border-indigo-500 font-black'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {num}題{num === 3 ? '⭐' : ''}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mode Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('drill')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'drill'
              ? 'bg-amber-500 text-slate-950 shadow-md font-black shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 bg-slate-950/60 border border-slate-800'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>⚡ 高速サクサクドリル（{fastDrillDeck.length}問 / 目安10分）</span>
          {drillDoneToday && <Check className="w-3 h-3 text-emerald-950" />}
        </button>

        <button
          onClick={() => setActiveTab('notion')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'notion'
              ? 'bg-indigo-600 text-white shadow-md font-black shadow-indigo-600/20'
              : 'text-slate-400 hover:text-slate-200 bg-slate-950/60 border border-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>📑 Notionトグル暗記（{notionDailyTheories.length}題 / 目安15分）</span>
          {toggleDoneToday && <Check className="w-3 h-3 text-emerald-400" />}
        </button>
      </div>

      {/* ================================================================= */}
      {/* TAB 1: FAST DRILL (3秒クイズ・虫食い・キャラ会話・フロー図 20問) */}
      {/* ================================================================= */}
      {activeTab === 'drill' && (
        <div className="space-y-3">
          {/* Subheader banner with remaining count & completed toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-300 font-bold">
                残り <strong className="text-amber-400 font-mono text-sm">{activeDrillDeck.length}</strong> / {fastDrillDeck.length}問
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400">解いた問題は自動で消えていきます</span>
              {completedDrillDeck.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowCompletedDrill(!showCompletedDrill)}
                  className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-slate-950 border border-slate-700 text-slate-300 hover:text-white hover:border-slate-500 transition cursor-pointer flex items-center gap-1"
                >
                  <span>{showCompletedDrill ? '完了分を隠す' : `完了分を表示（${completedDrillDeck.length}問）`}</span>
                  <ChevronDown className={`w-3 h-3 transition-transform ${showCompletedDrill ? 'rotate-180' : ''}`} />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {activeDrillDeck.length > 0 && (
                <button
                  onClick={() => handleStartDrillRemaining(activeDrillDeck, 0, false)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 transition shadow shadow-amber-400/20 shrink-0 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>残り{activeDrillDeck.length}問スタート ▶</span>
                </button>
              )}
            </div>
          </div>

          {/* All active items completed */}
          {activeDrillDeck.length === 0 ? (
            <div className="py-5 px-4 bg-emerald-950/30 rounded-xl border border-emerald-800/40 text-center space-y-2">
              <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>🎉 本日の高速ドリル全{fastDrillDeck.length}問をすべてこなしました！</span>
              </div>
              <p className="text-xs text-slate-400">
                お見事です！すべての問題が消去されました。「完了分を表示」から復習することも可能です。
              </p>
              <div className="pt-1 flex items-center justify-center gap-2 flex-wrap">
                <button
                  onClick={() => {
                    setCompletedDrillIds({});
                    setDrillDoneToday(false);
                    try {
                      localStorage.removeItem(completedDrillItemsKey);
                      localStorage.removeItem(drillDoneKey);
                    } catch {}
                    handleStartDrillRemaining(fastDrillDeck, 0, false);
                  }}
                  className="text-xs font-bold text-amber-400 hover:text-amber-300 px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-800/40 inline-flex items-center gap-1 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>リセットしてもう一度解く</span>
                </button>
                <button
                  onClick={() => setActiveTab('notion')}
                  className="text-xs font-bold text-indigo-300 hover:text-white px-3 py-1.5 rounded-lg bg-indigo-950/60 border border-indigo-700/60 inline-flex items-center gap-1 transition cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Notionトグル{notionDailyTheories.length}題へ進む ▶</span>
                </button>
              </div>
            </div>
          ) : (
            /* Grid of active uncompleted questions */
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              {activeDrillDeck.map((item, idx) => {
                return (
                  <div
                    key={item.id}
                    onClick={() => handleStartDrillRemaining(activeDrillDeck, idx, false)}
                    className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/60 hover:bg-slate-950 transition-all cursor-pointer group flex flex-col justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1.5">
                        <span className="text-[10px] font-mono font-bold text-slate-400 flex items-center gap-1">
                          <span>Q{idx + 1}. 理論{item.theoryNumber}</span>
                          {item.isWeakFocus && (
                            <span className="text-[9px] text-rose-300 bg-rose-950/80 px-1 rounded border border-rose-800/60" title="苦手柱・復習期日連動">
                              重点
                            </span>
                          )}
                        </span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${item.badgeColor}`}>
                          {item.typeLabel}
                        </span>
                      </div>

                      <div className="font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                        {item.question}
                      </div>

                      {item.contextSnippet && (
                        <div className="mt-1 text-[10px] text-slate-400 font-mono line-clamp-2 bg-slate-900/60 p-1 rounded border border-slate-850">
                          {item.contextSnippet}
                        </div>
                      )}
                    </div>

                    <div className="mt-2.5 pt-1.5 border-t border-slate-850 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 text-[10px]">4択シャッフル即答</span>
                      <span className="text-amber-400 font-bold group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                        <span>解く</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Completed Items Archive Section ("また見れる機能") */}
          {showCompletedDrill && completedDrillDeck.length > 0 && (
            <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>本日こなした問題一覧（{completedDrillDeck.length}問）</span>
                </span>
                <span className="text-[11px] text-slate-400">クリックで再確認・未完了へ戻せます</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 opacity-85">
                {completedDrillDeck.map((item, cIdx) => {
                  return (
                    <div
                      key={`done-${item.id}`}
                      className="p-3 rounded-xl bg-slate-950/40 border border-emerald-900/40 text-xs flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                            <Check className="w-3 h-3" />
                            <span>済 · 理論{item.theoryNumber}</span>
                          </span>
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                            {item.typeLabel}
                          </span>
                        </div>
                        <div className="font-medium text-slate-300 line-clamp-2 leading-snug">
                          {item.question}
                        </div>
                      </div>

                      <div className="mt-2.5 pt-1.5 border-t border-slate-850 flex items-center justify-between text-[10px]">
                        <button
                          type="button"
                          onClick={() => handleUnmarkDrillItemCompleted(item.id)}
                          className="text-slate-400 hover:text-amber-400 underline cursor-pointer"
                        >
                          未完了に戻す
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStartDrillRemaining(completedDrillDeck, cIdx, true)}
                          className="text-indigo-300 hover:text-white font-bold cursor-pointer"
                        >
                          復習する ▶
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================= */}
      {/* TAB 2: NOTION TOGGLE 3 THEORIES (本丸：Notionトグル暗記 3題)       */}
      {/* ================================================================= */}
      {activeTab === 'notion' && (
        <div className="space-y-4">
          {/* Subheader banner with phase rule, Anki due alert, remaining count & graduated deck */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs flex-wrap p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-slate-300 font-bold">
                残り <strong className="text-indigo-400 font-mono text-sm">{activeNotionTheories.length}</strong> / {notionDailyTheories.length}題
              </span>
              <span className="text-slate-600">|</span>

              {/* 📅 本試験カレンダー連動フェーズバッジ */}
              <div className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 ${dynamicPhaseInfo.phaseBadge}`} title="税理士本試験までの学習月・習得状況に連動した出題比率">
                <span>📅 {dynamicPhaseInfo.phaseName}（{dynamicPhaseInfo.phaseRule}）</span>
              </div>

              {/* 👑 Anki忘却曲線期日到来バッジ */}
              {dueTheoriesCount > 0 && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/50 flex items-center gap-1 animate-pulse" title="全柱◎の定着復習期日（3/7/14/30日後）が到来した論点">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Anki期日到来 {dueTheoriesCount}題優先</span>
                </span>
              )}

              {/* 🟢 即時永続化インジケーター */}
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 transition-all ${
                  justSaved
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-500 shadow-sm shadow-emerald-500/20 animate-pulse'
                    : 'bg-slate-900/90 text-slate-400 border-slate-800'
                }`}
                title="柱（◎○❌）をタップするごとに0秒でローカル永続化とクラウド保存が実行されます"
              >
                <Check className={`w-3 h-3 ${justSaved ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span>{justSaved ? 'タップ即時保存完了 ✔' : '即時保存稼働中'}</span>
              </span>

              {/* 🎓 卒業・Anki定着復習デッキ一覧トグル */}
              <button
                type="button"
                onClick={() => setShowGraduatedList(!showGraduatedList)}
                className="text-[11px] font-bold text-yellow-300 hover:text-yellow-200 bg-yellow-950/50 border border-yellow-700/50 px-2 py-0.5 rounded-md flex items-center gap-1 transition cursor-pointer"
                title="全柱が◎（マスター）になりAnki分散学習に入った卒業論点一覧を表示"
              >
                <GraduationCap className="w-3.5 h-3.5 text-yellow-400" />
                <span>卒業デッキ: {graduatedTheories.length} / {subjectTheories.length}題</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${showGraduatedList ? 'rotate-180' : ''}`} />
              </button>

              {completedNotionTheories.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowCompletedNotion(!showCompletedNotion)}
                  className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-slate-900 border border-slate-700 text-slate-300 hover:text-white hover:border-slate-500 transition cursor-pointer flex items-center gap-1"
                >
                  <span>{showCompletedNotion ? '完了分を隠す' : `本日クリア（${completedNotionTheories.length}題）`}</span>
                  <ChevronDown className={`w-3 h-3 transition-transform ${showCompletedNotion ? 'rotate-180' : ''}`} />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* 🔄 別の3問にチェンジ ボタン */}
              <button
                type="button"
                onClick={() => setNotionShuffleOffset((p) => p + 1)}
                className="text-[11px] font-bold text-amber-300 hover:text-white bg-slate-900 hover:bg-slate-850 border border-amber-500/50 hover:border-amber-400 px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-sm"
                title="別の出題候補にローテーションします"
              >
                <RotateCcw className="w-3 h-3 text-amber-400" />
                <span>別の3問にチェンジ 🔄</span>
              </button>

              <div className="text-[11px] font-mono font-bold text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/60 hidden sm:block">
                厳選 {notionDailyTheories.length}題
              </div>
            </div>
          </div>

          {/* 🎓 卒業生（全柱◎達成）× Anki忘却曲線復習デッキ ドロワー */}
          {showGraduatedList && (
            <div className="p-3.5 rounded-xl bg-gradient-to-br from-yellow-950/30 via-slate-950 to-slate-950 border border-yellow-600/40 space-y-2.5 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                <span className="font-bold text-yellow-300 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-yellow-400" />
                  <span>全柱マスター達成・Anki忘却曲線 定着デッキ（{graduatedTheories.length}題）</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  全柱◎達成後、Anki式（3日 ➔ 7日 ➔ 14日 ➔ 30日）の間隔で期日が来ると自動再出題されます
                </span>
              </div>
              {graduatedTheories.length === 0 ? (
                <p className="text-xs text-slate-400 py-1">
                  まだ卒業した論点はありません。論点内のすべての柱を「◎ 完璧！」にすると卒業し、Anki分散学習デッキに登録されて次の論点へ進みます！
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {graduatedTheories.map((gt) => {
                    const srs = srsMap[gt.id];
                    const isDue = !srs || !srs.nextDueDate || srs.nextDueDate <= todayStr;
                    let daysLeft = 0;
                    if (srs?.nextDueDate) {
                      const diff = Math.ceil((new Date(srs.nextDueDate).getTime() - new Date(todayStr).getTime()) / (1000 * 60 * 60 * 24));
                      daysLeft = diff;
                    }

                    return (
                      <div
                        key={`grad-${gt.id}`}
                        onClick={() => onSelectTheory(gt.id)}
                        className={`p-2.5 rounded-lg border flex items-center justify-between text-xs cursor-pointer group transition ${
                          isDue
                            ? 'bg-amber-950/40 border-amber-500/80 hover:border-amber-400'
                            : 'bg-slate-900/80 border-yellow-700/40 hover:border-yellow-500'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${isDue ? 'text-amber-400' : 'text-yellow-400'}`} />
                          <span className="font-mono font-bold text-yellow-300">問{gt.theoryNumber}</span>
                          <span className="truncate text-slate-200 group-hover:text-white font-medium">{gt.title}</span>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0 ml-2">
                          <span className="text-[10px] font-mono font-bold text-indigo-300 bg-indigo-950/80 px-1.5 py-0.5 rounded border border-indigo-800">
                            Lv.{srs?.level || 1}（{srs?.intervalDays || 3}日毎）
                          </span>
                          {isDue ? (
                            <span className="text-[10px] font-bold text-amber-300 bg-amber-950/90 px-1.5 py-0.5 rounded border border-amber-500 animate-pulse">
                              ⚠️ 本日期日！
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-850">
                              次回: {srs?.nextDueDate ? srs.nextDueDate.slice(5) : '予定'}（あと{daysLeft}日）
                            </span>
                          )}
                          {srs && srs.lapseCount > 0 && (
                            <span className="text-[9px] font-mono text-rose-400 bg-rose-950/60 px-1 rounded border border-rose-800/60" title={`忘却回数: ${srs.lapseCount}回`}>
                              忘{srs.lapseCount}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* All active Notion theories completed */}
          {activeNotionTheories.length === 0 ? (
            <div className="py-6 px-4 bg-indigo-950/30 rounded-2xl border border-indigo-800/40 text-center space-y-2.5">
              <div className="flex items-center justify-center gap-2 text-indigo-300 font-black text-sm sm:text-base">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>🎉 本日のNotionトグル全{notionDailyTheories.length}題の暗記チェック完了！</span>
              </div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                素晴らしい集中力です！本日の重要理論の骨格が定着しました。下の「完了分を表示」からいつでも復習できます。
              </p>
              <div className="pt-1 flex items-center justify-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setCompletedTheoryIds({});
                    setToggleDoneToday(false);
                    try {
                      localStorage.removeItem(completedTheoriesKey);
                      localStorage.removeItem(toggleDoneKey);
                    } catch {}
                    setTimeout(() => {
                      StorageService.pushToServer().catch(() => {});
                    }, 600);
                  }}
                  className="text-xs font-bold text-amber-400 hover:text-amber-300 px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-800/40 inline-flex items-center gap-1 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>リセットしてもう一度3題チェックする</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {activeNotionTheories.map((theory, tIdx) => {
                const parents = getParentSectionsForTheory(theory);
                const isTheoryOpen = openNotionSections[`th-${theory.id}`] ?? (tIdx === 0);
                const selection = notionDailyMap.get(theory.id);
                const stats = getTheoryMasteryStats(theory);

                return (
                  <div
                    key={theory.id}
                    className="rounded-2xl bg-slate-950/80 border border-slate-800 overflow-hidden shadow-md"
                  >
                    {/* 大トグル: 理論タイトル & 理由バッジ */}
                    <div
                      onClick={() => toggleNotionItem(`th-${theory.id}`)}
                      className="p-3.5 sm:p-4 bg-slate-900/90 hover:bg-slate-900 border-b border-slate-800/80 flex items-center justify-between gap-3 cursor-pointer select-none transition flex-wrap"
                    >
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="text-slate-400 group-hover:text-white transition-transform">
                          {isTheoryOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                        </div>
                        <span className="text-xs font-mono font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded-md">
                          問{theory.theoryNumber}
                        </span>

                        {/* 出題理由バッジ (苦手復習 / 育成中 / 新規前進) */}
                        {selection && (
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 ${selection.badgeStyle}`}
                            title={selection.reasonDesc}
                          >
                            {selection.reasonBadge}
                          </span>
                        )}

                        {theory.subCategory && (
                          <span className="text-[10px] font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-700/60 px-1.5 py-0.5 rounded">
                            {theory.subCategory}
                          </span>
                        )}

                        <span className="font-bold text-white text-xs sm:text-sm">
                          {theory.title}
                        </span>

                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          theory.priorityRank === 'S'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800/80'
                            : 'bg-amber-950 text-amber-300 border border-amber-800/80'
                        }`}>
                          {theory.priorityRank}ランク
                        </span>

                        {/* 柱進捗ミニバッジ */}
                        <span className="text-[10px] font-mono font-bold text-slate-300 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                          ◎ {stats.masteredPillars} / {stats.totalPillars}柱
                        </span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {/* 1題クリアボタン（この理論を消して達成にする） */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMarkTheoryCompleted(theory.id, theory.title);
                          }}
                          className="text-[11px] font-black text-emerald-300 hover:text-white px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-600/70 inline-flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-sm shadow-emerald-500/20"
                          title="この理論の暗記想起チェックを完了にしてメニューから消す"
                        >
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>暗記完了！クリア ✔</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectTheory(theory.id);
                          }}
                          className="text-[11px] font-bold text-amber-400 hover:text-amber-300 px-2.5 py-1.5 rounded-lg bg-amber-950/40 border border-amber-800/40 inline-flex items-center gap-1 transition shrink-0"
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>本格特訓 ▶</span>
                        </button>
                      </div>
                    </div>

                    {/* 🎊 卒業条件達成バナー（全柱マスター時） */}
                    {stats.isGraduated && (
                      <div className="mx-3 sm:mx-4 mt-3 mb-1 p-2.5 rounded-xl bg-gradient-to-r from-yellow-500/20 via-amber-500/25 to-yellow-500/20 border border-yellow-400/60 text-yellow-200 text-xs font-bold flex items-center justify-between gap-2 shadow-md shadow-yellow-500/10 flex-wrap">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-yellow-400 shrink-0 animate-bounce" />
                          <span>🎉 全{stats.totalPillars}柱マスター達成！卒業条件を満たしました</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] bg-yellow-500/20 border border-yellow-400/50 px-2 py-0.5 rounded font-mono text-yellow-200 font-black">
                            暗記100% 卒業 🎓
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkTheoryCompleted(theory.id, theory.title);
                            }}
                            className="text-[11px] bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-2.5 py-1 rounded-md transition shadow flex items-center gap-1 cursor-pointer active:scale-95"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>クリアして次へ進む ▶</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* 中トグル & 小トグル一覧 */}
                    {isTheoryOpen && (
                      <div className="p-3 sm:p-4 space-y-3 bg-[#0A0F1D]/80">
                        {parents.map((p, pIdx) => {
                          const isParentOpen = openNotionSections[`p-${theory.id}-${p.num}`] ?? true;

                          return (
                            <div
                              key={p.id || pIdx}
                              className="rounded-xl border border-slate-800/80 bg-slate-900/50 overflow-hidden"
                            >
                              {/* 中トグル (Parent Section Heading) */}
                              <div
                                onClick={() => toggleNotionItem(`p-${theory.id}-${p.num}`)}
                                className="px-3 py-2 bg-slate-900/80 flex items-center justify-between text-xs font-bold text-slate-200 cursor-pointer select-none border-b border-slate-800/60"
                              >
                                <div className="flex items-center gap-2">
                                  {isParentOpen ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />}
                                  <span className="text-amber-400 font-mono">{p.num}</span>
                                  <span>{p.heading}</span>
                                </div>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {p.subSections.length}本の柱
                                </span>
                              </div>

                              {/* 小トグル (Sub Sections / 各「柱」) */}
                              {isParentOpen && (
                                <div className="p-2 space-y-2">
                                  {p.subSections.map((sec, sIdx) => {
                                    const secKey = `sec-${theory.id}-${p.num}-${sec.heading}`;
                                    const isSecOpen = openNotionSections[secKey] ?? false;
                                    const pState = getPillarState(theory, sec.heading, sec.status);

                                    return (
                                      <div
                                        key={sIdx}
                                        className={`rounded-lg border transition-all ${
                                          pState.status === 'mastered'
                                            ? 'bg-emerald-950/20 border-emerald-800/40'
                                            : pState.status === 'learning'
                                            ? 'bg-amber-950/20 border-amber-800/40'
                                            : 'bg-slate-950 border-slate-800'
                                        }`}
                                      >
                                        {/* Pillar toggle bar with inline 1-tap ❌/○/◎ buttons */}
                                        <div
                                          onClick={() => toggleNotionItem(secKey)}
                                          className="p-2.5 flex items-center justify-between gap-2 cursor-pointer select-none text-xs"
                                        >
                                          <div className="flex items-center gap-2 flex-wrap min-w-0 flex-1">
                                            {isSecOpen ? <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" /> : <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />}
                                            <span className="font-mono text-slate-400 font-bold shrink-0">{sec.num}</span>
                                            <span className="font-bold text-slate-100 break-words">{formatCleanPillarHeading(sec.heading)}</span>
                                            {sec.imageUrl && (
                                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700/60">
                                                🖼️ 図解画像あり
                                              </span>
                                            )}
                                          </div>

                                          {/* Inline 1-Tap Quick Status Switcher (works even without opening toggle!) */}
                                          <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                                            <div className="flex items-center bg-slate-950/90 p-0.5 rounded-lg border border-slate-800 gap-0.5">
                                              <button
                                                type="button"
                                                onClick={() => handleEvaluateNotionPillar(theory, sec, 'weak')}
                                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                  pState.status === 'weak'
                                                    ? 'bg-rose-950 text-rose-300 border border-rose-700 font-black shadow-sm'
                                                    : 'text-slate-500 hover:text-rose-300'
                                                }`}
                                                title="❌ 要復習にする"
                                              >
                                                ❌
                                              </button>
                                              <button
                                                type="button"
                                                onClick={() => handleEvaluateNotionPillar(theory, sec, 'learning')}
                                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                  pState.status === 'learning'
                                                    ? 'bg-amber-950 text-amber-300 border border-amber-600 font-black shadow-sm'
                                                    : 'text-slate-500 hover:text-amber-300'
                                                }`}
                                                title="○ 骨格覚えたにする"
                                              >
                                                ○
                                              </button>
                                              <button
                                                type="button"
                                                onClick={() => handleEvaluateNotionPillar(theory, sec, 'mastered')}
                                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition cursor-pointer ${
                                                  pState.status === 'mastered'
                                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-500 font-black shadow-sm'
                                                    : 'text-slate-500 hover:text-emerald-300'
                                                }`}
                                                title="◎ 完璧マスターにする"
                                              >
                                                ◎
                                              </button>
                                            </div>
                                          </div>
                                        </div>

                                        {/* Pillar Content when opened */}
                                        {isSecOpen && (
                                          <div className="p-3 border-t border-slate-800/80 space-y-2.5 text-xs bg-slate-950/90 animate-in fade-in duration-100">
                                            {/* 💡 ようは */}
                                            {sec.essence && (
                                              <div className="p-2 rounded-lg bg-cyan-950/30 border border-cyan-800/40 text-cyan-200 text-xs font-medium flex items-start gap-1.5">
                                                <span className="font-bold text-cyan-400 shrink-0">💡 ようは:</span>
                                                <span>{sec.essence}</span>
                                              </div>
                                            )}

                                            {/* 🎵 呪文・語呂合わせ */}
                                            {sec.mnemonic && (
                                              <div className="p-2 rounded-lg bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs font-bold flex items-center gap-1.5 shadow-sm">
                                                <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400 shrink-0" />
                                                <span>語呂: {sec.mnemonic}</span>
                                              </div>
                                            )}

                                            {/* 🔍 【一字一句暗記対策】深掘り解説トグル */}
                                            {sec.deepDiveNote && (
                                              <details className="group rounded-xl border border-amber-500/40 bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 p-2.5 shadow-md transition-all text-xs">
                                                <summary className="flex items-center justify-between cursor-pointer font-bold text-amber-300 hover:text-amber-200 select-none list-none">
                                                  <div className="flex items-center gap-1.5">
                                                    <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-black">
                                                      🔥 暗記深掘り解説
                                                    </span>
                                                    <span className="text-[11px] text-amber-200 font-bold">理屈・背景＆一字一句攻略ドリル</span>
                                                  </div>
                                                  <span className="text-[10px] text-amber-400/80 group-open:rotate-180 transition-transform duration-200">
                                                    ▼
                                                  </span>
                                                </summary>
                                                <div className="mt-2.5 pt-2 border-t border-amber-500/20 text-slate-200 leading-relaxed font-sans whitespace-pre-wrap text-[11px] bg-slate-950/80 p-2.5 rounded-lg border border-slate-800/80">
                                                  {sec.deepDiveNote}
                                                </div>
                                              </details>
                                            )}

                                            {/* 🖼️ 柱ごとのビジュアルイメージ図（生成画像） */}
                                            {sec.imageUrl && (
                                              <div className="rounded-lg bg-slate-900 border border-indigo-500/40 p-2 space-y-1.5">
                                                <div className="text-[10px] font-bold text-indigo-300">🖼️ イメージ図解（{p.num}{sec.num} {formatCleanPillarHeading(sec.heading)}）</div>
                                                <img
                                                  src={sec.imageUrl}
                                                  alt={`${p.num}${sec.num} ${formatCleanPillarHeading(sec.heading)} イメージ図`}
                                                  referrerPolicy="no-referrer"
                                                  className="w-full rounded-lg border border-slate-800 object-contain bg-slate-950"
                                                />
                                              </div>
                                            )}

                                            {/* 🗺️ 判定フロー図解 */}
                                            {sec.diagram && (
                                              <div className="rounded-lg bg-slate-900 border border-indigo-900/40 p-2 space-y-1">
                                                <div className="text-[10px] font-bold text-indigo-300">🗺️ 構造・判定フロー</div>
                                                <pre className="font-mono text-[10px] sm:text-[11px] text-indigo-200 leading-relaxed overflow-x-auto p-1.5 bg-slate-950 rounded border border-slate-800 whitespace-pre">
                                                  {sec.diagram}
                                                </pre>
                                              </div>
                                            )}

                                            {/* 本文（条文） */}
                                            <div className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800 text-slate-300 leading-relaxed font-sans text-xs">
                                              {sec.body}
                                            </div>

                                            {/* 1-Tap Status Switcher */}
                                            <div className="pt-2 border-t border-slate-850 flex items-center justify-between gap-2 flex-wrap">
                                              <span className="text-[10px] text-slate-400">自己評価して更新:</span>
                                              <div className="flex items-center gap-1.5">
                                                <button
                                                  type="button"
                                                  onClick={() => handleEvaluateNotionPillar(theory, sec, 'weak')}
                                                  className={`px-2 py-1 rounded text-[11px] font-bold border transition cursor-pointer ${
                                                    pState.status === 'weak'
                                                      ? 'bg-rose-950 text-rose-300 border-rose-600 font-black'
                                                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                                                  }`}
                                                >
                                                  ❌ まだ不安
                                                </button>
                                                <button
                                                  type="button"
                                                  onClick={() => handleEvaluateNotionPillar(theory, sec, 'learning')}
                                                  className={`px-2 py-1 rounded text-[11px] font-bold border transition cursor-pointer ${
                                                    pState.status === 'learning'
                                                      ? 'bg-amber-950 text-amber-300 border-amber-600 font-black'
                                                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                                                  }`}
                                                >
                                                  ○ 骨格覚えた
                                                </button>
                                                <button
                                                  type="button"
                                                  onClick={() => handleEvaluateNotionPillar(theory, sec, 'mastered')}
                                                  className={`px-2 py-1 rounded text-[11px] font-bold border transition cursor-pointer ${
                                                    pState.status === 'mastered'
                                                      ? 'bg-emerald-950 text-emerald-300 border-emerald-600 font-black'
                                                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                                                  }`}
                                                >
                                                  ◎ 完璧！
                                                </button>
                                              </div>
                                            </div>
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })}

                        {/* Bottom completion action bar for this theory */}
                        <div className="pt-3.5 mt-2 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
                          <div className="text-[11px] text-slate-300 flex items-center gap-2">
                            <span>本問の進捗:</span>
                            <span className="font-mono font-bold text-emerald-400">{stats.masteredPillars} / {stats.totalPillars}柱 完璧◎</span>
                            {stats.isGraduated ? (
                              <span className="text-[10px] font-bold text-yellow-300 bg-yellow-950/80 px-2 py-0.5 rounded border border-yellow-700/60">
                                🎓 全柱マスター達成済
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-400">
                                （あと{stats.remainingToGraduate}柱で卒業＆Ankiサイクルへ）
                              </span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => handleMarkTheoryCompleted(theory.id, theory.title)}
                            className="text-xs font-black text-white px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:from-emerald-500 hover:to-teal-500 border border-emerald-400/50 flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                            <span>この論点をクリアして次へ進む（残り {Math.max(0, activeNotionTheories.length - 1)}題）▶</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Completed Notion Theories Archive Section ("また見れる機能") */}
          {showCompletedNotion && completedNotionTheories.length > 0 && (
            <div className="pt-3 border-t border-slate-800/80 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>本日クリアした理論一覧（{completedNotionTheories.length}題）</span>
                </span>
                <span className="text-[11px] text-slate-400">クリックでいつでも再確認・復習可能</span>
              </div>

              <div className="space-y-2 opacity-90">
                {completedNotionTheories.map((theory) => (
                  <div
                    key={`done-notion-${theory.id}`}
                    className="p-3 rounded-xl bg-slate-950/60 border border-emerald-900/50 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                        <Check className="w-3.5 h-3.5" />
                        <span>クリア</span>
                      </span>
                      <span className="font-mono font-bold text-slate-400">問{theory.theoryNumber}</span>
                      <span className="font-bold text-slate-200">{theory.title}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 border border-slate-800">
                        {theory.priorityRank}ランク
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleUnmarkTheoryCompleted(theory.id)}
                        className="text-[11px] text-slate-400 hover:text-amber-400 underline cursor-pointer"
                      >
                        未完了に戻す
                      </button>
                      <button
                        type="button"
                        onClick={() => onSelectTheory(theory.id)}
                        className="text-[11px] font-bold text-indigo-300 hover:text-white px-2.5 py-1 rounded-lg bg-indigo-950/60 border border-indigo-700/60 cursor-pointer"
                      >
                        中身を見る ▶
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================= */}
      {/* MODAL: FAST DRILL PLAYER (20問をサクサクスムーズに解く)           */}
      {/* ================================================================= */}
      {isDrillOpen && currentDrillItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-[#0D131F] border border-slate-700 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono font-black text-xs text-slate-950 bg-amber-400 px-2 py-0.5 rounded-md">
                  問{currentDrillItem.theoryNumber}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${currentDrillItem.badgeColor}`}>
                  {currentDrillItem.typeLabel}
                </span>
                {isDrillReviewMode && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700/60">
                    復習モード
                  </span>
                )}
                <span className="text-xs font-mono font-bold text-slate-300">
                  {currentDrillIndex + 1} / {activeModalQueue.length}問
                </span>
              </div>
              <button
                onClick={() => setIsDrillOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Progress bar */}
            <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-300 rounded-full"
                style={{ width: `${((currentDrillIndex + 1) / Math.max(1, activeModalQueue.length)) * 100}%` }}
              />
            </div>

            {/* Title & Question */}
            <div className="space-y-1">
              <div className="text-[11px] text-slate-400 font-medium">
                {currentDrillItem.theoryTitle}
                {currentDrillItem.pillarHeading && ` › ${formatCleanPillarHeading(currentDrillItem.pillarHeading)}`}
              </div>
              <h3 className="text-sm sm:text-base font-black text-white leading-snug">
                {currentDrillItem.question}
              </h3>
            </div>

            {/* Context Snippet (if available) */}
            {currentDrillItem.contextSnippet && (
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-200 leading-relaxed">
                {currentDrillItem.contextSnippet}
              </div>
            )}

            {/* Options list */}
            <div className="space-y-2 pt-1">
              {currentDrillItem.options.map((opt, oIdx) => {
                const isSelected = selectedDrillOption === oIdx;
                const isCorrect = oIdx === currentDrillItem.correctIndex;

                let optStyle = 'bg-slate-900 text-slate-200 border-slate-800 hover:border-amber-500/60 hover:bg-slate-850';
                if (isDrillRevealed) {
                  if (isCorrect) {
                    optStyle = 'bg-emerald-950 text-emerald-300 border-emerald-500 font-bold';
                  } else if (isSelected) {
                    optStyle = 'bg-rose-950 text-rose-300 border-rose-500';
                  } else {
                    optStyle = 'bg-slate-950 text-slate-500 border-slate-850 opacity-60';
                  }
                }

                return (
                  <button
                    key={oIdx}
                    type="button"
                    onClick={() => handleSelectDrillOption(oIdx)}
                    className={`w-full p-3 rounded-xl text-xs text-left border transition active:scale-98 flex items-start gap-2.5 cursor-pointer ${optStyle}`}
                  >
                    <span className="font-mono font-bold text-slate-400 shrink-0">
                      [{String.fromCharCode(65 + oIdx)}]
                    </span>
                    <span className="leading-snug">{opt}</span>
                  </button>
                );
              })}
            </div>

            {/* Explanation card + Direct Pillar Status Sync when revealed */}
            {isDrillRevealed && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/50 text-xs text-amber-200 space-y-2.5 animate-in fade-in duration-150">
                <div className="space-y-1">
                  <div className="font-bold text-amber-400 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>解説・ポイント</span>
                  </div>
                  <div className="leading-relaxed">{currentDrillItem.explanation}</div>
                </div>

                {currentDrillItem.pillarHeading && (() => {
                  const matchedTheory = theories.find((t) => t.id === currentDrillItem.theoryId);
                  if (!matchedTheory) return null;
                  const pKey = currentDrillItem.pillarHeading;
                  const curPillar = getPillarState(matchedTheory, pKey);
                  return (
                    <div className="pt-2 border-t border-amber-800/40 flex items-center justify-between gap-2 flex-wrap">
                      <span className="text-[10px] text-amber-200/80">
                        柱「{formatCleanPillarHeading(pKey)}」の評価を連動変更:
                      </span>
                      <div className="flex items-center gap-1">
                        {(['weak', 'learning', 'mastered'] as const).map((st) => {
                          const active = curPillar.status === st;
                          const label = st === 'mastered' ? '◎ 完璧' : st === 'learning' ? '○ 骨格' : '❌ 不安';
                          const activeCls =
                            st === 'mastered'
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500 font-black'
                              : st === 'learning'
                              ? 'bg-amber-950 text-amber-300 border-amber-500 font-black'
                              : 'bg-rose-950 text-rose-300 border-rose-500 font-black';
                          return (
                            <button
                              key={st}
                              type="button"
                              onClick={() =>
                                updatePillarState(
                                  matchedTheory,
                                  pKey,
                                  st,
                                  st === 'mastered' ? 2 : st === 'learning' ? 1 : 0
                                )
                              }
                              className={`px-2 py-0.5 rounded text-[10px] border transition cursor-pointer ${
                                active ? activeCls : 'bg-slate-950/80 text-slate-400 border-slate-800 hover:text-white'
                              }`}
                            >
                              {label}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* Footer with Next button */}
            {isDrillRevealed && (
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-mono">
                  正解数: {drillCorrectCount} / {currentDrillIndex + 1}
                </span>
                <button
                  type="button"
                  onClick={handleNextDrillItem}
                  className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs transition flex items-center gap-1 shadow-md shadow-amber-400/20 cursor-pointer"
                >
                  <span>{currentDrillIndex < activeModalQueue.length - 1 ? '次の問題へ ▶' : '結果を見る・完了 🎉'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
