import React, { useState } from 'react';
import { 
  Trophy, Flame, Clock, Calendar, CheckCircle2, 
  Download, Upload, ChevronRight, Award, Plus, Sparkles, AlertCircle
} from 'lucide-react';
import { SubjectInfo, StudySession, SubjectId, TheoryItem, MonthlyMilestone } from '../../types';
import { StorageService } from '../../services/storage';
import { getJSTDateString, normalizePillarKey } from '../../utils/date';

interface RoadmapViewProps {
  subjects: SubjectInfo[];
  sessions: StudySession[];
  theories?: TheoryItem[];
  milestones?: MonthlyMilestone[];
  onUpdateMilestones?: (updated: MonthlyMilestone[]) => void;
  onOpenQuickLog: () => void;
  onRestoreData: () => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({
  subjects,
  sessions,
  theories = [],
  milestones: propMilestones,
  onUpdateMilestones,
  onOpenQuickLog,
  onRestoreData,
}) => {
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Local milestones state with fallback to StorageService
  const [milestones, setMilestones] = useState<MonthlyMilestone[]>(() => {
    return propMilestones && propMilestones.length > 0
      ? propMilestones
      : StorageService.getMilestones();
  });

  // Custom Milestone Editor Modal State
  const [isEditingMilestones, setIsEditingMilestones] = useState<boolean>(false);
  const [editingMilestone, setEditingMilestone] = useState<MonthlyMilestone | null>(null);

  // Sync prop changes
  React.useEffect(() => {
    if (propMilestones && propMilestones.length > 0) {
      setMilestones(propMilestones);
    }
  }, [propMilestones]);

  // Aggregate user's genuine theory mastered and learning pillars count
  const residentTheories = theories.filter((t) => t.subjectId === 'resident');
  let totalMasteredPillars = 0;
  let totalLearningPillars = 0;
  let totalPillarsCount = 0;
  const vault = StorageService.getPillarVault();

  residentTheories.forEach((theory) => {
    const subs = theory.parentSections
      ? theory.parentSections.flatMap((p) => p.subSections)
      : theory.structuredSubSections || [];
    
    subs.forEach((s) => {
      totalPillarsCount++;
      const normH = normalizePillarKey(s.heading);
      const vEntry = vault[`${theory.id}::${s.heading}`] || vault[`${theory.id}::${normH}`];
      const pStat = theory.pillarStatuses?.[s.heading] || theory.pillarStatuses?.[normH];
      
      let status: 'mastered' | 'learning' | 'weak' = 'weak';
      if (vEntry && vEntry.isUserAction) {
        if (pStat && pStat.isUserAction === true && (pStat.updatedAt || 0) >= (vEntry.updatedAt || 0)) {
          status = pStat.status;
        } else {
          status = vEntry.status;
        }
      } else if (pStat && pStat.isUserAction === true) {
        status = pStat.status;
      } else {
        status = pStat?.status || s.status || 'weak';
      }

      if (status === 'mastered') totalMasteredPillars++;
      else if (status === 'learning') totalLearningPillars++;
    });
  });

  // Current Month calculation
  const now = new Date();
  const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const currentMilestone = milestones.find((m) => m.monthKey === currentMonthKey) || milestones[0];

  const handleSaveMilestoneEdit = (updated: MonthlyMilestone) => {
    const nextList = milestones.map((m) => (m.monthKey === updated.monthKey ? updated : m));
    setMilestones(nextList);
    StorageService.saveMilestones(nextList);
    if (onUpdateMilestones) onUpdateMilestones(nextList);
    setIsEditingMilestones(false);
    setEditingMilestone(null);
  };

  const totalMinutes = sessions.reduce((sum, s) => sum + (s.minutes > 0 ? s.minutes : 0), 0);
  const sessionTotalHours = Math.round((totalMinutes / 60) * 10) / 10;
  const subjectsTotalHours = Math.round(subjects.reduce((sum, s) => sum + (s.currentHours || 0), 0) * 10) / 10;
  const totalHours = Math.max(sessionTotalHours, subjectsTotalHours);
  const targetTotal = 900;
  const progressRatio = Math.min(100, Math.round((totalHours / targetTotal) * 100));

  // Exam Date calculation
  const examDate = new Date('2027-08-04T09:00:00');
  const diffDays = Math.max(0, Math.ceil((examDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  // Filtered study sessions
  const filteredSessions = selectedSubjectFilter === 'all'
    ? sessions
    : sessions.filter((s) => s.subjectId === selectedSubjectFilter);

  // Subject hours breakdown
  const subjectHours = (subId: SubjectId) => {
    const mins = sessions
      .filter((s) => s.subjectId === subId && s.minutes > 0)
      .reduce((sum, s) => sum + s.minutes, 0);
    const sesHours = Math.round((mins / 60) * 10) / 10;
    const subInfo = subjects.find((s) => s.id === subId);
    return Math.max(subInfo?.currentHours || 0, sesHours);
  };

  // Export JSON backup
  const handleExportBackup = () => {
    const jsonStr = StorageService.exportBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tax_exam_os_backup_${getJSTDateString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Import JSON backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = StorageService.importBackup(content);
      if (success) {
        setImportStatus('バックアップデータを正常に復元しました！');
        onRestoreData();
      } else {
        setImportStatus('ファイルの形式が不正です。');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* 2027 Tax Exam Mission Banner */}
      <div className="p-4 md:p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-amber-500/30 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 mb-1">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>2027年 税理士試験合格ロードマップ</span>
            <span className="text-slate-500">·</span>
            <span className="text-slate-300">2026年11月3日 再始動</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">
            住民税絶対合格 × 4科目900時間STUDY OS
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            10月の未達は引きずらない。今日からMuscle+の「前回の自分を超える」原則を日々の理論暗唱・計算スピードに適用し、確実に合格水準を突破する。
          </p>
        </div>

        <div className="flex items-center gap-4 bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 self-start md:self-auto shrink-0">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-medium">本試験まで残り</div>
            <div className="font-mono text-2xl font-black text-amber-400 tabular-nums">
              {diffDays} <span className="text-xs text-slate-400 font-normal">日</span>
            </div>
          </div>
          <div className="w-[1px] h-9 bg-slate-800" />
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-medium">900時間達成率</div>
            <div className="font-mono text-2xl font-black text-emerald-400 tabular-nums">
              {progressRatio}%
            </div>
          </div>
        </div>
      </div>

      {/* Hall of Fame: 8/10 簿記3級合格勋章 */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            💮
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <span>簿記3級 合格達成</span>
              <span className="text-[11px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                2026年8月10日 合格
              </span>
            </h4>
            <p className="text-xs text-slate-400">
              最初の勲章獲得！簿記論・財務諸表論の計算土台へステップアップ中。
            </p>
          </div>
        </div>
        <div className="text-xs font-bold text-slate-400 font-mono">
          簿記2級 予定 → 簿記論へ接続
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 🎯 月別理論暗記マイルストーン & 8月本試験逆算ダッシュボード (新機能)            */}
      {/* ========================================================================= */}
      <div className="p-4 md:p-6 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/60">
                本試験逆算 × 暗記本数連動
              </span>
              <span className="text-xs text-slate-400">2026年11月 〜 2027年8月</span>
            </div>
            <h3 className="text-lg font-black text-white mt-1 flex items-center gap-2">
              <span>🎯 月別理論暗記マイルストーン（現在地と目標進捗）</span>
            </h3>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-right">
              <div className="text-[10px] text-slate-400 font-medium">現在暗記達成</div>
              <div className="font-mono text-base font-black text-emerald-400">
                {totalMasteredPillars}本 <span className="text-xs text-amber-400 font-normal">（骨格○: {totalLearningPillars}本）</span>
              </div>
            </div>

            <button
              onClick={() => setIsEditingMilestones(true)}
              className="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-indigo-600/20 cursor-pointer"
            >
              <span>⚙️ 目標本数を編集</span>
            </button>
          </div>
        </div>

        {/* Current Month Focus Highlight Card */}
        {currentMilestone && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-950/40 via-slate-950 to-amber-950/20 border border-indigo-500/40 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-black text-slate-950 bg-amber-400 px-2 py-0.5 rounded">
                  今月の現在地
                </span>
                <span className="text-sm font-bold text-white">{currentMilestone.label}</span>
                <span className="text-xs text-indigo-300 font-medium">（{currentMilestone.phaseName}）</span>
              </div>

              <div className="text-xs font-mono">
                今月目標: <strong className="text-amber-300 font-bold">{currentMilestone.targetMasteredPillars}本</strong>
                <span className="text-slate-400 ml-2">
                  （現在: <strong className="text-emerald-400">{totalMasteredPillars}本</strong> / 達成率: {Math.min(100, Math.round((totalMasteredPillars / Math.max(1, currentMilestone.targetMasteredPillars)) * 100))}%）
                </span>
              </div>
            </div>

            <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-400 via-emerald-400 to-indigo-500 rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, Math.round((totalMasteredPillars / Math.max(1, currentMilestone.targetMasteredPillars)) * 100))}%`,
                }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 flex-wrap gap-2 pt-0.5">
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="text-amber-400">📌 重点論点:</span>
                <span>{currentMilestone.focusTheoriesNote}</span>
              </span>
              <span className="font-mono text-slate-400">
                目標累計学習時間: <strong className="text-white">{currentMilestone.targetTotalHours}h</strong>
              </span>
            </div>
          </div>
        )}

        {/* 10-Month Milestone Timeline Cards (2026/11 〜 2027/08) */}
        <div className="space-y-2.5">
          <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
            <span>📅 8月本試験までの月別ロードマップ全推移</span>
            <span className="text-[11px] text-slate-400 font-normal">カードをクリックして各月の目標値をカスタム変更</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {milestones.map((ms, idx) => {
              const isCurrent = ms.monthKey === currentMonthKey;
              const isPast = ms.monthKey < currentMonthKey;
              const isPassedTarget = totalMasteredPillars >= ms.targetMasteredPillars;

              let phaseBadgeColor = 'text-cyan-400 bg-cyan-950/60 border-cyan-800/60';
              if (ms.phase === 'applied') phaseBadgeColor = 'text-amber-400 bg-amber-950/60 border-amber-800/60';
              if (ms.phase === 'pre_exam') phaseBadgeColor = 'text-rose-400 bg-rose-950/60 border-rose-800/60';
              if (ms.phase === 'exam') phaseBadgeColor = 'text-yellow-300 bg-yellow-950/80 border-yellow-500/80 font-black';

              return (
                <div
                  key={ms.monthKey}
                  onClick={() => {
                    setEditingMilestone({ ...ms });
                    setIsEditingMilestones(true);
                  }}
                  className={`p-3 rounded-xl border transition-all text-xs space-y-2 cursor-pointer group relative ${
                    isCurrent
                      ? 'bg-slate-950 border-amber-500 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500/40'
                      : isPast
                      ? 'bg-slate-950/50 border-slate-800/80 opacity-80'
                      : 'bg-slate-950/80 border-slate-800 hover:border-indigo-500/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-mono font-bold text-white text-[11px] flex items-center gap-1">
                      <span>{ms.label}</span>
                      {isCurrent && (
                        <span className="text-[9px] font-bold text-slate-950 bg-amber-400 px-1 py-0.2 rounded font-sans">
                          現在
                        </span>
                      )}
                    </span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${phaseBadgeColor}`}>
                      {ms.phaseName.replace(/^第[0-9]期\s*/, '')}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-slate-400">暗記目標:</span>
                      <span className="font-bold text-amber-300 text-xs">{ms.targetMasteredPillars}本</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] font-mono">
                      <span className="text-slate-400">目安時間:</span>
                      <span className="font-bold text-slate-200">{ms.targetTotalHours}h</span>
                    </div>
                  </div>

                  <div className="pt-1 border-t border-slate-850 text-[10px] text-slate-400 line-clamp-2 leading-tight">
                    {ms.focusTheoriesNote}
                  </div>

                  {isPassedTarget && (
                    <div className="text-[9px] font-bold text-emerald-400 flex items-center gap-1 pt-0.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>達成水準クリア</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4 Subjects Progress Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {subjects.map((sub) => {
          const currentH = subjectHours(sub.id);
          const percent = Math.min(100, Math.round((currentH / sub.targetHours) * 100));

          return (
            <div
              key={sub.id}
              className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3 relative overflow-hidden"
            >
              <div
                className="absolute top-0 left-0 right-0 h-1"
                style={{ backgroundColor: sub.color }}
              />

              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400">{sub.badge}</span>
                  <h4 className="text-base font-extrabold text-white">{sub.name}</h4>
                </div>
                {sub.has2027Reform && (
                  <span className="text-[10px] font-bold text-pink-400 bg-pink-950/60 border border-pink-800/60 px-1.5 py-0.5 rounded">
                    '27改正
                  </span>
                )}
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">目標: {sub.targetHours}h</span>
                  <span className="font-bold text-white tabular-nums">
                    {currentH}h ({percent}%)
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden border border-slate-800">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${percent}%`, backgroundColor: sub.color }}
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-400 leading-tight line-clamp-2">
                {sub.role}
              </p>
            </div>
          );
        })}
      </div>

      {/* Muscle+ Study History & Quick Action */}
      <div className="p-4 md:p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h3 className="text-base font-bold text-white">日々の学習セッション履歴（Muscle+ログ）</h3>
          </div>

          <div className="flex items-center gap-2">
            {/* Subject filter */}
            <select
              value={selectedSubjectFilter}
              onChange={(e) => setSelectedSubjectFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-amber-500"
            >
              <option value="all">全科目</option>
              <option value="resident">住民税</option>
              <option value="liquor">酒税法</option>
              <option value="bookkeeping">簿記論</option>
              <option value="financial">財務諸表論</option>
            </select>

            <button
              onClick={onOpenQuickLog}
              className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold rounded-lg transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>手動記録</span>
            </button>
          </div>
        </div>

        {filteredSessions.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500 bg-slate-950/40 rounded-xl border border-slate-800">
            まだ記録がありません。「＋ 記録する」から今日の学習時間を残しましょう。
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {filteredSessions.map((ses) => {
              const sub = subjects.find((s) => s.id === ses.subjectId);
              return (
                <div
                  key={ses.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-500 text-[11px]">{ses.date}</span>
                    <span
                      className="px-2 py-0.5 rounded text-[10px] font-bold"
                      style={{
                        backgroundColor: `${sub?.color || '#94A3B8'}20`,
                        color: sub?.color || '#F8FAFC',
                        border: `1px solid ${sub?.color || '#94A3B8'}40`,
                      }}
                    >
                      {sub?.shortName || ses.subjectId}
                    </span>
                    <span className="font-bold text-white font-mono text-sm tabular-nums">
                      {ses.minutes}分
                    </span>
                  </div>

                  <div className="text-slate-400 text-right truncate max-w-[200px] sm:max-w-md">
                    {ses.notes}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Backup and Cross-Device Sync (PC & iPhone) */}
      <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h4 className="text-xs font-bold text-slate-300">データバックアップ & デバイス同期</h4>
          <p className="text-[11px] text-slate-400">
            iPhoneとPCで学習データを引き継ぎたい場合は、JSONバックアップを保存・復元できます。
          </p>
          {importStatus && (
            <p className="text-[11px] font-bold text-emerald-400 mt-1">{importStatus}</p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportBackup}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition"
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>データ出力</span>
          </button>

          <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-emerald-400" />
            <span>データ復元</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
          </label>
        </div>
      </div>
      {/* ========================================================================= */}
      {/* ⚙️ 月別暗記目標 カスタム編集モーダル (ユーザーが自由に本数変更可能)             */}
      {/* ========================================================================= */}
      {isEditingMilestones && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-[#0D131F] border border-slate-700 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-base">⚙️</span>
                <h3 className="text-sm sm:text-base font-black text-white">
                  {editingMilestone ? `${editingMilestone.label} の暗記目標編集` : '月別暗記目標のカスタム設定'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setIsEditingMilestones(false);
                  setEditingMilestone(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer text-xs font-bold"
              >
                ✕ 閉じる
              </button>
            </div>

            {editingMilestone ? (
              <div className="space-y-4 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">{editingMilestone.label}</span>
                    <span className="text-[10px] text-amber-400 font-mono font-bold">{editingMilestone.phaseName}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-300 font-bold block">
                    目標暗記本数（完璧◎の本数）:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      max={120}
                      value={editingMilestone.targetMasteredPillars}
                      onChange={(e) =>
                        setEditingMilestone({
                          ...editingMilestone,
                          targetMasteredPillars: Math.max(1, parseInt(e.target.value, 10) || 1),
                        })
                      }
                      className="bg-slate-950 border border-slate-700 text-amber-300 font-mono font-black text-base rounded-xl px-3 py-2 w-28 focus:outline-none focus:border-amber-500"
                    />
                    <span className="text-slate-400">本</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    現在の暗記達成: <strong className="text-emerald-400">{totalMasteredPillars}本</strong>
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-300 font-bold block">
                    目標累計学習時間（時間）:
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={10}
                      max={1500}
                      value={editingMilestone.targetTotalHours}
                      onChange={(e) =>
                        setEditingMilestone({
                          ...editingMilestone,
                          targetTotalHours: Math.max(10, parseInt(e.target.value, 10) || 10),
                        })
                      }
                      className="bg-slate-950 border border-slate-700 text-white font-mono font-bold text-sm rounded-xl px-3 py-2 w-28 focus:outline-none focus:border-amber-500"
                    />
                    <span className="text-slate-400">時間</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-slate-300 font-bold block">
                    今月の重点論点・メモ:
                  </label>
                  <input
                    type="text"
                    value={editingMilestone.focusTheoriesNote}
                    onChange={(e) =>
                      setEditingMilestone({
                        ...editingMilestone,
                        focusTheoriesNote: e.target.value,
                      })
                    }
                    className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-amber-500"
                    placeholder="例: Sランク基礎論点の暗記＋計算個別スピード"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setIsEditingMilestones(false);
                      setEditingMilestone(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs transition cursor-pointer"
                  >
                    キャンセル
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSaveMilestoneEdit(editingMilestone)}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 transition cursor-pointer"
                  >
                    保存して更新
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2 text-xs">
                <p className="text-slate-400 pb-1">
                  編集したい月を選択してください。各月の目標暗記本数や累計時間を調整できます。
                </p>
                <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                  {milestones.map((ms) => (
                    <div
                      key={ms.monthKey}
                      onClick={() => setEditingMilestone({ ...ms })}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500/60 flex items-center justify-between cursor-pointer transition"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-white text-xs">{ms.label}</span>
                          <span className="text-[10px] text-slate-400">（{ms.phaseName}）</span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[240px] pt-0.5">
                          {ms.focusTheoriesNote}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-mono font-bold text-amber-400 text-sm">
                          {ms.targetMasteredPillars}本
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {ms.targetTotalHours}h
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
