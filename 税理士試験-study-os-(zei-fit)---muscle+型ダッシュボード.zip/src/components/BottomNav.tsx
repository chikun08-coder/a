import React from 'react';
import { BookMarked, Timer, TrendingUp, Layers, Bot } from 'lucide-react';

export type NavTab = 'theory' | 'calc' | 'roadmap' | 'anki' | 'coach';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onSelectTab }) => {
  const tabs = [
    {
      id: 'theory' as NavTab,
      label: '理論5段階',
      icon: BookMarked,
      tag: '最優先',
      color: 'text-amber-400',
    },
    {
      id: 'calc' as NavTab,
      label: '計算Muscle+',
      icon: Timer,
      tag: '速度測定',
      color: 'text-cyan-400',
    },
    {
      id: 'roadmap' as NavTab,
      label: '4科目900h',
      icon: TrendingUp,
      tag: '進捗',
      color: 'text-emerald-400',
    },
    {
      id: 'anki' as NavTab,
      label: 'NotebookLM',
      icon: Layers,
      tag: 'Anki連携',
      color: 'text-purple-400',
    },
    {
      id: 'coach' as NavTab,
      label: 'AI鬼コーチ',
      icon: Bot,
      tag: '厳格指導',
      color: 'text-rose-400',
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#080C14]/95 backdrop-blur-lg border-t border-slate-800/90 pb-safe shadow-2xl">
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] py-1 transition-all relative ${
                isActive ? tab.color : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {isActive && (
                <span className="absolute -top-[1px] w-8 h-[2px] bg-amber-400 rounded-full shadow-[0_0_8px_#F59E0B]" />
              )}
              <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 stroke-[2.5]' : 'stroke-2'}`} />
              <span className={`text-[10px] mt-1 font-medium tracking-tight whitespace-nowrap ${isActive ? 'font-bold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
