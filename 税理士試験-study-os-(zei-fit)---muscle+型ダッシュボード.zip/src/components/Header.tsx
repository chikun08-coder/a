import React, { useState } from 'react';
import { Flame, Trophy, Smartphone, Download, RotateCcw, ShieldCheck, Cloud, RefreshCw, CheckCircle2 } from 'lucide-react';
import { SubjectInfo } from '../types';
import { usePWAInstall } from './pwa/usePWAInstall';

interface HeaderProps {
  subjects: SubjectInfo[];
  totalHours: number;
  streakDays: number;
  onOpenQuickLog: () => void;
  onExportBackup: () => void;
  syncStatus?: 'idle' | 'syncing' | 'synced' | 'error';
  onSyncNow?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  subjects,
  totalHours,
  streakDays,
  onOpenQuickLog,
  onExportBackup,
  syncStatus = 'idle',
  onSyncNow,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSModal, setShowIOSModal] = useState(false);

  // Target 900 hours
  const targetTotal = 900;
  const progressPercent = Math.min(100, Math.round((totalHours / targetTotal) * 100));

  // Countdown to Tax Exam 2027 (approx. August 4, 2027)
  const examDate = new Date('2027-08-04T09:00:00');
  const now = new Date();
  const diffDays = Math.max(0, Math.ceil((examDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#080C14]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5 transition-all">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Wordmark (Top Bar Contract: Single text wordmark) */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center font-black text-slate-950 text-sm shadow-md shadow-amber-500/20">
                税
              </div>
              <div>
                <span className="font-extrabold tracking-tight text-white text-base md:text-lg">
                  ZEI-FIT <span className="text-amber-400 text-xs font-semibold tracking-normal hidden sm:inline">STUDY OS</span>
                </span>
                <span className="block text-[10px] text-slate-400 font-medium">Muscle+型 税理士試験 4科目</span>
              </div>
            </div>

            {/* Exam Countdown Badge */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/90 border border-slate-800 text-xs text-slate-300">
              <span className="text-slate-400">2027本試験まで</span>
              <span className="font-mono font-bold text-amber-400 text-sm tabular-nums">あと{diffDays}日</span>
            </div>
          </div>

          {/* Quick Metrics Bar (Streak + 900h Target) */}
          <div className="flex items-center gap-3 md:gap-6">
            {/* Streak Counter */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-300">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
              <span className="text-xs font-semibold">Streak</span>
              <span className="font-mono font-bold text-sm text-amber-300 tabular-nums">{streakDays}日</span>
            </div>

            {/* 900h Progress Gauge */}
            <div className="hidden sm:flex items-center gap-2">
              <div className="text-right">
                <div className="text-[10px] text-slate-400 font-medium leading-tight">4科目 目標900h</div>
                <div className="text-xs font-bold text-slate-200 font-mono tabular-nums">
                  {totalHours}<span className="text-slate-500">/900h</span> ({progressPercent}%)
                </div>
              </div>
              <div className="w-16 h-2 rounded-full bg-slate-800 overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Primary Action Button */}
            <div className="flex items-center gap-2">
              {/* Install PWA Button */}
              {isInstallable && (
                <button
                  onClick={install}
                  className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 border border-slate-700 rounded-lg hover:bg-slate-800 transition"
                  title="スマホ・PCにアプリとしてインストール"
                >
                  <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>アプリ保存</span>
                </button>
              )}

              {isIOS && !isInstalled && (
                <button
                  onClick={() => setShowIOSModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-amber-300 bg-amber-950/40 border border-amber-700/50 rounded-lg"
                >
                  <Smartphone className="w-3 h-3" />
                  <span>iPhone追加</span>
                </button>
              )}

              {/* Cloud Sync Button (Smartphone ↔ PC) */}
              <button
                onClick={onSyncNow}
                disabled={syncStatus === 'syncing'}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                  syncStatus === 'syncing'
                    ? 'bg-amber-950/40 text-amber-300 border-amber-600/40 animate-pulse'
                    : syncStatus === 'synced'
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-600/50 hover:bg-emerald-900/50'
                    : syncStatus === 'error'
                    ? 'bg-rose-950/40 text-rose-300 border-rose-600/40'
                    : 'bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800'
                }`}
                title="スマホとPCの学習記録をリアルタイム同期（タップで手動同期）"
              >
                <Cloud className={`w-3.5 h-3.5 ${syncStatus === 'synced' ? 'text-emerald-400' : 'text-amber-400'}`} />
                <span className="hidden sm:inline">
                  {syncStatus === 'syncing' ? '同期中...' : syncStatus === 'synced' ? 'クラウド同期' : 'スマホ↔PC同期'}
                </span>
                {syncStatus === 'synced' ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                ) : (
                  <RefreshCw className={`w-3 h-3 ${syncStatus === 'syncing' ? 'animate-spin' : ''}`} />
                )}
              </button>

              <button
                onClick={onOpenQuickLog}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 active:scale-95 transition rounded-lg shadow-sm shadow-amber-400/20 whitespace-nowrap"
              >
                <span>＋ 記録する</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* iOS Install Instruction Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#0F172A] border border-slate-700 p-6 shadow-2xl text-slate-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">iPhoneホーム画面に追加</h3>
                <p className="text-xs text-slate-400">Muscle+のようにアプリ形式で起動</p>
              </div>
            </div>
            <ol className="text-xs text-slate-300 space-y-2.5 my-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center shrink-0">1</span>
                <span>Safari下部の<strong>「共有（四角と上矢印）」</strong>アイコンをタップ</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center shrink-0">2</span>
                <span>メニューを少し下にスクロールし<strong>「ホーム画面に追加」</strong>を選択</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center shrink-0">3</span>
                <span>右上の<strong>「追加」</strong>を押すとホーム画面から全画面で起動できます</span>
              </li>
            </ol>
            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
            >
              閉じる
            </button>
          </div>
        </div>
      )}
    </>
  );
};
