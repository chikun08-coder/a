/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { TheoryTrainingView } from './components/theory/TheoryTrainingView';
import { CalculationSpeedView } from './components/calc/CalculationSpeedView';
import { RoadmapView } from './components/roadmap/RoadmapView';
import { NotebookLMAnkiHub } from './components/anki/NotebookLMAnkiHub';
import { TrainerChatView } from './components/chat/TrainerChatView';
import { QuickLogModal } from './components/QuickLogModal';
import { StorageService, isRealStudySession } from './services/storage';
import { getJSTDateString, addDaysJST } from './utils/date';
import { 
  SubjectInfo, TheoryItem, CalculationItem, 
  AnkiCard, StudySession, TrainerMessage, SubjectId, MonthlyMilestone 
} from './types';

export default function App() {
  // Navigation: Default to 'theory' as user explicitly prioritized
  const [currentTab, setCurrentTab] = useState<NavTab>('theory');

  // Core Data Stores with LocalStorage synchronization
  const [subjects, setSubjects] = useState<SubjectInfo[]>(() => StorageService.getSubjects());
  const [theories, setTheories] = useState<TheoryItem[]>(() => StorageService.getTheories());
  const [calculations, setCalculations] = useState<CalculationItem[]>(() => StorageService.getCalculations());
  const [ankiCards, setAnkiCards] = useState<AnkiCard[]>(() => StorageService.getAnkiCards());
  const [sessions, setSessions] = useState<StudySession[]>(() => StorageService.getSessions());
  const [chatMessages, setChatMessages] = useState<TrainerMessage[]>(() => StorageService.getChatMessages());
  const [milestones, setMilestones] = useState<MonthlyMilestone[]>(() => StorageService.getMilestones());

  // Quick Log modal state
  const [isQuickLogOpen, setIsQuickLogOpen] = useState<boolean>(false);
  const [isSendingChat, setIsSendingChat] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced' | 'error'>('idle');

  const lastJstDateRef = useRef<string>(getJSTDateString());
  const isHydratedRef = useRef<boolean>(false);

  const reloadStoresIntoState = () => {
    setSubjects(StorageService.getSubjects());
    setTheories(StorageService.getTheories());
    setCalculations(StorageService.getCalculations());
    setAnkiCards(StorageService.getAnkiCards());
    setSessions(StorageService.getSessions());
    setChatMessages(StorageService.getChatMessages());
    setMilestones(StorageService.getMilestones());
  };

  // Initial IndexedDB Hydration + Cross-Device Sync + JST Midnight Rollover Watcher
  useEffect(() => {
    let isMounted = true;

    const initialSync = async () => {
      setSyncStatus('syncing');
      try {
        // Step 1: Hydrate from IndexedDB Immortal Mirror & Snapshots BEFORE enabling save effects!
        await StorageService.hydrateFromIndexedDB();
        if (isMounted) {
          reloadStoresIntoState();
          isHydratedRef.current = true;
          window.dispatchEvent(new Event('tax_exam_sync_updated'));
        } else {
          isHydratedRef.current = true;
        }

        // Step 2: Check rescued client progress vs server
        const localVaultCount = Object.keys(StorageService.getPillarVault()).length;
        const localSessions = StorageService.getSessions().filter(isRealStudySession);
        const localSubHours = StorageService.getSubjects().reduce((sum, s) => sum + (s?.currentHours || 0), 0);

        if (localVaultCount > 0 || localSessions.length > 0 || localSubHours > 0) {
          await StorageService.pushToServer();
          const pullRes = await StorageService.pullFromServer(false);
          if (pullRes.updated && isMounted) {
            reloadStoresIntoState();
            window.dispatchEvent(new Event('tax_exam_sync_updated'));
          }
        } else {
          // Fresh client device: safely pull if server has real progress
          const pullRes = await StorageService.pullFromServer(false);
          if (pullRes.updated && isMounted) {
            reloadStoresIntoState();
            window.dispatchEvent(new Event('tax_exam_sync_updated'));
          }
        }
        if (isMounted) setSyncStatus('synced');
      } catch {
        isHydratedRef.current = true;
        if (isMounted) setSyncStatus('error');
      }
    };
    initialSync();

    const checkJstRollover = () => {
      const currentJst = getJSTDateString();
      if (currentJst !== lastJstDateRef.current) {
        lastJstDateRef.current = currentJst;
        StorageService.saveDailySnapshot();
        window.dispatchEvent(new CustomEvent('tax_exam_date_rollover', { detail: { date: currentJst } }));
      }
    };

    // Auto-sync & date rollover check whenever user returns to or wakes up the app
    const handleFocusSync = async () => {
      checkJstRollover();
      try {
        const res = await StorageService.pullFromServer(false);
        if (res.updated && isMounted) {
          reloadStoresIntoState();
          window.dispatchEvent(new Event('tax_exam_sync_updated'));
          setSyncStatus('synced');
        }
        if (res.needsPush) {
          await StorageService.pushToServer();
        }
      } catch {}
    };

    const handleSaved = () => {
      if (isMounted) setSyncStatus('synced');
    };

    const rolloverInterval = setInterval(checkJstRollover, 30000);

    window.addEventListener('tax_exam_sync_saved', handleSaved);
    window.addEventListener('focus', handleFocusSync);
    document.addEventListener('visibilitychange', handleFocusSync);

    return () => {
      isMounted = false;
      clearInterval(rolloverInterval);
      window.removeEventListener('tax_exam_sync_saved', handleSaved);
      window.removeEventListener('focus', handleFocusSync);
      document.removeEventListener('visibilitychange', handleFocusSync);
    };
  }, []);

  // Manual Instant Sync Trigger (client-first push then safe pull)
  const handleSyncNow = async () => {
    setSyncStatus('syncing');
    try {
      await StorageService.pushToServer();
      const pullRes = await StorageService.pullFromServer(false);
      if (pullRes.updated) {
        reloadStoresIntoState();
        window.dispatchEvent(new Event('tax_exam_sync_updated'));
      }
      setSyncStatus('synced');
    } catch {
      setSyncStatus('error');
    }
  };

  // Sync state to LocalStorage ONLY AFTER initial IndexedDB hydration completes
  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveSubjects(subjects);
  }, [subjects]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveTheories(theories);
  }, [theories]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveCalculations(calculations);
    const timer = setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 1500);
    return () => clearTimeout(timer);
  }, [calculations]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveAnkiCards(ankiCards);
  }, [ankiCards]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveSessions(sessions);
    const timer = setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 1500);
    return () => clearTimeout(timer);
  }, [sessions]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveChatMessages(chatMessages);
  }, [chatMessages]);

  useEffect(() => {
    if (!isHydratedRef.current) return;
    StorageService.saveMilestones(milestones);
    const timer = setTimeout(() => {
      StorageService.pushToServer().catch(() => {});
    }, 1500);
    return () => clearTimeout(timer);
  }, [milestones]);

  const handleUpdateMilestones = (updated: MonthlyMilestone[]) => {
    setMilestones(updated);
    StorageService.saveMilestones(updated);
  };

  // Total Study Hours (never drop below either recorded sessions or subject cumulative hours)
  const totalMinutes = sessions.reduce((acc, s) => acc + (s.minutes > 0 ? s.minutes : 0), 0);
  const sessionHours = Math.round((totalMinutes / 60) * 10) / 10;
  const subjectSumHours = Math.round(subjects.reduce((acc, s) => acc + (s.currentHours || 0), 0) * 10) / 10;
  const totalHours = Math.max(sessionHours, subjectSumHours);

  // Streak calculation (consecutive active days in JST)
  const calculateStreak = () => {
    const activeSessions = sessions.filter((s) => s.minutes > 0);
    if (activeSessions.length === 0) return 1;
    const uniqueDates = new Set(activeSessions.map((s) => s.date));
    const today = getJSTDateString();

    let streak = 0;
    const startOffset = uniqueDates.has(today) ? 0 : 1;

    for (let i = startOffset; i < 365; i++) {
      const dateStr = addDaysJST(today, -i);
      if (uniqueDates.has(dateStr)) {
        streak++;
      } else {
        break;
      }
    }
    return Math.max(1, streak);
  };

  const streakDays = calculateStreak();

  // Handle study time record (synchronously persisted to LocalStorage + IDB + Snapshot + Server)
  const handleRecordStudyTime = (subjectId: SubjectId, minutes: number, notes: string) => {
    const newSession: StudySession = {
      id: 'ses-' + Date.now(),
      date: getJSTDateString(),
      subjectId,
      minutes,
      type: 'theory',
      notes,
    };
    setSessions((prev) => {
      const next = [newSession, ...prev];
      StorageService.saveSessions(next);
      return next;
    });

    setSubjects((prev) => {
      const next = prev.map((s) => {
        if (s.id === subjectId) {
          const currentTotal = Math.round(((s.currentHours * 60 + minutes) / 60) * 10) / 10;
          return { ...s, currentHours: currentTotal };
        }
        return s;
      });
      StorageService.saveSubjects(next);
      return next;
    });

    StorageService.setLocalTimestamp(Date.now());
    StorageService.saveDailySnapshot();
    StorageService.pushToServer().catch(() => {});
  };

  // Theory update handler - synchronously persist locally and immediately push to server on every tap
  const handleUpdateTheory = (updated: TheoryItem) => {
    setTheories((prev) => {
      const next = prev.map((t) => (t.id === updated.id ? updated : t));
      StorageService.saveTheories(next);
      return next;
    });
    // Instant 0ms server sync on tap (no debounce timer lost on reload/tab switch)
    StorageService.pushToServer().catch(() => {});
  };

  // Calculation update & add handlers
  const handleUpdateCalculation = (updated: CalculationItem) => {
    setCalculations((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  const handleAddCalculation = (newItem: CalculationItem) => {
    setCalculations((prev) => [newItem, ...prev]);
  };

  // Anki cards update & add handlers
  const handleAddAnkiCards = (newCards: AnkiCard[]) => {
    setAnkiCards((prev) => [...newCards, ...prev]);
  };

  const handleUpdateAnkiCard = (updated: AnkiCard) => {
    setAnkiCards((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  const handleAddParsedTheories = (newTheories: TheoryItem[]) => {
    setTheories((prev) => [...newTheories, ...prev]);
  };

  // Chat message send handler
  const handleSendMessage = async (userText: string) => {
    const userMsg: TrainerMessage = {
      id: 'msg-u-' + Date.now(),
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...chatMessages, userMsg];
    setChatMessages(newHistory);
    setIsSendingChat(true);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ role: m.role, content: m.content })),
          currentSubject: '住民税',
          userStats: {
            totalHours,
            streakDays,
            theoriesCount: theories.length,
          },
        }),
      });

      if (!response.ok) {
        throw new Error('コーチの応答取得に失敗しました。');
      }

      const data = await response.json();
      const assistantMsg: TrainerMessage = {
        id: 'msg-a-' + Date.now(),
        role: 'assistant',
        content: data.content || '回答がありませんでした。',
        timestamp: new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, assistantMsg]);
    } catch (e: any) {
      const errorMsg: TrainerMessage = {
        id: 'msg-err-' + Date.now(),
        role: 'assistant',
        content: `エラーが発生しました: ${e?.message || '通信エラー'}\nもう一度送信してみてください。`,
        timestamp: new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSendingChat(false);
    }
  };

  // Restore state callback
  const handleRestoreData = () => {
    setSubjects(StorageService.getSubjects());
    setTheories(StorageService.getTheories());
    setCalculations(StorageService.getCalculations());
    setAnkiCards(StorageService.getAnkiCards());
    setSessions(StorageService.getSessions());
    setChatMessages(StorageService.getChatMessages());
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-slate-100 flex flex-col font-sans pb-20 md:pb-6">
      {/* Universal Top Header */}
      <Header
        subjects={subjects}
        totalHours={totalHours}
        streakDays={streakDays}
        onOpenQuickLog={() => setIsQuickLogOpen(true)}
        onExportBackup={() => StorageService.exportBackup()}
        syncStatus={syncStatus}
        onSyncNow={handleSyncNow}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 md:p-6 transition-all">
        {currentTab === 'theory' && (
          <TheoryTrainingView
            theories={theories}
            milestones={milestones}
            onUpdateTheory={handleUpdateTheory}
            onRecordStudyTime={handleRecordStudyTime}
            onNavigateToRoadmap={() => setCurrentTab('roadmap')}
          />
        )}

        {currentTab === 'calc' && (
          <CalculationSpeedView
            calculations={calculations}
            onUpdateCalculation={handleUpdateCalculation}
            onAddCalculation={handleAddCalculation}
            onRecordStudyTime={handleRecordStudyTime}
          />
        )}

        {currentTab === 'roadmap' && (
          <RoadmapView
            subjects={subjects}
            sessions={sessions}
            theories={theories}
            milestones={milestones}
            onUpdateMilestones={handleUpdateMilestones}
            onOpenQuickLog={() => setIsQuickLogOpen(true)}
            onRestoreData={handleRestoreData}
          />
        )}

        {currentTab === 'anki' && (
          <NotebookLMAnkiHub
            ankiCards={ankiCards}
            onAddAnkiCards={handleAddAnkiCards}
            onUpdateAnkiCard={handleUpdateAnkiCard}
            onAddParsedTheories={handleAddParsedTheories}
          />
        )}

        {currentTab === 'coach' && (
          <TrainerChatView
            messages={chatMessages}
            onSendMessage={handleSendMessage}
            onClearChat={() => {
              setChatMessages([]);
              StorageService.saveChatMessages([]);
            }}
            isSending={isSendingChat}
            currentSubject="resident"
          />
        )}
      </main>

      {/* Mobile-First Sticky Bottom Navigation */}
      <BottomNav currentTab={currentTab} onSelectTab={setCurrentTab} />

      {/* Quick Study Session Modal */}
      <QuickLogModal
        isOpen={isQuickLogOpen}
        onClose={() => setIsQuickLogOpen(false)}
        onSaveSession={(ses) => {
          setSessions((prev) => {
            const next = [ses, ...prev];
            StorageService.saveSessions(next);
            return next;
          });
          setSubjects((prev) => {
            const next = prev.map((s) => {
              if (s.id === ses.subjectId) {
                const currentTotal = Math.round(((s.currentHours * 60 + ses.minutes) / 60) * 10) / 10;
                return { ...s, currentHours: currentTotal };
              }
              return s;
            });
            StorageService.saveSubjects(next);
            return next;
          });
          StorageService.setLocalTimestamp(Date.now());
          StorageService.saveDailySnapshot();
          StorageService.pushToServer().catch(() => {});
        }}
      />
    </div>
  );
}
