import confetti from 'canvas-confetti';

export function firePRCelebration() {
  try {
    // Left burst
    confetti({
      particleCount: 50,
      angle: 60,
      spread: 55,
      origin: { x: 0, y: 0.8 },
      colors: ['#F59E0B', '#10B981', '#F43F5E', '#3B82F6', '#EAB308'],
    });
    // Right burst
    confetti({
      particleCount: 50,
      angle: 120,
      spread: 55,
      origin: { x: 1, y: 0.8 },
      colors: ['#F59E0B', '#10B981', '#F43F5E', '#3B82F6', '#EAB308'],
    });
  } catch (e) {
    console.warn('Confetti error:', e);
  }
}

export function formatSeconds(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}分${secs < 10 ? '0' : ''}${secs}秒`;
}

export function formatTimeDigital(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
}
