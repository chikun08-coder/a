/**
 * Japan Standard Time (Asia/Tokyo) & Deterministic Deck Utilities
 * Ensures midnight rollover happens strictly at 00:00 JST (not 09:00 JST via UTC toISOString)
 */

export function getJSTDateString(date: Date = new Date()): string {
  try {
    // sv-SE locale formats strictly as YYYY-MM-DD
    const formatted = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'Asia/Tokyo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
    if (/^\d{4}-\d{2}-\d{2}$/.test(formatted)) {
      return formatted;
    }
  } catch {
    // Fallback below
  }
  // Manual UTC+9 calculation fallback
  const jstMs = date.getTime() + 9 * 60 * 60 * 1000;
  const jstDate = new Date(jstMs);
  const y = jstDate.getUTCFullYear();
  const m = String(jstDate.getUTCMonth() + 1).padStart(2, '0');
  const d = String(jstDate.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getJSTMonthKey(date: Date = new Date()): string {
  return getJSTDateString(date).slice(0, 7);
}

export function getJSTCalendarParts(date: Date = new Date()): {
  year: number;
  month: number;
  day: number;
  lastDayOfMonth: number;
} {
  const dateStr = getJSTDateString(date);
  const [year, month, day] = dateStr.split('-').map(Number);
  // Day 0 of next month in UTC gives exact days in current month
  const lastDayOfMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return { year, month, day, lastDayOfMonth };
}

export function addDaysJST(dateStr: string, days: number): string {
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    const utc = new Date(Date.UTC(y, m - 1, d + days));
    const nextY = utc.getUTCFullYear();
    const nextM = String(utc.getUTCMonth() + 1).padStart(2, '0');
    const nextD = String(utc.getUTCDate()).padStart(2, '0');
    return `${nextY}-${nextM}-${nextD}`;
  } catch {
    return dateStr;
  }
}

/**
 * Strips trailing evaluation markers (◎, ○, ❌, ×, △, ⚪︎) from display headings
 * while preserving the underlying heading string used as a storage key.
 */
export function formatCleanPillarHeading(heading: string): string {
  if (!heading) return '';
  const cleaned = heading.replace(/[\s　]*[◎○❌×△⚪︎]+[\s　]*$/g, '').trim();
  return cleaned || heading;
}

/**
 * Normalizes a pillar key for vault storage lookup, eliminating mismatch between
 * legacy symbol-tagged headings and clean headings.
 */
export function normalizePillarKey(key: string): string {
  if (!key) return '';
  return key.replace(/[\s　]*[◎○❌×△⚪︎]+[\s　]*$/g, '').trim();
}

/**
 * Deterministic PRNG (LCG) seeded from an arbitrary string
 */
export function createSeededRandom(seedStr: string): () => number {
  let seed = 2166136261 >>> 0;
  for (let i = 0; i < seedStr.length; i++) {
    seed ^= seedStr.charCodeAt(i);
    seed = Math.imul(seed, 16777619) >>> 0;
  }
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

/**
 * Deterministically shuffles an array given a seed string
 */
export function deterministicShuffle<T>(items: readonly T[], seedStr: string): T[] {
  const arr = [...items];
  const rand = createSeededRandom(seedStr);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
