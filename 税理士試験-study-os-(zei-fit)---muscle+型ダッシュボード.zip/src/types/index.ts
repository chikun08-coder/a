export type SubjectId = 'resident' | 'liquor' | 'bookkeeping' | 'financial';

export interface SubjectInfo {
  id: SubjectId;
  name: string;
  shortName: string;
  badge: string;
  targetHours: number;
  currentHours: number;
  role: string;
  has2027Reform: boolean;
  color: string;
}

export interface TheoryPracticeLog {
  id: string;
  date: string;
  level: number;
  timeSeconds: number;
  score: number;
  reproductionRate: number;
  isPersonalBest: boolean;
  missingItems?: string[];
  feedback?: string;
}

export interface TheorySubSection {
  num: string; // e.g. '[1]' or '(1)'
  heading: string;
  essence?: string; // 💡 ようはこういうこと（1行で本質をズバッと解説）
  mnemonic?: string; // 語呂合わせ
  deepDiveNote?: string; // 🔍 一字一句暗記・理屈の超解説トグル（受験生必見）
  body: string;
  keyPoints?: string[];
  status?: 'mastered' | 'learning' | 'weak'; // ◎ (mastered), ○ (learning), ❌ (weak)
  lockCount?: number; // 0: ❌, 1: ○, 2+: ◎ (2回連続で完璧)
  updatedAt?: number;
  isUserAction?: boolean;
  lastLockedAt?: string;
  diagram?: string; // 🗺️ 柱ごとの図解・構造ビジュアルフロー
  imageUrl?: string; // 🖼️ 柱ごとのビジュアルイメージ図（生成画像）
}

export interface TheoryParentSection {
  id: string;
  num: string; // e.g. '(1)', '(2)', '〔1〕', '〔2〕'
  heading: string;
  subSections: TheorySubSection[];
}

export interface TaxDifferenceItem {
  category: string;
  resident: string;
  incomeTax: string;
}

export interface StoryDialogue {
  speaker: string;
  avatar: string;
  text: string;
  side: 'left' | 'right';
}

export interface QuickKnockQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  tip: string;
}

export interface FlowStep {
  step: number;
  pillarNum?: string; // e.g. '[1]', '[2]'
  title: string;
  actor: string; // e.g. '👨 納税者', '🏛️ 市町村長', '🍶 蔵元'
  actionOrCondition: string; // 発動要件・前提事実
  judgment: string; // 税法上の判定基準
  outcome: string; // 結論・法的効果（課税/非課税/通知など）
  subNote?: string; // 語呂・実務注意点
}

export interface DailyQueueItem {
  id: string;
  theoryId: string;
  theoryNumber: string;
  theoryTitle: string;
  pillarNum: string;
  pillarHeading: string;
  taskType: 'quiz' | 'diagram' | 'cloze' | 'outline';
  reasonLabel: string;
  urgency: 'high' | 'medium' | 'normal';
  subSection: TheorySubSection;
  quickKnockQuestion?: QuickKnockQuestion;
  flowStep?: FlowStep;
}

export interface TheoryItem {
  id: string;
  theoryNumber: string; // '1-1', '1-2', '3-4', etc.
  subjectId: SubjectId;
  title: string;
  category: string;
  subCategory?: string; // 細分類タグ（例: '人的控除', '税額控除', '非課税・減免'）
  isRevised2027: boolean;
  standardMinutes: number;
  priorityRank: 'S' | 'A' | 'B' | 'D'; // S: 超最重要, A: 頻出・単体/応用本命, B: 標準, D: 直近本試験出題済（自動復習除外）
  priorityOrder: number; // 覚えるべき順序 (1, 2, 3...)
  examRankNote: string; // 本試験出題ランキング、出題回数
  mnemonics: string[]; // 語呂合わせ一覧
  lv1Hint: string;
  lv2Outline: string[];
  lv3KeyRequirements: string[];
  lv4FullText: string;
  easyExplanation?: string; // 【1】超日常語訳・要するにこういうこと
  clozeKeywords?: string[]; // 【2】タップでめくる虫食い対象ワード
  storyDialogue?: StoryDialogue[]; // 【4】キャラクター吹き出し・ストーリー図解
  quickKnockQuestions?: QuickKnockQuestion[]; // 【5】3秒即答クイックノック
  flowSteps?: FlowStep[]; // 【6】柱の構造フロー図（各柱の判定ステップと結論）
  parentSections?: TheoryParentSection[];
  structuredSubSections?: TheorySubSection[];
  pillarStatuses?: Record<string, { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }>;
  taxDifferenceTable?: TaxDifferenceItem[];
  visualDiagram?: string;
  bestScore: number;
  bestTimeSeconds: number;
  currentStage: number; // 1 to 5
  lastPracticed?: string;
  history: TheoryPracticeLog[];
}

export interface CalculationLog {
  id: string;
  date: string;
  timeSeconds: number;
  previousBestSeconds?: number;
  isCorrect: boolean;
  errorCategory: 'none' | 'lack_of_knowledge' | 'procedure_stalled' | 'calc_mistake' | 'misread';
  memo: string;
  isPersonalBest: boolean;
}

export interface CalculationItem {
  id: string;
  subjectId: SubjectId;
  title: string;
  category: string;
  targetMinutes: number;
  bestTimeSeconds: number;
  consecutiveCorrect: number;
  logs: CalculationLog[];
}

export interface AnkiCard {
  id: string;
  subjectId: SubjectId;
  theoryId?: string;
  deckName: string;
  front: string;
  back: string;
  tag: string;
  intervalDays: number;
  repetitions: number;
  easeFactor: number;
  nextReviewDate: string;
}

export interface StudySession {
  id: string;
  date: string;
  subjectId: SubjectId;
  minutes: number;
  type: 'theory' | 'calc' | 'anki' | 'lecture';
  notes: string;
}

export interface TrainerMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface MonthlyMilestone {
  monthKey: string; // '2026-11', '2026-12', '2027-01', ...
  label: string; // '2026年11月'
  phase: 'basic' | 'applied' | 'pre_exam' | 'exam';
  phaseName: string; // '基礎定着期', '応用展開期', '直前総仕上げ期', '本試験'
  targetMasteredPillars: number; // 目標暗記本数（◎）
  targetTotalHours: number; // 目標累計学習時間
  focusTheoriesNote: string; // 今月の重点論点
}

export interface TheorySRSData {
  theoryId: string;
  intervalDays: number; // 3 -> 7 -> 14 -> 30
  level: number; // 1: 3日, 2: 7日, 3: 14日, 4: 30日
  lastReviewedDate: string; // YYYY-MM-DD
  nextDueDate: string; // YYYY-MM-DD
  lapseCount: number; // 忘却回数
}

