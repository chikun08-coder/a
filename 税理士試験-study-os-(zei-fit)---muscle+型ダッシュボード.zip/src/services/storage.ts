import {
  SubjectInfo,
  TheoryItem,
  TheoryPracticeLog,
  CalculationItem,
  CalculationLog,
  AnkiCard,
  StudySession,
  TrainerMessage,
  MonthlyMilestone,
  TheorySRSData,
  SubjectId,
} from '../types';
import {
  INITIAL_SUBJECTS,
  INITIAL_THEORIES,
  INITIAL_CALCULATIONS,
  INITIAL_ANKI_CARDS,
  INITIAL_STUDY_SESSIONS,
  INITIAL_MILESTONES,
} from '../data/initialData';
import { getJSTDateString, normalizePillarKey } from '../utils/date';

const STORAGE_KEYS = {
  SUBJECTS: 'tax_exam_subjects_v10',
  THEORY_DELTAS: 'tax_exam_theory_deltas_v11',
  CALCULATIONS: 'tax_exam_calculations_v10',
  ANKI_CARDS: 'tax_exam_anki_cards_v10',
  SESSIONS: 'tax_exam_sessions_v10',
  CHAT_MESSAGES: 'tax_exam_chat_messages_v10',
  MILESTONES: 'tax_exam_milestones_v10',
  LAST_RELOAD: 'tax_exam_last_active_v10',
};

const LEGACY_BLOATED_THEORY_KEYS = [
  'tax_exam_theories_v10',
  'tax_exam_theories_persistent',
  'tax_exam_theories_v9',
  'tax_exam_theories_v8',
  'tax_exam_theories',
];

const VAULT_KEY = 'tax_exam_pillar_vault_v2';
const LEGACY_VAULT_KEY = 'tax_exam_pillar_vault_v1';
const POISON_TEST_TS = 1794395356434;

export function isGenuineUserAction(p: any): boolean {
  if (!p || typeof p !== 'object') return false;
  if (p.updatedAt === POISON_TEST_TS) return false;
  if (p.isUserAction === true || p.isUserEvaluated === true) return true;
  if (p.isUserAction === false) return false;
  return Boolean(
    p.status === 'mastered' ||
      p.status === 'learning' ||
      (typeof p.lockCount === 'number' && p.lockCount > 0) ||
      (typeof p.updatedAt === 'number' && p.updatedAt > 0)
  );
}

export function isRealStudySession(s: any): boolean {
  if (!s || typeof s !== 'object') return false;
  if (s.id === 'ses-real-0') return false;
  return Boolean((typeof s.minutes === 'number' && s.minutes > 0) || (typeof s.notes === 'string' && s.notes.trim()));
}

export interface PillarVaultEntry {
  theoryId: string;
  pillarKey: string;
  status: 'mastered' | 'learning' | 'weak';
  lockCount: number;
  updatedAt: number;
  isUserAction: boolean;
}

export interface TheoryProgressDelta {
  id: string;
  theoryNumber: string;
  pillarStatuses: Record<
    string,
    { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }
  >;
  currentStage: number;
  bestScore: number;
  bestTimeSeconds: number;
  history: TheoryPracticeLog[];
  lastPracticed?: string;
  isCustomTheory?: boolean;
  fullCustomItem?: TheoryItem;
}

// ============================================================================
// Lightweight Zero-Dependency IndexedDB Mirror ("TaxExamImmortalDB")
// Protects progress even if mobile Safari/Chrome evicts localStorage overnight
// ============================================================================
const IDB_NAME = 'TaxExamImmortalDB';
const IDB_VERSION = 1;
const IDB_STORE = 'kv';

let idbPromise: Promise<IDBDatabase | null> | null = null;

function openImmortalDB(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  if (!idbPromise) {
    // Request persistent storage permission from browser (prevents OS cache eviction)
    try {
      if (navigator.storage && typeof navigator.storage.persist === 'function') {
        navigator.storage.persist().catch(() => {});
      }
    } catch {}

    idbPromise = new Promise((resolve) => {
      try {
        const req = window.indexedDB.open(IDB_NAME, IDB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(IDB_STORE)) {
            db.createObjectStore(IDB_STORE);
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }
  return idbPromise;
}

async function idbSet(key: string, value: any): Promise<void> {
  const db = await openImmortalDB();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      tx.objectStore(IDB_STORE).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

async function idbGet<T = any>(key: string): Promise<T | null> {
  const db = await openImmortalDB();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbGetAll(): Promise<Record<string, any>> {
  const db = await openImmortalDB();
  if (!db) return {};
  return new Promise((resolve) => {
    const out: Record<string, any> = {};
    try {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const req = tx.objectStore(IDB_STORE).openCursor();
      req.onsuccess = () => {
        const cursor = req.result;
        if (cursor) {
          out[String(cursor.key)] = cursor.value;
          cursor.continue();
        } else {
          resolve(out);
        }
      };
      req.onerror = () => resolve(out);
    } catch {
      resolve(out);
    }
  });
}

// ============================================================================
// Theory Pillar & Stage Helpers (Strict Zero-Zombie Logic)
// ============================================================================
function getCanonicalPillarDefaults(
  theory: TheoryItem
): Map<string, { status: 'mastered' | 'learning' | 'weak'; lockCount: number }> {
  const map = new Map<string, { status: 'mastered' | 'learning' | 'weak'; lockCount: number }>();

  const registerPillar = (heading: string, defaultStatus?: 'mastered' | 'learning' | 'weak') => {
    if (!heading) return;
    const explicit = theory.pillarStatuses?.[heading];
    const st = explicit?.status || defaultStatus || 'weak';
    const lc = explicit?.lockCount ?? (st === 'mastered' ? 2 : st === 'learning' ? 1 : 0);
    map.set(heading, { status: st, lockCount: lc });
  };

  if (theory.parentSections && theory.parentSections.length > 0) {
    theory.parentSections.forEach((p) => {
      (p.subSections || []).forEach((s) => registerPillar(s.heading, s.status));
    });
  } else if (theory.structuredSubSections && theory.structuredSubSections.length > 0) {
    theory.structuredSubSections.forEach((s) => registerPillar(s.heading, s.status));
  } else if (theory.lv2Outline && theory.lv2Outline.length > 0) {
    theory.lv2Outline.forEach((line) => registerPillar(line, 'weak'));
  }

  if (theory.pillarStatuses) {
    Object.entries(theory.pillarStatuses).forEach(([k, v]) => {
      if (!map.has(k) && v) {
        map.set(k, { status: v.status, lockCount: v.lockCount });
      }
    });
  }

  return map;
}

function computeStageFromMergedPillars(
  theory: TheoryItem,
  mergedPillars: Record<string, { status: 'mastered' | 'learning' | 'weak'; lockCount: number }>,
  candidateStage: number
): number {
  const canonical = getCanonicalPillarDefaults(theory);
  const headings = Array.from(canonical.keys());
  if (headings.length === 0) {
    return Math.max(1, candidateStage || 1);
  }

  let mastered = 0;
  let learning = 0;
  let weak = 0;

  headings.forEach((h) => {
    const normH = normalizePillarKey(h);
    const p = mergedPillars[h] || mergedPillars[normH] || canonical.get(h) || canonical.get(normH);
    if (p?.status === 'mastered') mastered++;
    else if (p?.status === 'learning') learning++;
    else weak++;
  });

  if (mastered === headings.length) {
    // All pillars mastered (◎): at least Lv.3, preserve Lv.4/Lv.5 if earned
    return Math.max(3, candidateStage || 3);
  }
  if (weak === 0 && mastered + learning === headings.length) {
    // All pillars at least ○, but not all ◎ -> strictly Lv.2 (never resurrect ◎ via Lv.3+)
    return 2;
  }
  // At least one ❌ weak pillar -> Lv.1
  return 1;
}

function safeSetLocalStorage(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    // Emergency quota cleanup: purge any leftover bloated keys or old snapshots and retry
    try {
      LEGACY_BLOATED_THEORY_KEYS.forEach((lk) => localStorage.removeItem(lk));
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const k = localStorage.key(i);
        if (k && k.startsWith('tax_exam_snapshot_') && k !== 'tax_exam_snapshot_latest') {
          localStorage.removeItem(k);
        }
      }
      localStorage.setItem(key, value);
    } catch (retryErr) {
      console.warn(`LocalStorage write failed for ${key}, relying on IndexedDB mirror:`, retryErr);
    }
  }
}

let hasRunStorageMigration = false;

function mergeVaultDictionaryIntoTarget(
  targetVault: Record<string, PillarVaultEntry>,
  sourceVault: any
): boolean {
  if (!sourceVault || typeof sourceVault !== 'object') return false;
  let changed = false;
  Object.entries(sourceVault).forEach(([k, val]: [string, any]) => {
    if (!val || typeof val !== 'object') return;
    if (val.updatedAt === POISON_TEST_TS) return;
    if (!isGenuineUserAction(val)) return;

    let tId = val.theoryId || '';
    let rawPKey = val.pillarKey || '';
    if (k.includes('::')) {
      const parts = k.split('::');
      if (!tId) tId = parts[0];
      if (!rawPKey) rawPKey = parts.slice(1).join('::');
    }
    if (!tId || !rawPKey) return;

    const cleanPKey = normalizePillarKey(rawPKey);
    const ts = typeof val.updatedAt === 'number' && val.updatedAt > 0 ? val.updatedAt : 1;
    const entry: PillarVaultEntry = {
      theoryId: tId,
      pillarKey: cleanPKey,
      status: val.status === 'mastered' ? 'mastered' : val.status === 'learning' ? 'learning' : 'weak',
      lockCount: val.lockCount ?? (val.status === 'mastered' ? 2 : val.status === 'learning' ? 1 : 0),
      updatedAt: ts,
      isUserAction: true,
    };

    const k1 = `${tId}::${rawPKey}`;
    const k2 = `${tId}::${cleanPKey}`;
    const ex1 = targetVault[k1];
    if (!ex1 || ts > (ex1.updatedAt || 0)) {
      targetVault[k1] = entry;
      changed = true;
    }
    const ex2 = targetVault[k2];
    if (!ex2 || ts > (ex2.updatedAt || 0)) {
      targetVault[k2] = entry;
      changed = true;
    }
  });
  return changed;
}

function rescueFromSnapshotObject(
  snap: any,
  targetVault: Record<string, PillarVaultEntry>
): { vaultChanged: boolean; rescuedSessions: StudySession[]; rescuedSubjects: SubjectInfo[] } {
  const result = {
    vaultChanged: false,
    rescuedSessions: [] as StudySession[],
    rescuedSubjects: [] as SubjectInfo[],
  };
  if (!snap || typeof snap !== 'object') return result;

  if (snap.vault && typeof snap.vault === 'object') {
    if (mergeVaultDictionaryIntoTarget(targetVault, snap.vault)) {
      result.vaultChanged = true;
    }
  }
  if (snap.pillarVault && typeof snap.pillarVault === 'object') {
    if (mergeVaultDictionaryIntoTarget(targetVault, snap.pillarVault)) {
      result.vaultChanged = true;
    }
  }
  if (Array.isArray(snap.sessions)) {
    result.rescuedSessions = snap.sessions.filter((s: any) => s && s.id);
  }
  if (Array.isArray(snap.subjects)) {
    result.rescuedSubjects = snap.subjects.filter((s: any) => s && s.id);
  }
  return result;
}

function rescueGraduatedSRSIntoVault(_targetVault: Record<string, PillarVaultEntry>): boolean {
  // Permanently disabled: Never synthesize mastered pillars automatically.
  // The user's explicit taps and canonical Notion defaults are the authoritative truth.
  return false;
}

function ensureStorageMigrated(): void {
  if (hasRunStorageMigration || typeof window === 'undefined') return;
  hasRunStorageMigration = true;

  try {
    // 1. Load & sanitize Vault v2 (strip poisoned test entry, preserve all genuine user actions)
    const existingV2Raw = localStorage.getItem(VAULT_KEY);
    const v2Vault: Record<string, PillarVaultEntry> = {};
    let vaultDirty = false;

    if (existingV2Raw) {
      try {
        const parsed = JSON.parse(existingV2Raw);
        Object.entries(parsed).forEach(([k, val]: [string, any]) => {
          if (val?.updatedAt === POISON_TEST_TS) {
            vaultDirty = true;
            return;
          }
          if (k.includes('::') && isGenuineUserAction(val)) {
            const [tId, rawPKey] = k.split('::');
            const cleanPKey = normalizePillarKey(val.pillarKey || rawPKey);
            const normalizedEntry: PillarVaultEntry = {
              theoryId: val.theoryId || tId,
              pillarKey: cleanPKey,
              status: val.status,
              lockCount: val.lockCount ?? (val.status === 'mastered' ? 2 : val.status === 'learning' ? 1 : 0),
              updatedAt: val.updatedAt || 1,
              isUserAction: true,
            };
            v2Vault[k] = normalizedEntry;
            v2Vault[`${normalizedEntry.theoryId}::${cleanPKey}`] = normalizedEntry;
          }
        });
      } catch {}
    }

    // 2. Migrate Vault v1 -> Vault v2 (accept v1 entries even if isUserAction was omitted!)
    const v1Raw = localStorage.getItem(LEGACY_VAULT_KEY);
    if (v1Raw) {
      try {
        const v1Parsed = JSON.parse(v1Raw);
        if (mergeVaultDictionaryIntoTarget(v2Vault, v1Parsed)) {
          vaultDirty = true;
        }
      } catch {}
      localStorage.removeItem(LEGACY_VAULT_KEY);
    }

    // 3. Rescue vault, sessions, and subject hours from ALL localStorage snapshots (snapshot_latest + dated snapshots)
    const snapshotSessionsPool: StudySession[] = [];
    const snapshotSubjectsPool: SubjectInfo[][] = [];

    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('tax_exam_snapshot_')) {
        try {
          const snapRaw = localStorage.getItem(k);
          if (snapRaw) {
            const snap = JSON.parse(snapRaw);
            const rescued = rescueFromSnapshotObject(snap, v2Vault);
            if (rescued.vaultChanged) vaultDirty = true;
            if (rescued.rescuedSessions.length > 0) snapshotSessionsPool.push(...rescued.rescuedSessions);
            if (rescued.rescuedSubjects.length > 0) snapshotSubjectsPool.push(rescued.rescuedSubjects);
          }
        } catch {}
      }
    }

    // Merge rescued sessions if any real sessions were found in snapshots
    if (snapshotSessionsPool.length > 0) {
      try {
        const curSesRaw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
        const curSes: StudySession[] = curSesRaw ? JSON.parse(curSesRaw) : INITIAL_STUDY_SESSIONS;
        const sesMap = new Map<string, StudySession>();
        curSes.forEach((s) => {
          if (s?.id) sesMap.set(s.id, s);
        });
        let addedSes = false;
        snapshotSessionsPool.forEach((s) => {
          if (s?.id && !sesMap.has(s.id)) {
            sesMap.set(s.id, s);
            addedSes = true;
          }
        });
        if (addedSes) {
          const mergedSes = Array.from(sesMap.values()).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
          safeSetLocalStorage(STORAGE_KEYS.SESSIONS, JSON.stringify(mergedSes));
          idbSet(STORAGE_KEYS.SESSIONS, mergedSes).catch(() => {});
        }
      } catch {}
    }

    // Merge rescued subject hours (Math.max) if snapshots had higher hours
    if (snapshotSubjectsPool.length > 0) {
      try {
        const curSubRaw = localStorage.getItem(STORAGE_KEYS.SUBJECTS);
        const curSubs: SubjectInfo[] = curSubRaw ? JSON.parse(curSubRaw) : INITIAL_SUBJECTS;
        let subUpdated = false;
        const nextSubs = curSubs.map((sub) => {
          let maxH = sub.currentHours || 0;
          snapshotSubjectsPool.forEach((pool) => {
            const match = pool.find((p) => p.id === sub.id);
            if (match && (match.currentHours || 0) > maxH) {
              maxH = match.currentHours;
            }
          });
          if (maxH > (sub.currentHours || 0)) {
            subUpdated = true;
            return { ...sub, currentHours: maxH };
          }
          return sub;
        });
        if (subUpdated) {
          safeSetLocalStorage(STORAGE_KEYS.SUBJECTS, JSON.stringify(nextSubs));
          idbSet(STORAGE_KEYS.SUBJECTS, nextSubs).catch(() => {});
        }
      } catch {}
    }

    // 4. Rescue graduated SRS theories into vault if their vault records were lost
    if (rescueGraduatedSRSIntoVault(v2Vault)) {
      vaultDirty = true;
    }

    // 5. Sanitize existing TheoryProgressDelta for poisoned test entry & rescue genuine user actions
    const existingDeltasRaw = localStorage.getItem(STORAGE_KEYS.THEORY_DELTAS);
    if (existingDeltasRaw) {
      try {
        const parsedDeltas = JSON.parse(existingDeltasRaw);
        if (Array.isArray(parsedDeltas)) {
          let deltasDirty = false;
          const initMap = new Map<string, TheoryItem>();
          INITIAL_THEORIES.forEach((it) => {
            initMap.set(it.id, it);
            initMap.set(it.theoryNumber, it);
          });

          parsedDeltas.forEach((d: TheoryProgressDelta) => {
            if (!d?.pillarStatuses) return;
            const initItem = initMap.get(d.id) || initMap.get(d.theoryNumber);
            const canonical = initItem ? getCanonicalPillarDefaults(initItem) : new Map();

            Object.entries(d.pillarStatuses).forEach(([pk, pv]: [string, any]) => {
              if (!pv) return;
              if (pv.updatedAt === POISON_TEST_TS) {
                delete d.pillarStatuses[pk];
                deltasDirty = true;
                return;
              }
              const cleanPk = normalizePillarKey(pk);
              const def = canonical.get(pk) || canonical.get(cleanPk);
              const isExplicitUser =
                pv.isUserAction === true ||
                (pv.isUserAction === undefined &&
                  ((pv.updatedAt && pv.updatedAt > 0) ||
                    ((pv.status === 'mastered' || pv.status === 'learning') &&
                      (!def || def.status !== pv.status))));

              if (isExplicitUser && d.id) {
                const ts = pv.updatedAt && pv.updatedAt > 0 ? pv.updatedAt : 1;
                const ex = v2Vault[`${d.id}::${cleanPk}`];
                if (!ex || ts > (ex.updatedAt || 0)) {
                  const vEntry: PillarVaultEntry = {
                    theoryId: d.id,
                    pillarKey: cleanPk,
                    status: pv.status,
                    lockCount: pv.lockCount ?? (pv.status === 'mastered' ? 2 : pv.status === 'learning' ? 1 : 0),
                    updatedAt: ts,
                    isUserAction: true,
                  };
                  v2Vault[`${d.id}::${pk}`] = vEntry;
                  v2Vault[`${d.id}::${cleanPk}`] = vEntry;
                  vaultDirty = true;
                }
              }
            });
          });

          if (deltasDirty) {
            safeSetLocalStorage(STORAGE_KEYS.THEORY_DELTAS, JSON.stringify(parsedDeltas));
            idbSet(STORAGE_KEYS.THEORY_DELTAS, parsedDeltas).catch(() => {});
          }
        }
      } catch {}
    }

    // 6. Migrate legacy bloated theory arrays -> compact TheoryProgressDelta
    let legacyItems: TheoryItem[] | null = null;
    for (const lk of LEGACY_BLOATED_THEORY_KEYS) {
      const raw = localStorage.getItem(lk);
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0 && !legacyItems) {
            legacyItems = parsed;
          }
        } catch {}
      }
    }

    if (legacyItems) {
      const initMap = new Map<string, TheoryItem>();
      INITIAL_THEORIES.forEach((it) => {
        initMap.set(it.id, it);
        initMap.set(it.theoryNumber, it);
      });

      const deltas: TheoryProgressDelta[] = legacyItems.map((item) => {
        const initItem = initMap.get(item.id) || initMap.get(item.theoryNumber);
        const canonicalDefaults = initItem ? getCanonicalPillarDefaults(initItem) : new Map();

        const cleanedStatuses: TheoryProgressDelta['pillarStatuses'] = {};
        if (item.pillarStatuses) {
          Object.entries(item.pillarStatuses).forEach(([pk, pv]) => {
            if (!pv || pv.updatedAt === POISON_TEST_TS) return;
            const cleanPk = normalizePillarKey(pk);
            const def = canonicalDefaults.get(pk) || canonicalDefaults.get(cleanPk);
            const isUser =
              pv.isUserAction === true ||
              (pv.isUserAction !== false &&
                ((pv.updatedAt && pv.updatedAt > 0) ||
                  ((pv.status === 'mastered' || pv.status === 'learning') &&
                    (!def || def.status !== pv.status))));

            const statEntry = {
              status: pv.status,
              lockCount: pv.lockCount ?? (pv.status === 'mastered' ? 2 : pv.status === 'learning' ? 1 : 0),
              updatedAt: isUser ? pv.updatedAt || 1 : 0,
              isUserAction: isUser,
            };
            cleanedStatuses[pk] = statEntry;
            cleanedStatuses[cleanPk] = statEntry;

            if (isUser && initItem) {
              const k1 = `${initItem.id}::${pk}`;
              const k2 = `${initItem.id}::${cleanPk}`;
              const ex1 = v2Vault[k1] || v2Vault[k2];
              const ts = statEntry.updatedAt || 1;
              if (!ex1 || ts > (ex1.updatedAt || 0)) {
                const vEntry: PillarVaultEntry = {
                  theoryId: initItem.id,
                  pillarKey: cleanPk,
                  status: pv.status,
                  lockCount: statEntry.lockCount,
                  updatedAt: ts,
                  isUserAction: true,
                };
                v2Vault[k1] = vEntry;
                v2Vault[k2] = vEntry;
                vaultDirty = true;
              }
            }
          });
        }

        const isCustom = !initItem;
        return {
          id: initItem ? initItem.id : item.id,
          theoryNumber: initItem ? initItem.theoryNumber : item.theoryNumber,
          pillarStatuses: cleanedStatuses,
          currentStage: item.currentStage || 1,
          bestScore: item.bestScore || 0,
          bestTimeSeconds: item.bestTimeSeconds || 0,
          history: item.history || [],
          lastPracticed: item.lastPracticed,
          ...(isCustom ? { isCustomTheory: true, fullCustomItem: item } : {}),
        };
      });

      if (!existingDeltasRaw || existingDeltasRaw === '[]') {
        safeSetLocalStorage(STORAGE_KEYS.THEORY_DELTAS, JSON.stringify(deltas));
        idbSet(STORAGE_KEYS.THEORY_DELTAS, deltas).catch(() => {});
      }
    }

    if (vaultDirty) {
      safeSetLocalStorage(VAULT_KEY, JSON.stringify(v2Vault));
      idbSet(VAULT_KEY, v2Vault).catch(() => {});
    }

    // Purge legacy bloated keys only after migration
    LEGACY_BLOATED_THEORY_KEYS.forEach((lk) => {
      try {
        localStorage.removeItem(lk);
      } catch {}
    });
  } catch (e) {
    console.warn('Storage migration warning:', e);
  }
}

export const StorageService = {
  // Direct Pillar Vault Access (Indexed by both raw and normalized keys for 100% collision-free recall)
  getPillarVault(): Record<string, PillarVaultEntry> {
    ensureStorageMigrated();
    try {
      const raw = localStorage.getItem(VAULT_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      const clean: Record<string, PillarVaultEntry> = {};
      Object.entries(parsed).forEach(([k, v]: [string, any]) => {
        if (!k.includes('::') || !v || v.updatedAt === POISON_TEST_TS) return;
        if (isGenuineUserAction(v)) {
          const [tId, pKey] = k.split('::');
          const normKey = normalizePillarKey(v.pillarKey || pKey);
          const normalized: PillarVaultEntry = {
            theoryId: v.theoryId || tId,
            pillarKey: normKey,
            status: v.status,
            lockCount: v.lockCount ?? (v.status === 'mastered' ? 2 : v.status === 'learning' ? 1 : 0),
            updatedAt: v.updatedAt || 1,
            isUserAction: true,
          };
          clean[k] = normalized;
          if (normKey && !clean[`${tId}::${normKey}`]) {
            clean[`${tId}::${normKey}`] = normalized;
          }
        }
      });
      return clean;
    } catch {
      return {};
    }
  },

  // Record an explicit single pillar tap by user (◎, ○, or ❌)
  // Stamped with Date.now() + isUserAction: true so intentional downgrades (◎ -> ○ / ❌) stick 100%
  recordPillarTap(
    theoryId: string,
    pillarKey: string,
    status: 'mastered' | 'learning' | 'weak',
    lockCount: number
  ): void {
    try {
      const vault = this.getPillarVault();
      const now = Date.now();
      const normKey = normalizePillarKey(pillarKey);
      const entry: PillarVaultEntry = {
        theoryId,
        pillarKey: normKey,
        status,
        lockCount,
        updatedAt: now,
        isUserAction: true,
      };
      vault[`${theoryId}::${pillarKey}`] = entry;
      vault[`${theoryId}::${normKey}`] = entry;
      safeSetLocalStorage(VAULT_KEY, JSON.stringify(vault));
      this.setLocalTimestamp(now);
      idbSet(VAULT_KEY, vault).catch(() => {});
      this.saveDailySnapshot();
    } catch (e) {
      console.warn('Failed to record pillar tap in vault:', e);
    }
  },

  // Record batch pillar updates (e.g., Lv.1-Lv.5 stage toggle rollback or AI grading)
  recordBatchPillarTaps(
    theoryId: string,
    updates: Array<{ pillarKey: string; status: 'mastered' | 'learning' | 'weak'; lockCount: number }>
  ): void {
    try {
      const vault = this.getPillarVault();
      const now = Date.now();
      updates.forEach(({ pillarKey, status, lockCount }) => {
        const normKey = normalizePillarKey(pillarKey);
        const entry: PillarVaultEntry = {
          theoryId,
          pillarKey: normKey,
          status,
          lockCount,
          updatedAt: now,
          isUserAction: true,
        };
        vault[`${theoryId}::${pillarKey}`] = entry;
        vault[`${theoryId}::${normKey}`] = entry;
      });
      safeSetLocalStorage(VAULT_KEY, JSON.stringify(vault));
      this.setLocalTimestamp(now);
      idbSet(VAULT_KEY, vault).catch(() => {});
      this.saveDailySnapshot();
    } catch (e) {
      console.warn('Failed to batch record pillar taps in vault:', e);
    }
  },

  // Compact Daily Snapshot (< 15KB) in JST
  saveDailySnapshot(): void {
    try {
      const today = getJSTDateString();
      const snapshot = {
        date: today,
        timestamp: Date.now(),
        vault: this.getPillarVault(),
        sessions: this.getSessions(),
        subjects: this.getSubjects(),
      };
      const serialized = JSON.stringify(snapshot);
      safeSetLocalStorage('tax_exam_snapshot_latest', serialized);
      idbSet('tax_exam_snapshot_latest', snapshot).catch(() => {});

      // Keep only today's dated snapshot and prune older dated snapshots to keep localStorage ultra-lean
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const k = localStorage.key(i);
        if (k && k.startsWith('tax_exam_snapshot_') && k !== 'tax_exam_snapshot_latest' && k !== `tax_exam_snapshot_${today}`) {
          localStorage.removeItem(k);
        }
      }
      safeSetLocalStorage(`tax_exam_snapshot_${today}`, serialized);
    } catch {}
  },

  // Hydrate from IndexedDB on app boot (rescues data from ALL IDB keys & snapshots if localStorage was wiped/overwritten)
  async hydrateFromIndexedDB(): Promise<boolean> {
    ensureStorageMigrated();
    let restoredAnything = false;

    try {
      const idbAll = await idbGetAll();
      const localVault = this.getPillarVault();
      let vaultChanged = false;

      // 1. Merge Vault from IDB (v2, v1, and all snapshots stored in IDB!)
      if (idbAll[VAULT_KEY] && mergeVaultDictionaryIntoTarget(localVault, idbAll[VAULT_KEY])) {
        vaultChanged = true;
      }
      if (idbAll[LEGACY_VAULT_KEY] && mergeVaultDictionaryIntoTarget(localVault, idbAll[LEGACY_VAULT_KEY])) {
        vaultChanged = true;
      }

      const idbSnapshotSessions: StudySession[] = [];
      const idbSnapshotSubjects: SubjectInfo[][] = [];

      Object.entries(idbAll).forEach(([idbKey, idbVal]) => {
        if (idbKey.startsWith('tax_exam_snapshot_') && idbVal && typeof idbVal === 'object') {
          const rescued = rescueFromSnapshotObject(idbVal, localVault);
          if (rescued.vaultChanged) vaultChanged = true;
          if (rescued.rescuedSessions.length > 0) idbSnapshotSessions.push(...rescued.rescuedSessions);
          if (rescued.rescuedSubjects.length > 0) idbSnapshotSubjects.push(rescued.rescuedSubjects);
        }
      });

      // 2. Restore DailyMenuState (including SRS records) first so SRS graduation rescue can also inspect it
      const idbDaily = idbAll['tax_exam_daily_menu_mirror'] as Record<string, string> | undefined;
      if (idbDaily && typeof idbDaily === 'object') {
        const currentDaily = this.getDailyMenuState();
        let dailyRestored = false;
        Object.entries(idbDaily).forEach(([dk, dv]) => {
          if (!currentDaily[dk] && typeof dv === 'string') {
            safeSetLocalStorage(dk, dv);
            dailyRestored = true;
          }
        });
        if (dailyRestored) restoredAnything = true;
      }

      // Check SRS rescue again after IDB daily mirror restoration
      if (rescueGraduatedSRSIntoVault(localVault)) {
        vaultChanged = true;
      }

      // 3. Rescue any genuine user pillar evaluations from IDB theory deltas or legacy IDB theory keys
      const idbDeltas = idbAll[STORAGE_KEYS.THEORY_DELTAS] as TheoryProgressDelta[] | undefined;
      if (Array.isArray(idbDeltas) && idbDeltas.length > 0) {
        const initMap = new Map<string, TheoryItem>();
        INITIAL_THEORIES.forEach((it) => {
          initMap.set(it.id, it);
          initMap.set(it.theoryNumber, it);
        });

        idbDeltas.forEach((d) => {
          if (!d?.pillarStatuses || !d.id) return;
          const initItem = initMap.get(d.id) || initMap.get(d.theoryNumber);
          const canonical = initItem ? getCanonicalPillarDefaults(initItem) : new Map();
          Object.entries(d.pillarStatuses).forEach(([pk, pv]: [string, any]) => {
            if (!pv || pv.updatedAt === POISON_TEST_TS) return;
            const cleanPk = normalizePillarKey(pk);
            const def = canonical.get(pk) || canonical.get(cleanPk);
            const isExplicitUser =
              pv.isUserAction === true ||
              (pv.isUserAction === undefined &&
                ((pv.updatedAt && pv.updatedAt > 0) ||
                  ((pv.status === 'mastered' || pv.status === 'learning') &&
                    (!def || def.status !== pv.status))));
            if (isExplicitUser) {
              const ts = pv.updatedAt && pv.updatedAt > 0 ? pv.updatedAt : 1;
              const ex = localVault[`${d.id}::${cleanPk}`];
              if (!ex || ts > (ex.updatedAt || 0)) {
                const entry: PillarVaultEntry = {
                  theoryId: d.id,
                  pillarKey: cleanPk,
                  status: pv.status,
                  lockCount: pv.lockCount ?? (pv.status === 'mastered' ? 2 : pv.status === 'learning' ? 1 : 0),
                  updatedAt: ts,
                  isUserAction: true,
                };
                localVault[`${d.id}::${pk}`] = entry;
                localVault[`${d.id}::${cleanPk}`] = entry;
                vaultChanged = true;
              }
            }
          });
        });

        const localDeltasRaw = localStorage.getItem(STORAGE_KEYS.THEORY_DELTAS);
        if (!localDeltasRaw || localDeltasRaw === '[]') {
          safeSetLocalStorage(STORAGE_KEYS.THEORY_DELTAS, JSON.stringify(idbDeltas));
          restoredAnything = true;
        }
      }

      if (vaultChanged) {
        safeSetLocalStorage(VAULT_KEY, JSON.stringify(localVault));
        await idbSet(VAULT_KEY, localVault);
        restoredAnything = true;
      } else if (Object.keys(localVault).length > 0) {
        await idbSet(VAULT_KEY, localVault);
      }

      // 4. Union-Merge Sessions from IDB + IDB Snapshots by ID
      const idbSessions = Array.isArray(idbAll[STORAGE_KEYS.SESSIONS])
        ? (idbAll[STORAGE_KEYS.SESSIONS] as StudySession[])
        : [];
      const combinedCandidateSessions = [...idbSessions, ...idbSnapshotSessions];
      if (combinedCandidateSessions.length > 0) {
        const localSessions = this.getSessions();
        const sessionMap = new Map<string, StudySession>();
        localSessions.forEach((s) => {
          if (s?.id) sessionMap.set(s.id, s);
        });
        let addedSession = false;
        combinedCandidateSessions.forEach((s) => {
          if (s?.id && !sessionMap.has(s.id)) {
            sessionMap.set(s.id, s);
            addedSession = true;
          }
        });
        if (addedSession) {
          const merged = Array.from(sessionMap.values()).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
          safeSetLocalStorage(STORAGE_KEYS.SESSIONS, JSON.stringify(merged));
          await idbSet(STORAGE_KEYS.SESSIONS, merged);
          restoredAnything = true;
        }
      }

      // 5. Merge Subjects by Math.max of currentHours across localStorage, IDB, IDB snapshots, and sessions!
      const idbSubs = Array.isArray(idbAll[STORAGE_KEYS.SUBJECTS])
        ? (idbAll[STORAGE_KEYS.SUBJECTS] as SubjectInfo[])
        : [];
      const allSubPools: SubjectInfo[][] = [];
      if (idbSubs.length > 0) allSubPools.push(idbSubs);
      if (idbSnapshotSubjects.length > 0) allSubPools.push(...idbSnapshotSubjects);

      if (allSubPools.length > 0) {
        const localSubs = this.getSubjects();
        let subsChanged = false;
        const mergedSubs = localSubs.map((sub) => {
          let maxHours = sub.currentHours || 0;
          allSubPools.forEach((pool) => {
            const m = pool.find((p) => p?.id === sub.id);
            if (m && (m.currentHours || 0) > maxHours) {
              maxHours = m.currentHours;
            }
          });
          if (maxHours > (sub.currentHours || 0)) {
            subsChanged = true;
            return { ...sub, currentHours: maxHours };
          }
          return sub;
        });
        if (subsChanged) {
          safeSetLocalStorage(STORAGE_KEYS.SUBJECTS, JSON.stringify(mergedSubs));
          await idbSet(STORAGE_KEYS.SUBJECTS, mergedSubs);
          restoredAnything = true;
        }
      }

      // 6. Restore Calculations, AnkiCards, Milestones if missing
      const keysToCheck = [
        STORAGE_KEYS.CALCULATIONS,
        STORAGE_KEYS.ANKI_CARDS,
        STORAGE_KEYS.MILESTONES,
      ];
      for (const k of keysToCheck) {
        const locRaw = localStorage.getItem(k);
        const idbVal = idbAll[k];
        if (!locRaw && idbVal) {
          safeSetLocalStorage(k, JSON.stringify(idbVal));
          restoredAnything = true;
        }
      }
    } catch (e) {
      console.warn('IndexedDB hydration warning:', e);
    }

    return restoredAnything;
  },

  getSubjects(): SubjectInfo[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SUBJECTS);
      const subjects: SubjectInfo[] = data ? JSON.parse(data) : INITIAL_SUBJECTS;
      // Guarantee hours are never lower than recorded sessions
      const sessions = this.getSessions();
      return subjects.map((sub) => {
        const mins = sessions
          .filter((s) => s.subjectId === sub.id && s.minutes > 0)
          .reduce((sum, s) => sum + s.minutes, 0);
        const sessionHours = Math.round((mins / 60) * 10) / 10;
        return {
          ...sub,
          currentHours: Math.max(sub.currentHours || 0, sessionHours),
        };
      });
    } catch {
      return INITIAL_SUBJECTS;
    }
  },

  saveSubjects(subjects: SubjectInfo[]) {
    safeSetLocalStorage(STORAGE_KEYS.SUBJECTS, JSON.stringify(subjects));
    idbSet(STORAGE_KEYS.SUBJECTS, subjects).catch(() => {});
  },

  getTheoryDeltas(): TheoryProgressDelta[] {
    ensureStorageMigrated();
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.THEORY_DELTAS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  },

  getTheories(): TheoryItem[] {
    ensureStorageMigrated();
    try {
      const storedDeltas = this.getTheoryDeltas();
      const storedMap = new Map<string, TheoryProgressDelta>();
      const customTheories: TheoryItem[] = [];

      for (const delta of storedDeltas) {
        if (delta.id) storedMap.set(delta.id, delta);
        if (delta.theoryNumber) storedMap.set(delta.theoryNumber, delta);
        if (delta.isCustomTheory && delta.fullCustomItem) {
          customTheories.push(delta.fullCustomItem);
        }
      }

      // Automatic Migration: propagate any legacy 3-4 progress to 3-4A and 3-4B
      const old34 = storedMap.get('res-th-3-4') || storedMap.get('3-4');
      if (old34 && old34.pillarStatuses) {
        if (!storedMap.has('res-th-3-4a') && !storedMap.has('3-4A')) {
          storedMap.set('res-th-3-4a', {
            ...old34,
            id: 'res-th-3-4a',
            theoryNumber: '3-4A',
            pillarStatuses: { ...old34.pillarStatuses },
          });
        }
        if (!storedMap.has('res-th-3-4b') && !storedMap.has('3-4B')) {
          storedMap.set('res-th-3-4b', {
            ...old34,
            id: 'res-th-3-4b',
            theoryNumber: '3-4B',
            pillarStatuses: { ...old34.pillarStatuses },
          });
        }
      }

      const vault = this.getPillarVault();

      const mergedTheories: TheoryItem[] = INITIAL_THEORIES.map((initTheory) => {
        const stored = storedMap.get(initTheory.id) || storedMap.get(initTheory.theoryNumber);
        const canonicalDefaults = getCanonicalPillarDefaults(initTheory);

        const allPillarKeys = new Set<string>([
          ...Array.from(canonicalDefaults.keys()),
          ...(stored?.pillarStatuses ? Object.keys(stored.pillarStatuses) : []),
        ]);

        Object.keys(vault).forEach((vKey) => {
          if (vKey.startsWith(`${initTheory.id}::`)) {
            allPillarKeys.add(vKey.slice(`${initTheory.id}::`.length));
          }
        });

        const mergedPillars: Record<
          string,
          { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }
        > = {};

        allPillarKeys.forEach((key) => {
          const normKey = normalizePillarKey(key);
          const storedP = stored?.pillarStatuses?.[key] || stored?.pillarStatuses?.[normKey];
          const vEntry = vault[`${initTheory.id}::${key}`] || vault[`${initTheory.id}::${normKey}`];
          const def = canonicalDefaults.get(key) || canonicalDefaults.get(normKey) || { status: 'weak', lockCount: 0 };

          const storedIsUser = Boolean(
            storedP &&
              storedP.updatedAt !== POISON_TEST_TS &&
              (storedP.isUserAction === true ||
                (storedP.isUserAction !== false &&
                  ((storedP.updatedAt && storedP.updatedAt > 0) ||
                    def.status !== storedP.status)))
          );
          const vIsUser = Boolean(vEntry && vEntry.updatedAt !== POISON_TEST_TS && isGenuineUserAction(vEntry));

          let chosen: { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean };

          if (vIsUser && storedIsUser && storedP) {
            // Both sides have explicit user evaluation: newer timestamp wins (even if 'weak' ❌ downgrade!)
            const vTime = vEntry.updatedAt || 0;
            const sTime = storedP.updatedAt || 0;
            if (sTime > vTime) {
              chosen = {
                status: storedP.status,
                lockCount: storedP.lockCount ?? (storedP.status === 'mastered' ? 2 : storedP.status === 'learning' ? 1 : 0),
                updatedAt: sTime,
                isUserAction: true,
              };
            } else {
              chosen = {
                status: vEntry.status,
                lockCount: vEntry.lockCount,
                updatedAt: vTime,
                isUserAction: true,
              };
            }
          } else if (vIsUser) {
            chosen = {
              status: vEntry.status,
              lockCount: vEntry.lockCount,
              updatedAt: vEntry.updatedAt,
              isUserAction: true,
            };
          } else if (storedIsUser && storedP) {
            chosen = {
              status: storedP.status,
              lockCount: storedP.lockCount ?? (storedP.status === 'mastered' ? 2 : storedP.status === 'learning' ? 1 : 0),
              updatedAt: storedP.updatedAt || 1,
              isUserAction: true,
            };
          } else {
            // Un-evaluated by user: fall back to canonical Notion baseline default with isUserAction: false
            // Any future user tap (including ◎ -> ○ / ❌ downgrade) sets isUserAction: true and permanently overrides this!
            chosen = {
              status: def.status,
              lockCount: def.lockCount,
              updatedAt: 0,
              isUserAction: false,
            };
          }

          mergedPillars[key] = chosen;
          mergedPillars[normKey] = chosen;

          // Backfill genuine user actions into vault so vault always holds the immortal user truth
          if (chosen.isUserAction && (!vEntry || (chosen.updatedAt || 0) > (vEntry.updatedAt || 0))) {
            vault[`${initTheory.id}::${key}`] = {
              theoryId: initTheory.id,
              pillarKey: normKey,
              status: chosen.status,
              lockCount: chosen.lockCount,
              updatedAt: chosen.updatedAt || Date.now(),
              isUserAction: true,
            };
            vault[`${initTheory.id}::${normKey}`] = vault[`${initTheory.id}::${key}`];
          }
        });

        const rawStage = stored?.currentStage || initTheory.currentStage || 1;
        const currentStage = computeStageFromMergedPillars(initTheory, mergedPillars, rawStage);

        const bestScore =
          typeof stored?.bestScore === 'number'
            ? Math.max(stored.bestScore, initTheory.bestScore || 0)
            : initTheory.bestScore || 0;
        const bestTimeSeconds =
          typeof stored?.bestTimeSeconds === 'number' && stored.bestTimeSeconds > 0
            ? stored.bestTimeSeconds
            : initTheory.bestTimeSeconds || 0;
        const history =
          stored?.history && stored.history.length > 0 ? stored.history : initTheory.history || [];
        const lastPracticed = stored?.lastPracticed || initTheory.lastPracticed;

        return {
          ...initTheory,
          pillarStatuses: mergedPillars,
          currentStage,
          bestScore,
          bestTimeSeconds,
          history,
          lastPracticed,
        };
      });

      return [...customTheories, ...mergedTheories];
    } catch (e) {
      console.warn('Error reading theories from storage, falling back to initial:', e);
      return INITIAL_THEORIES;
    }
  },

  saveTheories(theories: TheoryItem[]) {
    ensureStorageMigrated();
    try {
      const initIds = new Set(INITIAL_THEORIES.map((t) => t.id));
      const deltas: TheoryProgressDelta[] = theories.map((t) => {
        const isCustom = !initIds.has(t.id);
        return {
          id: t.id,
          theoryNumber: t.theoryNumber,
          pillarStatuses: t.pillarStatuses || {},
          currentStage: t.currentStage || 1,
          bestScore: t.bestScore || 0,
          bestTimeSeconds: t.bestTimeSeconds || 0,
          history: t.history || [],
          lastPracticed: t.lastPracticed,
          ...(isCustom ? { isCustomTheory: true, fullCustomItem: t } : {}),
        };
      });

      safeSetLocalStorage(STORAGE_KEYS.THEORY_DELTAS, JSON.stringify(deltas));
      idbSet(STORAGE_KEYS.THEORY_DELTAS, deltas).catch(() => {});

      // Sync ONLY genuine user actions (including intentional weak/❌ downgrades!) to Vault
      const vault = this.getPillarVault();
      let vaultChanged = false;
      theories.forEach((t) => {
        if (!t.pillarStatuses) return;
        Object.entries(t.pillarStatuses).forEach(([k, v]) => {
          if (v && v.isUserAction === true && v.updatedAt !== POISON_TEST_TS) {
            const normK = normalizePillarKey(k);
            const vaultKey = `${t.id}::${k}`;
            const existing = vault[vaultKey];
            const vTime = v.updatedAt || 0;
            const exTime = existing?.updatedAt || 0;
            if (!existing || vTime > exTime || (vTime === exTime && existing.status !== v.status)) {
              const entry: PillarVaultEntry = {
                theoryId: t.id,
                pillarKey: normK,
                status: v.status,
                lockCount: v.lockCount,
                updatedAt: vTime || Date.now(),
                isUserAction: true,
              };
              vault[vaultKey] = entry;
              vault[`${t.id}::${normK}`] = entry;
              vaultChanged = true;
            }
          }
        });
      });

      if (vaultChanged) {
        safeSetLocalStorage(VAULT_KEY, JSON.stringify(vault));
        idbSet(VAULT_KEY, vault).catch(() => {});
      }
    } catch (e) {
      console.error('Failed to save theory deltas:', e);
    }
  },

  getCalculations(): CalculationItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CALCULATIONS);
      return data ? JSON.parse(data) : INITIAL_CALCULATIONS;
    } catch {
      return INITIAL_CALCULATIONS;
    }
  },
  saveCalculations(calcs: CalculationItem[]) {
    safeSetLocalStorage(STORAGE_KEYS.CALCULATIONS, JSON.stringify(calcs));
    idbSet(STORAGE_KEYS.CALCULATIONS, calcs).catch(() => {});
  },

  getAnkiCards(): AnkiCard[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ANKI_CARDS);
      return data ? JSON.parse(data) : INITIAL_ANKI_CARDS;
    } catch {
      return INITIAL_ANKI_CARDS;
    }
  },
  saveAnkiCards(cards: AnkiCard[]) {
    safeSetLocalStorage(STORAGE_KEYS.ANKI_CARDS, JSON.stringify(cards));
    idbSet(STORAGE_KEYS.ANKI_CARDS, cards).catch(() => {});
  },

  getSessions(): StudySession[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SESSIONS);
      return data ? JSON.parse(data) : INITIAL_STUDY_SESSIONS;
    } catch {
      return INITIAL_STUDY_SESSIONS;
    }
  },
  saveSessions(sessions: StudySession[]) {
    safeSetLocalStorage(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    idbSet(STORAGE_KEYS.SESSIONS, sessions).catch(() => {});
  },

  getChatMessages(): TrainerMessage[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHAT_MESSAGES);
      if (data) return JSON.parse(data);
      return [
        {
          id: 'welcome',
          role: 'assistant',
          content: `お疲れ様！今日から2027年合格に向けた本格始動だ。
住民税2年分の悔しさは、今日からの「前回の自分を超える」トレーニングで必ず晴らす。
何から始める？
① 住民税の理論（均等割の非課税限度額など）の5段階特訓
② 計算スピード測定（所得控除・税額控除のタイムアタック）
③ NotebookLMのノート貼り付け＆AI分解
何でも言ってくれ。甘えは一切許さないが、一歩でも前進したときは全力で称えるぞ！🔥`,
          timestamp: new Date().toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' }),
        },
      ];
    } catch {
      return [];
    }
  },
  saveChatMessages(messages: TrainerMessage[]) {
    safeSetLocalStorage(STORAGE_KEYS.CHAT_MESSAGES, JSON.stringify(messages));
  },

  getMilestones(): MonthlyMilestone[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MILESTONES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return INITIAL_MILESTONES;
    } catch {
      return INITIAL_MILESTONES;
    }
  },
  saveMilestones(milestones: MonthlyMilestone[]) {
    safeSetLocalStorage(STORAGE_KEYS.MILESTONES, JSON.stringify(milestones));
    idbSet(STORAGE_KEYS.MILESTONES, milestones).catch(() => {});
  },

  // Anki Spaced Repetition (SRS) data for mastered/graduated theories
  getTheorySRSData(subjectId: SubjectId): Record<string, TheorySRSData> {
    try {
      const key = `tax_exam_notion_srs_${subjectId}`;
      const raw = localStorage.getItem(key);
      const data: Record<string, TheorySRSData> = raw ? JSON.parse(raw) : {};

      if (subjectId === 'resident' && data['res-th-3-4']) {
        if (!data['res-th-3-4a']) {
          data['res-th-3-4a'] = { ...data['res-th-3-4'], theoryId: 'res-th-3-4a' };
        }
        if (!data['res-th-3-4b']) {
          data['res-th-3-4b'] = { ...data['res-th-3-4'], theoryId: 'res-th-3-4b' };
        }
      }

      return data;
    } catch {
      return {};
    }
  },
  saveTheorySRSData(subjectId: SubjectId, data: Record<string, TheorySRSData>) {
    try {
      const key = `tax_exam_notion_srs_${subjectId}`;
      safeSetLocalStorage(key, JSON.stringify(data));
      this.setLocalTimestamp(Date.now());
      idbSet('tax_exam_daily_menu_mirror', this.getDailyMenuState()).catch(() => {});
      setTimeout(() => {
        StorageService.pushToServer().catch(() => {});
      }, 400);
    } catch {}
  },

  // Daily Menu State (PC ↔ Smartphone real-time sync for completed questions, SRS & quotas)
  getDailyMenuState(): Record<string, string> {
    const dailyState: Record<string, string> = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (
          key &&
          (key.startsWith('tax_exam_drill_') ||
            key.startsWith('tax_exam_notion_') ||
            key.startsWith('tax_exam_toggle_'))
        ) {
          const val = localStorage.getItem(key);
          if (val !== null) {
            dailyState[key] = val;
          }
        }
      }
    } catch (e) {
      console.warn('Could not read daily menu keys:', e);
    }
    return dailyState;
  },

  saveDailyMenuState(dailyState: Record<string, string>) {
    try {
      if (!dailyState || typeof dailyState !== 'object') return;
      Object.entries(dailyState).forEach(([key, val]) => {
        if (!key || typeof val !== 'string') return;

        // Merge SRS dictionaries per theoryId by latest lastReviewedDate
        if (key.startsWith('tax_exam_notion_srs_')) {
          try {
            const existingRaw = localStorage.getItem(key);
            if (existingRaw) {
              const pEx: Record<string, TheorySRSData> = JSON.parse(existingRaw);
              const pIn: Record<string, TheorySRSData> = JSON.parse(val);
              const mergedSrs: Record<string, TheorySRSData> = { ...pEx };
              Object.entries(pIn).forEach(([tId, inSrs]) => {
                const exSrs = mergedSrs[tId];
                if (!exSrs || (inSrs.lastReviewedDate || '') >= (exSrs.lastReviewedDate || '')) {
                  mergedSrs[tId] = inSrs;
                }
              });
              safeSetLocalStorage(key, JSON.stringify(mergedSrs));
              return;
            }
          } catch {}
        }

        // Merge completed items/theories additively
        if (key.includes('completed_items') || key.includes('completed_theories')) {
          try {
            const existing = localStorage.getItem(key);
            if (existing) {
              const parsedExisting = JSON.parse(existing);
              const parsedIncoming = JSON.parse(val);
              const merged = { ...parsedExisting, ...parsedIncoming };
              safeSetLocalStorage(key, JSON.stringify(merged));
              return;
            }
          } catch {}
        }

        if (key.includes('_done_')) {
          const existing = localStorage.getItem(key);
          if (existing === 'true' || val === 'true') {
            safeSetLocalStorage(key, 'true');
            return;
          }
        }

        safeSetLocalStorage(key, val);
      });
      idbSet('tax_exam_daily_menu_mirror', this.getDailyMenuState()).catch(() => {});
    } catch (e) {
      console.warn('Could not save daily menu keys:', e);
    }
  },

  // Export all application state as a JSON file
  exportBackup(): string {
    const backup = {
      timestamp: new Date().toISOString(),
      pillarVault: this.getPillarVault(),
      subjects: this.getSubjects(),
      theories: this.getTheories(),
      calculations: this.getCalculations(),
      ankiCards: this.getAnkiCards(),
      sessions: this.getSessions(),
      chatMessages: this.getChatMessages(),
      milestones: this.getMilestones(),
      dailyMenuState: this.getDailyMenuState(),
    };
    return JSON.stringify(backup, null, 2);
  },

  // Restore / Union-Merge application state (Safe against ephemeral server container resets!)
  importBackup(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (!data || typeof data !== 'object') return false;

      // 1. Merge PillarVault first by `${theoryId}::${pillarKey}` and `updatedAt`
      const currentVault = this.getPillarVault();
      if (data.pillarVault && typeof data.pillarVault === 'object') {
        if (mergeVaultDictionaryIntoTarget(currentVault, data.pillarVault)) {
          safeSetLocalStorage(VAULT_KEY, JSON.stringify(currentVault));
          idbSet(VAULT_KEY, currentVault).catch(() => {});
        }
      }

      // 2. Union-merge Sessions by ID (never wipe local study sessions!)
      let mergedSessions = this.getSessions();
      if (Array.isArray(data.sessions)) {
        const sessionMap = new Map<string, StudySession>();
        mergedSessions.forEach((s) => {
          if (s?.id) sessionMap.set(s.id, s);
        });
        (data.sessions as StudySession[]).forEach((s) => {
          if (s?.id && !sessionMap.has(s.id)) {
            sessionMap.set(s.id, s);
          }
        });
        mergedSessions = Array.from(sessionMap.values()).sort((a, b) => b.date.localeCompare(a.date));
        this.saveSessions(mergedSessions);
      }

      // 3. Merge Subjects & recompute hours from mergedSessions so hours never reset to 0
      if (Array.isArray(data.subjects)) {
        const localSubs = this.getSubjects();
        const incSubMap = new Map<string, SubjectInfo>();
        (data.subjects as SubjectInfo[]).forEach((s) => {
          if (s?.id) incSubMap.set(s.id, s);
        });
        const mergedSubs = localSubs.map((locSub) => {
          const incSub = incSubMap.get(locSub.id);
          const sessionMinutes = mergedSessions
            .filter((ses) => ses.subjectId === locSub.id && ses.minutes > 0)
            .reduce((acc, ses) => acc + ses.minutes, 0);
          const computedHours = Math.round((sessionMinutes / 60) * 10) / 10;
          return {
            ...locSub,
            ...(incSub || {}),
            targetHours: incSub?.targetHours || locSub.targetHours,
            currentHours: Math.max(locSub.currentHours || 0, incSub?.currentHours || 0, computedHours),
          };
        });
        this.saveSubjects(mergedSubs);
      }

      // 4. Merge Theories & Pillar Statuses (Timestamp + isUserAction strictly respected)
      if (Array.isArray(data.theories)) {
        const existingTheories = this.getTheories();
        const existingMap = new Map<string, TheoryItem>();
        for (const t of existingTheories) {
          if (t.id) existingMap.set(t.id, t);
          if (t.theoryNumber) existingMap.set(t.theoryNumber, t);
        }

        const incomingMap = new Map<string, any>();
        const customIncoming: TheoryItem[] = [];
        const initIds = new Set(INITIAL_THEORIES.map((t) => t.id));
        const initNums = new Set(INITIAL_THEORIES.map((t) => t.theoryNumber));

        for (const t of data.theories) {
          if (t.id) incomingMap.set(t.id, t);
          if (t.theoryNumber) incomingMap.set(t.theoryNumber, t);
          if (t.id && !initIds.has(t.id) && (!t.theoryNumber || !initNums.has(t.theoryNumber))) {
            if (t.fullCustomItem) customIncoming.push(t.fullCustomItem);
            else if (t.title && t.lv4FullText !== undefined) customIncoming.push(t as TheoryItem);
          }
        }

        const vault = this.getPillarVault();

        const mergedStandardTheories = INITIAL_THEORIES.map((initTheory) => {
          const local = existingMap.get(initTheory.id) || existingMap.get(initTheory.theoryNumber);
          const incoming = incomingMap.get(initTheory.id) || incomingMap.get(initTheory.theoryNumber);
          const canonicalDefaults = getCanonicalPillarDefaults(initTheory);

          const allPillars = new Set<string>([
            ...Array.from(canonicalDefaults.keys()),
            ...Object.keys(incoming?.pillarStatuses || {}),
            ...Object.keys(local?.pillarStatuses || {}),
          ]);

          Object.keys(vault).forEach((vKey) => {
            if (vKey.startsWith(`${initTheory.id}::`)) {
              allPillars.add(vKey.slice(`${initTheory.id}::`.length));
            }
          });

          const mergedStatuses: Record<
            string,
            { status: 'mastered' | 'learning' | 'weak'; lockCount: number; updatedAt?: number; isUserAction?: boolean }
          > = {};

          allPillars.forEach((key) => {
            const normKey = normalizePillarKey(key);
            const loc = local?.pillarStatuses?.[key] || local?.pillarStatuses?.[normKey];
            const inc = incoming?.pillarStatuses?.[key] || incoming?.pillarStatuses?.[normKey];
            const vEntry = vault[`${initTheory.id}::${key}`] || vault[`${initTheory.id}::${normKey}`];
            const def = canonicalDefaults.get(key) || canonicalDefaults.get(normKey) || { status: 'weak', lockCount: 0 };

            const locExplicitUser = Boolean(
              (vEntry && vEntry.updatedAt !== POISON_TEST_TS && isGenuineUserAction(vEntry)) ||
                (loc &&
                  loc.updatedAt !== POISON_TEST_TS &&
                  (loc.isUserAction === true ||
                    (loc.isUserAction !== false &&
                      ((loc.updatedAt && loc.updatedAt > 0) ||
                        def.status !== loc.status))))
            );
            const locCandidate =
              vEntry &&
              isGenuineUserAction(vEntry) &&
              (!loc?.isUserAction || (vEntry.updatedAt || 0) >= (loc?.updatedAt || 0))
                ? vEntry
                : loc;
            const locTime = locCandidate?.updatedAt || (locExplicitUser ? 1 : 0);

            const incExplicitUser = Boolean(
              inc &&
                inc.updatedAt !== POISON_TEST_TS &&
                (inc.isUserAction === true ||
                  (inc.isUserAction !== false &&
                    ((inc.updatedAt && inc.updatedAt > 0) ||
                      def.status !== inc.status)))
            );
            const incTime = inc?.updatedAt || (incExplicitUser ? 1 : 0);

            let chosen: any;
            let finalIsUser = false;

            if (locExplicitUser && incExplicitUser) {
              // Both have explicit user actions: strictly newer timestamp wins (even if status is 'weak' ❌!)
              chosen = locTime >= incTime ? locCandidate : inc;
              finalIsUser = true;
            } else if (locExplicitUser && !incExplicitUser) {
              chosen = locCandidate;
              finalIsUser = true;
            } else if (!locExplicitUser && incExplicitUser) {
              chosen = inc;
              finalIsUser = true;
            } else {
              // Neither side has explicit user action -> preserve canonical Notion baseline default (isUserAction: false)
              chosen = { status: def.status, lockCount: def.lockCount, updatedAt: 0, isUserAction: false };
              finalIsUser = false;
            }

            const entryResult = {
              status: chosen?.status || def.status || 'weak',
              lockCount:
                chosen?.lockCount ??
                (chosen?.status === 'mastered' ? 2 : chosen?.status === 'learning' ? 1 : 0),
              updatedAt: finalIsUser ? chosen?.updatedAt || Math.max(locTime, incTime, 1) : 0,
              isUserAction: finalIsUser,
            };
            mergedStatuses[key] = entryResult;
            mergedStatuses[normKey] = entryResult;

            if (finalIsUser) {
              vault[`${initTheory.id}::${key}`] = {
                theoryId: initTheory.id,
                pillarKey: normKey,
                status: entryResult.status,
                lockCount: entryResult.lockCount,
                updatedAt: entryResult.updatedAt,
                isUserAction: true,
              };
              vault[`${initTheory.id}::${normKey}`] = vault[`${initTheory.id}::${key}`];
            }
          });

          // Merge practice history logs by id
          const historyMap = new Map<string, TheoryPracticeLog>();
          (local?.history || []).forEach((h) => {
            if (h?.id) historyMap.set(h.id, h);
          });
          (incoming?.history || []).forEach((h: TheoryPracticeLog) => {
            if (h?.id && !historyMap.has(h.id)) historyMap.set(h.id, h);
          });
          const mergedHistory = Array.from(historyMap.values());

          const localTime = local?.bestTimeSeconds || 0;
          const incomingTime = incoming?.bestTimeSeconds || 0;

          // Candidate stage respects whichever side has newer user activity, then recomputed from pillars
          const candidateStage = Math.max(local?.currentStage || 1, incoming?.currentStage || 1);
          const accurateStage = computeStageFromMergedPillars(initTheory, mergedStatuses, candidateStage);

          return {
            ...initTheory,
            pillarStatuses: mergedStatuses,
            currentStage: accurateStage,
            bestScore: Math.max(initTheory.bestScore || 0, incoming?.bestScore || 0, local?.bestScore || 0),
            bestTimeSeconds:
              localTime > 0 && incomingTime > 0
                ? Math.min(incomingTime, localTime)
                : localTime || incomingTime || initTheory.bestTimeSeconds || 0,
            history: mergedHistory.length > 0 ? mergedHistory : initTheory.history || [],
            lastPracticed:
              (incoming?.lastPracticed || '') >= (local?.lastPracticed || '')
                ? incoming?.lastPracticed || local?.lastPracticed || initTheory.lastPracticed
                : local?.lastPracticed || initTheory.lastPracticed,
          };
        });

        // Preserve any custom theories from local + incoming
        const customMap = new Map<string, TheoryItem>();
        existingTheories
          .filter((t) => !initIds.has(t.id))
          .forEach((t) => customMap.set(t.id, t));
        customIncoming.forEach((t) => {
          if (!customMap.has(t.id)) customMap.set(t.id, t);
        });

        this.saveTheories([...Array.from(customMap.values()), ...mergedStandardTheories]);
      }

      // 5. Union-merge Calculations & their logs
      if (Array.isArray(data.calculations)) {
        const localCalcs = this.getCalculations();
        const calcMap = new Map<string, CalculationItem>();
        localCalcs.forEach((c) => calcMap.set(c.id, c));

        (data.calculations as CalculationItem[]).forEach((incC) => {
          if (!incC?.id) return;
          const locC = calcMap.get(incC.id);
          if (!locC) {
            calcMap.set(incC.id, incC);
            return;
          }
          const logMap = new Map<string, CalculationLog>();
          (locC.logs || []).forEach((l) => {
            if (l?.id) logMap.set(l.id, l);
          });
          (incC.logs || []).forEach((l) => {
            if (l?.id && !logMap.has(l.id)) logMap.set(l.id, l);
          });
          const mergedLogs = Array.from(logMap.values());
          const bestTimes = [locC.bestTimeSeconds, incC.bestTimeSeconds].filter((t) => t && t > 0);
          calcMap.set(incC.id, {
            ...locC,
            ...incC,
            bestTimeSeconds: bestTimes.length > 0 ? Math.min(...bestTimes) : 0,
            consecutiveCorrect: Math.max(locC.consecutiveCorrect || 0, incC.consecutiveCorrect || 0),
            logs: mergedLogs,
          });
        });
        this.saveCalculations(Array.from(calcMap.values()));
      }

      // 6. Union-merge AnkiCards
      if (Array.isArray(data.ankiCards)) {
        const localCards = this.getAnkiCards();
        const cardMap = new Map<string, AnkiCard>();
        localCards.forEach((c) => cardMap.set(c.id, c));
        (data.ankiCards as AnkiCard[]).forEach((incCard) => {
          if (!incCard?.id) return;
          const locCard = cardMap.get(incCard.id);
          if (!locCard || (incCard.repetitions || 0) > (locCard.repetitions || 0)) {
            cardMap.set(incCard.id, incCard);
          }
        });
        this.saveAnkiCards(Array.from(cardMap.values()));
      }

      if (Array.isArray(data.chatMessages) && data.chatMessages.length > this.getChatMessages().length) {
        this.saveChatMessages(data.chatMessages);
      }
      if (Array.isArray(data.milestones) && data.milestones.length > 0) {
        this.saveMilestones(data.milestones);
      }
      if (data.dailyMenuState) {
        this.saveDailyMenuState(data.dailyMenuState);
      }
      return true;
    } catch (e) {
      console.error('Backup import error:', e);
      return false;
    }
  },

  getLocalTimestamp(): number {
    try {
      const v = localStorage.getItem('tax_exam_last_updated_at');
      return v ? parseInt(v, 10) : 0;
    } catch {
      return 0;
    }
  },

  setLocalTimestamp(ts: number) {
    try {
      safeSetLocalStorage('tax_exam_last_updated_at', String(ts));
    } catch {}
  },

  // Push compact state to server (~10KB instead of 560KB for instant 0ms mobile sync)
  async pushToServer(): Promise<boolean> {
    try {
      // Ensure deltas reflect current theories
      const deltas = this.getTheoryDeltas();
      const theoriesPayload =
        deltas.length > 0
          ? deltas
          : this.getTheories().map((t) => ({
              id: t.id,
              theoryNumber: t.theoryNumber,
              pillarStatuses: t.pillarStatuses || {},
              currentStage: t.currentStage || 1,
              bestScore: t.bestScore || 0,
              bestTimeSeconds: t.bestTimeSeconds || 0,
              history: t.history || [],
              lastPracticed: t.lastPracticed,
            }));

      const backup = {
        timestamp: new Date().toISOString(),
        pillarVault: this.getPillarVault(),
        subjects: this.getSubjects(),
        theories: theoriesPayload,
        calculations: this.getCalculations(),
        ankiCards: this.getAnkiCards(),
        sessions: this.getSessions(),
        chatMessages: this.getChatMessages(),
        milestones: this.getMilestones(),
        dailyMenuState: this.getDailyMenuState(),
      };
      const now = Date.now();
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: backup, timestamp: now }),
      });
      if (res.ok) {
        const json = await res.json().catch(() => ({}));
        const serverTs = typeof json.timestamp === 'number' ? json.timestamp : now;
        this.setLocalTimestamp(serverTs);
        window.dispatchEvent(new CustomEvent('tax_exam_sync_saved', { detail: { timestamp: serverTs } }));
        return true;
      }
      return false;
    } catch (e) {
      console.warn('Failed to push sync to server:', e);
      return false;
    }
  },

  // Pull & Union-Merge state from server; detects if server reset so client can auto-heal server
  async pullFromServer(force: boolean = false): Promise<{ updated: boolean; needsPush?: boolean; data?: any }> {
    try {
      const res = await fetch('/api/sync/pull');
      if (!res.ok) return { updated: false };
      const { data, timestamp } = await res.json();

      const localVault = this.getPillarVault();
      const localVaultCount = Object.keys(localVault).length;
      const localRealSessionsCount = this.getSessions().filter(isRealStudySession).length;
      const localSubjectHours = this.getSubjects().reduce((sum, s) => sum + (s?.currentHours || 0), 0);
      const clientHasRealProgress =
        localVaultCount > 0 || localRealSessionsCount > 0 || localSubjectHours > 0;

      if (!data) {
        if (clientHasRealProgress) {
          await this.pushToServer();
        }
        return { updated: false, needsPush: false };
      }

      const localTs = this.getLocalTimestamp();
      const serverTs = typeof timestamp === 'number' ? timestamp : 0;

      const serverVaultCount =
        data.pillarVault && typeof data.pillarVault === 'object'
          ? Object.values(data.pillarVault).filter((v: any) => isGenuineUserAction(v)).length
          : 0;
      const serverRealSessionsCount = Array.isArray(data.sessions)
        ? data.sessions.filter(isRealStudySession).length
        : 0;
      const serverSubjectHours = Array.isArray(data.subjects)
        ? data.subjects.reduce((sum: number, s: any) => sum + (s?.currentHours || 0), 0)
        : 0;

      const serverHasRealProgress =
        serverTs > 0 && (serverVaultCount > 0 || serverRealSessionsCount > 0 || serverSubjectHours > 0);

      // SAFETY SHIELD: Never pull from an empty or cold-restarted server!
      if (!serverHasRealProgress) {
        if (clientHasRealProgress) {
          await this.pushToServer();
        }
        return { updated: false, needsPush: false };
      }

      if (
        localVaultCount > serverVaultCount ||
        localRealSessionsCount > serverRealSessionsCount ||
        localSubjectHours > serverSubjectHours
      ) {
        await this.pushToServer();
      }

      const isServerNewer = serverTs > localTs && serverHasRealProgress;
      if (isServerNewer || (force && serverHasRealProgress)) {
        this.importBackup(JSON.stringify(data));
        this.saveDailySnapshot();
        this.setLocalTimestamp(Math.max(serverTs, localTs, Date.now()));
        return {
          updated: true,
          needsPush: false,
          data,
        };
      }

      return {
        updated: false,
        needsPush: false,
      };
    } catch (e) {
      console.warn('Failed to pull sync from server:', e);
      return { updated: false };
    }
  },

  // Export Anki compatible CSV
  exportAnkiCSV(cards: AnkiCard[]): string {
    const lines = cards.map((c) => {
      const frontClean = c.front.replace(/"/g, '""').replace(/\n/g, '<br>');
      const backClean = c.back.replace(/"/g, '""').replace(/\n/g, '<br>');
      const tagsClean = c.tag || 'TaxExam';
      return `"${frontClean}"\t"${backClean}"\t"${tagsClean}"`;
    });
    return lines.join('\n');
  },
};
