import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Environment constraint: In development, dev server MUST run on port 3000.
const port = process.env.NODE_ENV === 'production' ? parseInt(process.env.PORT || '3000', 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Shared Server-side Gemini client helper
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY || '';
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Endpoint: Theory Strict Grading with High Thinking (gemini-4-argon with fallback to gemini-3.8-flash)
app.post('/api/ai/grade-theory', async (req: Request, res: Response) => {
  try {
    const {
      theoryTitle,
      standardAnswer,
      keyRequirements,
      userAnswer,
      targetLevel, // Lv.1, Lv.2, Lv.3, Lv.4, Lv.5
      previousAttempt,
    } = req.body;

    if (!userAnswer || !theoryTitle) {
      return res.status(400).json({ error: '理論タイトルと答案テキストを入力してください。' });
    }

    const systemInstruction = `あなたは税理士試験（住民税・酒税法・簿記論・財務諸表論）の極めて厳格な試験採点官兼Muscle+型トレーナーです。
税理士試験の理論では「覚えたつもり」では本番で1行も書けず不合格になります。
提出された答案を模範解答・主要要件と照らし合わせ、一言一句・要件・数字・例外規定・主語述語の精度まで厳格に採点してください。
「タイトル漏れ」「要件漏れ」「数字・期限の間違い」「重要語句の欠落」「語尾・表現の不正確さ」「論点の順番間違い」を容赦なく分類し、受講生が次回確実に克服できるよう分析してください。
また、前回結果（${previousAttempt ? JSON.stringify(previousAttempt) : '初挑戦'}）と比較し、成長した点と次回への改善アクションを明確に提示してください。`;

    const prompt = `【採点対象理論】: ${theoryTitle}
【特訓レベル】: Lv.${targetLevel || '4'}
【模範解答 / 柱・構成】:
${standardAnswer || 'なし'}

【必須要件・キーワードリスト】:
${Array.isArray(keyRequirements) ? keyRequirements.join('\n') : (keyRequirements || 'なし')}

【受講生が白紙から作成した答案】:
${userAnswer}

【前回の記録】:
${previousAttempt ? `前回スコア: ${previousAttempt.score}点, 欠落要件: ${previousAttempt.missingRequirements?.join(', ') || 'なし'}` : '前回記録なし（初回特訓）'}

以下のJSONフォーマットで厳格に採点・評価を返してください:
{
  "score": number (0〜100点),
  "isPass": boolean (80点以上かつ重要要件漏れがない場合true),
  "isPersonalBest": boolean,
  "reproductionRate": number (0〜100%),
  "summaryComment": string (採点官からの簡潔かつ熱いフィードバック。Muscle+風に「前回の壁を破ったか」に言及),
  "defectBreakdown": {
    "titleMissing": string[] (漏れたタイトルや柱見出し),
    "requirementsMissing": string[] (抜け落ちた要件・適用条件),
    "numbersOrDatesWrong": string[] (間違えた数字、パーセンテージ、申告納付期限など),
    "crucialKeywordsMissing": string[] (欠落した税法上の重要専門用語),
    "expressionFlaws": string[] (語尾や主語述語の不正確さ、法令用語としての不備)
  },
  "strengthsOverPrevious": string[] (前回より書けるようになった点、再現できたポイント),
  "nextDrillAction": string (次回Lv.5制限時間クリアや100%再現に向けた具体的処方箋)
}`;

    // Attempt with gemini-4-argon with ThinkingLevel.HIGH as mandated for complex high-thinking queries
    const ai = getGenAI();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-argon',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.HIGH,
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json(parsed);
    } catch (argonError: any) {
      console.warn('gemini-4-argon fallback to gemini-3.8-flash:', argonError?.message);
      // Fallback to gemini-3.8-flash with MEDIUM thinking
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.MEDIUM,
          },
        },
      });
      const parsed = JSON.parse(fallbackResponse.text || '{}');
      return res.json(parsed);
    }
  } catch (error: any) {
    console.error('Error in /api/ai/grade-theory:', error);
    res.status(500).json({ error: error?.message || '理論採点中にエラーが発生しました。' });
  }
});

// Endpoint: Parse NotebookLM notes or text into 5-stage theory structure + Anki cards
app.post('/api/ai/parse-notebooklm', async (req: Request, res: Response) => {
  try {
    const { rawText, subjectId } = req.body;
    if (!rawText) {
      return res.status(400).json({ error: 'テキストを入力してください。' });
    }

    const systemInstruction = `あなたは税理士試験（住民税・酒税法・簿記論・財務諸表論）の教材・理論サブノート構造化アナリストです。
NotebookLMから抽出した講義ノート、要約、Q&A、法改正テキスト、または自作の論点メモを解析し、Muscle+型の「5段階理論特訓システム」および「Anki用暗記カード」へ自動変換してください。
特に最新2027年試験向け（住民税の定額減税や税率・控除の改正、酒税の税率統合改正など）の改正要素があれば 'isRevised2027: true' と判定してください。`;

    const prompt = `以下の入力テキストから、税理士試験の理論論点を検出し、5段階トレーニング用データとAnkiカードを生成してください。
科目指定: ${subjectId || '住民税'}
【入力テキスト】:
${rawText}
`;

    const ai = getGenAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            detectedSubject: { type: Type.STRING },
            theoryItems: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING, description: '理論の正式題名（例: 均等割の納税義務者及び非課税の範囲）' },
                  category: { type: Type.STRING, description: 'カテゴリ（納税義務、課税標準、税額控除、申告手続、不服申立 等）' },
                  isRevised2027: { type: Type.BOOLEAN, description: '最新法改正に関連する論点か' },
                  lv1TitleAnswer: { type: Type.STRING, description: 'Lv1用: 概要・キーワードから即想起させるヒントと正解' },
                  lv2Outline: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Lv2用: 答案を構成する柱・見出し一覧',
                  },
                  lv3KeyRequirements: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Lv3用: 条文の重要要件、数字、期限、例外事項のリスト',
                  },
                  lv4FullText: { type: Type.STRING, description: 'Lv4/Lv5用: 白紙再現用の模範解答全文' },
                  standardTimeMinutes: { type: Type.INTEGER, description: '本試験で書き切る標準所要時間（分）' },
                  ankiCards: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        front: { type: Type.STRING, description: 'Anki表面の問い（例: 住民税における障害者等の非課税限度額の判定式は？）' },
                        back: { type: Type.STRING, description: 'Anki裏面の答え（数字・要件）' },
                        tag: { type: Type.STRING },
                      },
                      required: ['front', 'back'],
                    },
                  },
                },
                required: ['title', 'category', 'lv2Outline', 'lv3KeyRequirements', 'lv4FullText'],
              },
            },
          },
          required: ['theoryItems'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error in /api/ai/parse-notebooklm:', error);
    res.status(500).json({ error: error?.message || 'NotebookLM解析中にエラーが発生しました。' });
  }
});

// Endpoint: Multi-turn Chat for Tax Exam Trainer
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { messages, currentSubject, userStats } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'メッセージ配列が必要です。' });
    }

    const systemInstruction = `あなたは税理士試験（住民税・酒税法・簿記論・財務諸表論）の合格請負人であり、筋トレアプリ「Muscle+」のストイックさと熱さを備えた専属パーソナルトレーナーです。
受講生の現在の状況:
- 住民税: 過去2年不合格をバネに今年絶対合格。課題は理論の白紙再現と計算の高速化。
- 酒税法: 理論先行で早期完成を目指す。
- 簿記論・財務諸表論: 個別問題から総合問題へ着実にステップアップ。
- 総学習目標: 900時間（2026年11月3日再スタート〜2027年本試験）。
- 現在選択中の科目: ${currentSubject || '住民税'}
- 記録状況: ${userStats ? JSON.stringify(userStats) : '学習進行中'}

あなたの指導スタイル:
1. 単なる慰めや精神論は言わない。「前回の自分（タイム・正答率・再現率）を1ミリでも超えたか」にこだわる。
2. 理論暗記は「タイトル→骨格（柱）→要件・数字→白紙再現→制限時間テスト」の5段階を徹底。
3. 計算ミスは「①知識不足 ②解法手順不発 ③純粋な計算ミス ④問題文読み違い」の4大分類で即座に処方箋を出す。
4. 口頭テストを出題したり、受講生の疑問（改正論点や計算の解法順序など）に明快かつ具体的に回答する。
5. 口調は頼れるストイックな鬼コーチでありながら、成長を本気で称える熱血スタイル（「ナイスレップ！」「前回のタイムを更新したな！」「その調子で脳の筋肉を追い込め！」）。`;

    // Convert messages to GenAI contents format
    const contents = messages.map((m: any) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content || m.text || '' }],
    }));

    const ai = getGenAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
      },
    });

    return res.json({
      role: 'assistant',
      content: response.text || '回答を生成できませんでした。',
    });
  } catch (error: any) {
    console.error('Error in /api/ai/chat:', error);
    res.status(500).json({ error: error?.message || 'チャット処理中にエラーが発生しました。' });
  }
});

// Shared Server-side Cross-Device Sync State
const SYNC_FILE_PATH = path.resolve(__dirname, '.sync_state.json');
const POISON_TEST_TS = 1794395356434;
const POISON_SYNC_FILE_TS = 1794395356587;
let serverSyncState: any = null;
let serverSyncTimestamp = 0;

function normalizePillarKey(key: string): string {
  if (!key) return '';
  return key.replace(/[\s　]*[◎○❌×△⚪︎]+[\s　]*$/g, '').trim();
}

function isGenuineServerUserAction(p: any): boolean {
  if (!p || typeof p !== 'object') return false;
  if (p.updatedAt === POISON_TEST_TS) return false;
  if (p.isUserAction === true || p.isUserEvaluated === true) return true;
  if (p.isUserAction === false) return false;
  return Boolean(
    typeof p.updatedAt === 'number' && p.updatedAt > 0
  );
}

function calculateStageFromMergedPillars(pillars: Record<string, any>, candidate: number): number {
  const values = Object.values(pillars || {});
  if (values.length === 0) return Math.max(1, candidate || 1);
  let mastered = 0;
  let learning = 0;
  let weak = 0;
  values.forEach((p: any) => {
    if (p?.status === 'mastered') mastered++;
    else if (p?.status === 'learning') learning++;
    else weak++;
  });
  if (mastered === values.length) return Math.max(3, candidate || 3);
  if (weak === 0 && mastered + learning === values.length) return 2;
  return 1;
}

function compactTheoryEntry(t: any): any {
  if (!t || typeof t !== 'object') return t;
  if (t.isCustomTheory) return t;
  return {
    id: t.id,
    theoryNumber: t.theoryNumber,
    pillarStatuses: t.pillarStatuses || {},
    currentStage: t.currentStage || 1,
    bestScore: t.bestScore || 0,
    bestTimeSeconds: t.bestTimeSeconds || 0,
    history: Array.isArray(t.history) ? t.history : [],
    lastPracticed: t.lastPracticed,
  };
}

try {
  if (fs.existsSync(SYNC_FILE_PATH)) {
    const raw = fs.readFileSync(SYNC_FILE_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    if (parsed && parsed.timestamp && parsed.timestamp !== POISON_SYNC_FILE_TS && parsed.data) {
      serverSyncState = parsed.data;
      if (serverSyncState.pillarVault && typeof serverSyncState.pillarVault === 'object') {
        Object.keys(serverSyncState.pillarVault).forEach((vk) => {
          if (!isGenuineServerUserAction(serverSyncState.pillarVault[vk])) {
            delete serverSyncState.pillarVault[vk];
          }
        });
      }
      if (Array.isArray(serverSyncState.theories)) {
        serverSyncState.theories = serverSyncState.theories.map(compactTheoryEntry);
      }
      serverSyncTimestamp = parsed.timestamp || 0;
    } else {
      serverSyncState = null;
      serverSyncTimestamp = 0;
    }
  }
} catch (e) {
  console.warn('Could not read existing sync file:', e);
}

// Endpoint: Push client state to server for cross-device sync (Smartphone ↔ PC)
app.post('/api/sync/push', (req: Request, res: Response) => {
  try {
    const { data, timestamp } = req.body;
    if (data && typeof timestamp === 'number') {
      // Sanitize incoming vault against poisoned test entry
      const cleanIncomingVault: Record<string, any> = {};
      Object.entries(data.pillarVault || {}).forEach(([k, inV]: [string, any]) => {
        if (k.includes('::') && isGenuineServerUserAction(inV)) {
          cleanIncomingVault[k] = inV;
          const [tId, pKey] = k.split('::');
          cleanIncomingVault[`${tId}::${normalizePillarKey(pKey)}`] = inV;
        }
      });

      if (!serverSyncState) {
        serverSyncState = {
          ...data,
          pillarVault: cleanIncomingVault,
          theories: Array.isArray(data.theories) ? data.theories.map(compactTheoryEntry) : [],
        };
      } else {
        // 1. Merge PillarVault with both raw and normalized keys (strictly genuine user actions)
        const mergedVault: Record<string, any> = {};
        Object.entries(serverSyncState.pillarVault || {}).forEach(([k, v]: [string, any]) => {
          if (k.includes('::') && isGenuineServerUserAction(v)) {
            mergedVault[k] = v;
            const [tId, pKey] = k.split('::');
            mergedVault[`${tId}::${normalizePillarKey(pKey)}`] = v;
          }
        });
        Object.entries(cleanIncomingVault).forEach(([k, inV]: [string, any]) => {
          const exV = mergedVault[k];
          if (!exV || (inV.updatedAt || 0) >= (exV.updatedAt || 0)) {
            mergedVault[k] = inV;
            const [tId, pKey] = k.split('::');
            mergedVault[`${tId}::${normalizePillarKey(pKey)}`] = inV;
          }
        });

        // 2. Intelligent bidirectional merge for theories (respects downgrades ◎ -> ○ / ❌)
        const incomingTheoriesMap = new Map<string, any>();
        (data.theories || []).forEach((t: any) => {
          if (t.id) incomingTheoriesMap.set(t.id, t);
          if (t.theoryNumber) incomingTheoriesMap.set(t.theoryNumber, t);
        });

        const baseTheories =
          serverSyncState.theories && serverSyncState.theories.length > 0
            ? serverSyncState.theories
            : data.theories || [];

        const mergedTheories = baseTheories.map((exT: any) => {
          const inT = incomingTheoriesMap.get(exT.id) || incomingTheoriesMap.get(exT.theoryNumber);
          if (!inT) return compactTheoryEntry(exT);

          const allPillars = new Set([
            ...Object.keys(exT.pillarStatuses || {}),
            ...Object.keys(inT.pillarStatuses || {}),
          ]);
          const mergedPillars: Record<string, any> = {};
          allPillars.forEach((k) => {
            const exP = exT.pillarStatuses?.[k];
            const inP = inT.pillarStatuses?.[k];
            const normK = normalizePillarKey(k);
            const vEntry =
              mergedVault[`${exT.id || inT.id}::${k}`] ||
              mergedVault[`${exT.id || inT.id}::${normK}`];

            const inIsUser = isGenuineServerUserAction(inP);
            const exIsUser = isGenuineServerUserAction(exP);

            let chosen = inP || exP;
            if (inP && exP) {
              const inTime = inP.updatedAt || 0;
              const exTime = exP.updatedAt || 0;
              if (inIsUser && !exIsUser) {
                chosen = inP;
              } else if (!inIsUser && exIsUser) {
                chosen = exP;
              } else {
                chosen = inTime >= exTime ? inP : exP;
              }
            }
            if (vEntry && isGenuineServerUserAction(vEntry) && (vEntry.updatedAt || 0) >= (chosen?.updatedAt || 0)) {
              chosen = {
                status: vEntry.status,
                lockCount: vEntry.lockCount,
                updatedAt: vEntry.updatedAt,
                isUserAction: true,
              };
            }
            if (chosen && chosen.updatedAt !== POISON_TEST_TS) {
              mergedPillars[k] = chosen;
              mergedPillars[normK] = chosen;
            }
          });

          // Merge practice history logs by id
          const histMap = new Map<string, any>();
          (exT.history || []).forEach((h: any) => {
            if (h?.id) histMap.set(h.id, h);
          });
          (inT.history || []).forEach((h: any) => {
            if (h?.id && !histMap.has(h.id)) histMap.set(h.id, h);
          });

          const candidateStage = inT.currentStage !== undefined ? inT.currentStage : exT.currentStage || 1;
          const recomputedStage = calculateStageFromMergedPillars(mergedPillars, candidateStage);

          return compactTheoryEntry({
            ...exT,
            ...inT,
            pillarStatuses: mergedPillars,
            currentStage: recomputedStage,
            bestScore: Math.max(inT.bestScore || 0, exT.bestScore || 0),
            bestTimeSeconds:
              inT.bestTimeSeconds > 0 && exT.bestTimeSeconds > 0
                ? Math.min(inT.bestTimeSeconds, exT.bestTimeSeconds)
                : inT.bestTimeSeconds || exT.bestTimeSeconds || 0,
            history: Array.from(histMap.values()),
            lastPracticed:
              (inT.lastPracticed || '') >= (exT.lastPracticed || '')
                ? inT.lastPracticed || exT.lastPracticed
                : exT.lastPracticed,
          });
        });

        (data.theories || []).forEach((inT: any) => {
          const already = mergedTheories.some(
            (t: any) => t.id === inT.id || (t.theoryNumber && t.theoryNumber === inT.theoryNumber)
          );
          if (!already) {
            mergedTheories.push(compactTheoryEntry(inT));
          }
        });

        // 3. Merge dailyMenuState (completed items, theories, done flags, and SRS intervals)
        const mergedDaily: Record<string, string> = {
          ...(serverSyncState.dailyMenuState || {}),
          ...(data.dailyMenuState || {}),
        };
        Object.keys(mergedDaily).forEach((k) => {
          const exV = serverSyncState.dailyMenuState?.[k];
          const inV = data.dailyMenuState?.[k];
          if (exV && inV && k.startsWith('tax_exam_notion_srs_')) {
            try {
              const pEx = JSON.parse(exV);
              const pIn = JSON.parse(inV);
              const mSrs = { ...pEx };
              Object.entries(pIn).forEach(([tId, inSrs]: [string, any]) => {
                const exSrs = mSrs[tId];
                if (!exSrs || (inSrs.lastReviewedDate || '') >= (exSrs.lastReviewedDate || '')) {
                  mSrs[tId] = inSrs;
                }
              });
              mergedDaily[k] = JSON.stringify(mSrs);
            } catch {}
          } else if (exV && inV && (k.includes('completed_items') || k.includes('completed_theories'))) {
            try {
              const pEx = JSON.parse(exV);
              const pIn = JSON.parse(inV);
              mergedDaily[k] = JSON.stringify({ ...pEx, ...pIn });
            } catch {}
          } else if (k.includes('_done_') && (exV === 'true' || inV === 'true')) {
            mergedDaily[k] = 'true';
          }
        });

        // 4. Union-merge sessions (deduplicate by id)
        const sessionMap = new Map<string, any>();
        (serverSyncState.sessions || []).forEach((s: any) => {
          if (s?.id) sessionMap.set(s.id, s);
        });
        (data.sessions || []).forEach((s: any) => {
          if (s?.id && !sessionMap.has(s.id)) sessionMap.set(s.id, s);
        });
        const mergedSessions = Array.from(sessionMap.values());

        // 5. Merge subjects preserving max study hours
        const exSubMap = new Map<string, any>();
        (serverSyncState.subjects || []).forEach((s: any) => {
          if (s?.id) exSubMap.set(s.id, s);
        });
        const mergedSubjects = (data.subjects || serverSyncState.subjects || []).map((inS: any) => {
          const exS = exSubMap.get(inS.id);
          const sesMins = mergedSessions
            .filter((ses: any) => ses.subjectId === inS.id && ses.minutes > 0)
            .reduce((sum: number, ses: any) => sum + ses.minutes, 0);
          const sesHours = Math.round((sesMins / 60) * 10) / 10;
          return {
            ...(exS || {}),
            ...inS,
            currentHours: Math.max(exS?.currentHours || 0, inS.currentHours || 0, sesHours),
          };
        });

        // 6. Union-merge calculations logs
        const calcMap = new Map<string, any>();
        (serverSyncState.calculations || []).forEach((c: any) => {
          if (c?.id) calcMap.set(c.id, c);
        });
        (data.calculations || []).forEach((inC: any) => {
          if (!inC?.id) return;
          const exC = calcMap.get(inC.id);
          if (!exC) {
            calcMap.set(inC.id, inC);
            return;
          }
          const logMap = new Map<string, any>();
          (exC.logs || []).forEach((l: any) => {
            if (l?.id) logMap.set(l.id, l);
          });
          (inC.logs || []).forEach((l: any) => {
            if (l?.id && !logMap.has(l.id)) logMap.set(l.id, l);
          });
          const bestTimes = [exC.bestTimeSeconds, inC.bestTimeSeconds].filter((t) => t && t > 0);
          calcMap.set(inC.id, {
            ...exC,
            ...inC,
            bestTimeSeconds: bestTimes.length > 0 ? Math.min(...bestTimes) : 0,
            consecutiveCorrect: Math.max(exC.consecutiveCorrect || 0, inC.consecutiveCorrect || 0),
            logs: Array.from(logMap.values()),
          });
        });

        // 7. Merge Anki cards
        const cardMap = new Map<string, any>();
        (serverSyncState.ankiCards || []).forEach((c: any) => {
          if (c?.id) cardMap.set(c.id, c);
        });
        (data.ankiCards || []).forEach((inCard: any) => {
          if (!inCard?.id) return;
          const exCard = cardMap.get(inCard.id);
          if (!exCard || (inCard.repetitions || 0) >= (exCard.repetitions || 0)) {
            cardMap.set(inCard.id, inCard);
          }
        });

        serverSyncState = {
          ...serverSyncState,
          ...data,
          pillarVault: mergedVault,
          subjects: mergedSubjects,
          theories: mergedTheories,
          calculations: Array.from(calcMap.values()),
          ankiCards: Array.from(cardMap.values()),
          dailyMenuState: mergedDaily,
          sessions: mergedSessions,
          milestones: data.milestones || serverSyncState.milestones,
        };
      }

      serverSyncTimestamp = Date.now();
      try {
        fs.writeFileSync(SYNC_FILE_PATH, JSON.stringify({ data: serverSyncState, timestamp: serverSyncTimestamp }));
      } catch (e) {
        console.warn('Could not write sync file:', e);
      }
      return res.json({ success: true, timestamp: serverSyncTimestamp });
    }
    return res.status(400).json({ error: '無効な同期データ形式です。' });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || '同期保存エラー' });
  }
});

// Endpoint: Pull latest state from server (Smartphone ↔ PC)
app.get('/api/sync/pull', (_req: Request, res: Response) => {
  res.json({
    data: serverSyncState,
    timestamp: serverSyncTimestamp,
  });
});

// Production vs Development Setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Tax Exam OS server running on http://0.0.0.0:${port}`);
  });
}

startServer();
